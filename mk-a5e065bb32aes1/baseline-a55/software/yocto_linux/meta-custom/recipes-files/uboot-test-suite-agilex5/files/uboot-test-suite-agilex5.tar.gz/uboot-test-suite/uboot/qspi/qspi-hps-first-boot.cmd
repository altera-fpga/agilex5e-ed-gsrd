# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from qspi/uboot/qspi_hps_first_boot/test_steps.pl
echo "[uboot-qspi-hps-first-boot] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] fatwrite mmc 0:1 $loadaddr $core_rbf $filesize"
  if fatwrite mmc 0:1 $loadaddr $core_rbf $filesize; then
    echo "[OK] fatwrite mmc 0:1 $loadaddr $core_rbf $filesize"
  else
    echo "[FAIL] command failed: fatwrite mmc 0:1 $loadaddr $core_rbf $filesize"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] sf probe"
  if sf probe; then
    echo "[OK] sf probe"
  else
    echo "[FAIL] command failed: sf probe"
    exit 1
  fi
  echo "[cmd] md.l 0xff8d2000 1"
  if md.l 0xff8d2000 1; then
    echo "[OK] md.l 0xff8d2000 1"
  else
    echo "[FAIL] command failed: md.l 0xff8d2000 1"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] md.l 0xff8d2000 1"
  if md.l 0xff8d2000 1; then
    echo "[OK] md.l 0xff8d2000 1"
  else
    echo "[FAIL] command failed: md.l 0xff8d2000 1"
    exit 1
  fi
  echo "[cmd] sf read 1000000 420 10"
  if sf read 1000000 420 10; then
    echo "[OK] sf read 1000000 420 10"
  else
    echo "[FAIL] command failed: sf read 1000000 420 10"
    exit 1
  fi
  echo "[cmd] md 1000000 10"
  if md 1000000 10; then
    echo "[OK] md 1000000 10"
  else
    echo "[FAIL] command failed: md 1000000 10"
    exit 1
  fi
  echo "[cmd] version"
  if version; then
    echo "[OK] version"
  else
    echo "[FAIL] command failed: version"
    exit 1
  fi
  echo "[cmd] reset -w"
  echo "[INFO] reset command should reboot the board; script fails if it returns"
  reset -w
  echo "[FAIL] reset command returned unexpectedly"
  exit 1
  echo "[cmd] setenv reset warm"
  setenv reset warm
  echo "[cmd] reset"
  echo "[INFO] reset command should reboot the board; script fails if it returns"
  reset
  echo "[FAIL] reset command returned unexpectedly"
  exit 1
  echo "[cmd] setenv reset cold"
  setenv reset cold
  echo "[cmd] reset"
  echo "[INFO] reset command should reboot the board; script fails if it returns"
  reset
  echo "[FAIL] reset command returned unexpectedly"
  exit 1
  echo "[cmd] sf probe"
  if sf probe; then
    echo "[OK] sf probe"
  else
    echo "[FAIL] command failed: sf probe"
    exit 1
  fi
  echo "[cmd] md.l 0xff8d2000 1"
  if md.l 0xff8d2000 1; then
    echo "[OK] md.l 0xff8d2000 1"
  else
    echo "[FAIL] command failed: md.l 0xff8d2000 1"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] md.l 0xff8d2000 1"
  if md.l 0xff8d2000 1; then
    echo "[OK] md.l 0xff8d2000 1"
  else
    echo "[FAIL] command failed: md.l 0xff8d2000 1"
    exit 1
  fi
  echo "[cmd] bridge enable"
  if bridge enable; then
    echo "[OK] bridge enable"
  else
    echo "[FAIL] command failed: bridge enable"
    exit 1
  fi
  echo "[cmd] md f9000000 1"
  if md f9000000 1; then
    echo "[OK] md f9000000 1"
  else
    echo "[FAIL] command failed: md f9000000 1"
    exit 1
  fi
  echo "[cmd] mw.l 0xffd00204 0x11"
  if mw.l 0xffd00204 0x11; then
    echo "[OK] mw.l 0xffd00204 0x11"
  else
    echo "[FAIL] command failed: mw.l 0xffd00204 0x11"
    exit 1
  fi
  echo "[cmd] mw ffd00200 1"
  if mw ffd00200 1; then
    echo "[OK] mw ffd00200 1"
  else
    echo "[FAIL] command failed: mw ffd00200 1"
    exit 1
  fi
  echo "[cmd] sf probe"
  if sf probe; then
    echo "[OK] sf probe"
  else
    echo "[FAIL] command failed: sf probe"
    exit 1
  fi
  echo "[cmd] md.l 0xff8d2000 1"
  if md.l 0xff8d2000 1; then
    echo "[OK] md.l 0xff8d2000 1"
  else
    echo "[FAIL] command failed: md.l 0xff8d2000 1"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] md.l 0xff8d2000 1"
  if md.l 0xff8d2000 1; then
    echo "[OK] md.l 0xff8d2000 1"
  else
    echo "[FAIL] command failed: md.l 0xff8d2000 1"
    exit 1
  fi
  echo "[cmd] bridge enable"
  if bridge enable; then
    echo "[OK] bridge enable"
  else
    echo "[FAIL] command failed: bridge enable"
    exit 1
  fi
  echo "[cmd] md f9000000 1"
  if md f9000000 1; then
    echo "[OK] md f9000000 1"
  else
    echo "[FAIL] command failed: md f9000000 1"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
