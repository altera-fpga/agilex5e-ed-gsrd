#!/usr/bin/env bash
# Lab capability profile for Linux test-suite **runtime** execution gating.
#
# All tests are shipped in the customer zip. config/testsuite.conf lab flags
# (usb, i2c, i3c, spi, ...) decide which tests ./ts all and ./ts run will execute.

lab_trim() {
  local s="$1"
  s="${s#"${s%%[![:space:]]*}"}"
  s="${s%"${s##*[![:space:]]}"}"
  printf '%s' "$s"
}

lab_parse_bool() {
  case "${1,,}" in
    y|yes|1|true|on) return 0 ;;
    *) return 1 ;;
  esac
}

lab_load_config_from_file() {
  local config_file="${1:-}"
  local line key value

  export LAB_USB=0 LAB_USB2=0 LAB_USB3=0 LAB_USB_DEVICE_MODE=0
  export LAB_I2C=0 LAB_I3C=0 LAB_SPI=0 LAB_DEBUG2=0 LAB_TSN_CFG2=0
  export LAB_FCS=0 LAB_DMA=0
  export LAB_NAND=0 LAB_EMMC=0
  export DAUGHTER_CARD=OOBE HOST_CONNECTION=devkit

  [[ -n "$config_file" && -f "$config_file" ]] || return 0

  declare -A explicit=()

  while IFS= read -r line || [[ -n "$line" ]]; do
    line="${line%%#*}"
    line="$(lab_trim "$line")"
    [[ -z "$line" || "$line" != *"="* ]] && continue

    key="${line%%=*}"
    value="${line#*=}"
    key="$(lab_trim "${key,,}")"
    value="$(lab_trim "$value")"

    case "$key" in
      daughter_card) export DAUGHTER_CARD="$value" ;;
      host_connection) export HOST_CONNECTION="$value" ;;
      usb)
        explicit[usb]=1
        if lab_parse_bool "$value"; then export LAB_USB=1; else export LAB_USB=0; fi
        ;;
      usb2)
        explicit[usb2]=1
        if lab_parse_bool "$value"; then export LAB_USB2=1; else export LAB_USB2=0; fi
        ;;
      usb3)
        explicit[usb3]=1
        if lab_parse_bool "$value"; then export LAB_USB3=1; else export LAB_USB3=0; fi
        ;;
      usb_device_mode)
        explicit[usb_device_mode]=1
        if lab_parse_bool "$value"; then export LAB_USB_DEVICE_MODE=1; else export LAB_USB_DEVICE_MODE=0; fi
        ;;
      i2c)
        explicit[i2c]=1
        if lab_parse_bool "$value"; then export LAB_I2C=1; else export LAB_I2C=0; fi
        ;;
      i3c)
        explicit[i3c]=1
        if lab_parse_bool "$value"; then export LAB_I3C=1; else export LAB_I3C=0; fi
        ;;
      spi)
        explicit[spi]=1
        if lab_parse_bool "$value"; then export LAB_SPI=1; else export LAB_SPI=0; fi
        ;;
      debug2)
        explicit[debug2]=1
        if lab_parse_bool "$value"; then export LAB_DEBUG2=1; else export LAB_DEBUG2=0; fi
        ;;
      tsn_cfg2)
        explicit[tsn_cfg2]=1
        if lab_parse_bool "$value"; then export LAB_TSN_CFG2=1; else export LAB_TSN_CFG2=0; fi
        ;;
      fcs)
        explicit[fcs]=1
        if lab_parse_bool "$value"; then export LAB_FCS=1; else export LAB_FCS=0; fi
        ;;
      dma)
        explicit[dma]=1
        if lab_parse_bool "$value"; then export LAB_DMA=1; else export LAB_DMA=0; fi
        ;;
      nand)
        if lab_parse_bool "$value"; then export LAB_NAND=1; else export LAB_NAND=0; fi
        ;;
      emmc)
        if lab_parse_bool "$value"; then export LAB_EMMC=1; else export LAB_EMMC=0; fi
        ;;
    esac
  done < "$config_file"

  if [[ "${LAB_USB:-0}" -eq 1 ]]; then
    [[ -z "${explicit[usb2]:-}" ]] && export LAB_USB2=1
    [[ -z "${explicit[usb3]:-}" ]] && export LAB_USB3=1
  fi

  if [[ "${LAB_DEBUG2:-0}" -eq 1 ]]; then
    export LAB_SPI=1
  fi
}

lab_is_peripheral_enabled() {
  local peripheral="${1,,}"
  local var="LAB_${peripheral^^}"

  case "$peripheral" in
    usb|usb2|usb3|usb_device_mode|i2c|i3c|spi|debug2|tsn_cfg2|fcs|dma|nand|emmc) ;;
    *) return 1 ;;
  esac

  case "$peripheral" in
    usb2|usb3)
      [[ "${LAB_USB:-0}" -eq 1 ]] && return 0
      ;;
    spi)
      [[ "${LAB_DEBUG2:-0}" -eq 1 ]] && return 0
      ;;
  esac

  [[ "${!var:-0}" -eq 1 ]]
}

lab_has_tag() {
  local tags="$1"
  local want="$2"
  local tag

  IFS=',' read -ra tag_list <<< "$tags"
  for tag in "${tag_list[@]}"; do
    tag="$(lab_trim "$tag")"
    [[ "$tag" == "$want" ]] && return 0
  done
  return 1
}

lab_required_peripherals() {
  local tags="$1"
  local source_path="$2"
  local -a required=()
  local tag peripheral

  IFS=',' read -ra tag_list <<< "$tags"
  for tag in "${tag_list[@]}"; do
    tag="$(lab_trim "$tag")"
    [[ "$tag" == requires-* ]] || continue
    peripheral="${tag#requires-}"
    required+=("$peripheral")
  done

  if [[ ${#required[@]} -eq 0 ]]; then
    case "$source_path" in
      */usb/linux/usb3_device_mode/*|usb/linux/usb3_device_mode/*|tests/usb/usb3-device-mode.sh)
        required+=(usb_device_mode) ;;
      */usb/linux/usb3_w_usb2_thumbdrive/*|usb/linux/usb3_w_usb2_thumbdrive/*|tests/usb/usb3-w-usb2-thumbdrive.sh)
        required+=(usb2) ;;
      */usb/linux/usb2_hotplug/*|usb/linux/usb2_hotplug/*|tests/usb/usb2-hotplug.sh)
        required+=(usb2) ;;
      */usb/*|usb/*|tests/usb/*)
        required+=(usb3) ;;
      */i2c/*|i2c/*|tests/i2c/*)
        required+=(i2c) ;;
      */i3c/linux/basic_i3c_rw/*|i3c/linux/basic_i3c_rw/*|*/i3c/linux/dw_i3c_probe/*|i3c/linux/dw_i3c_probe/*|tests/i3c/*|*/i3c/uboot/*|i3c/uboot/*)
        required+=(i3c) ;;
      */dma/linux/dmatest/*|dma/linux/dmatest/*|tests/dma/*)
        required+=(dma) ;;
      */spi/*|spi/*|tests/spi/*)
        required+=(spi) ;;
      */ETH/Config2/*|networking/linux/ETH/Config2/*|tests/ethernet/eth-config2-*)
        required+=(tsn_cfg2) ;;
    esac
  fi

  if [[ ${#required[@]} -gt 0 ]]; then
    printf '%s\n' "${required[@]}"
  fi
}

lab_entry_runnable() {
  local tags="$1"
  local source_path="$2"
  local peripheral

  while IFS= read -r peripheral; do
    [[ -z "$peripheral" ]] && continue
    if ! lab_is_peripheral_enabled "$peripheral"; then
      return 1
    fi
  done < <(lab_required_peripherals "$tags" "$source_path")

  return 0
}

lab_peripheral_config_key() {
  case "${1,,}" in
    usb3) printf 'usb' ;;
    usb2) printf 'usb2' ;;
    *) printf '%s' "${1,,}" ;;
  esac
}

lab_skip_reason() {
  local tags="$1"
  local source_path="$2"
  local -a missing=()
  local -a hints=()
  local peripheral key hint seen

  while IFS= read -r peripheral; do
    [[ -z "$peripheral" ]] && continue
    if ! lab_is_peripheral_enabled "$peripheral"; then
      missing+=("$peripheral")
    fi
  done < <(lab_required_peripherals "$tags" "$source_path")

  if [[ ${#missing[@]} -eq 0 ]]; then
    return 1
  fi

  for peripheral in "${missing[@]}"; do
    key="$(lab_peripheral_config_key "$peripheral")"
    hint="${key}=y"
    for seen in "${hints[@]:-}"; do
      [[ "$seen" == "$hint" ]] && hint="" && break
    done
    [[ -n "$hint" ]] && hints+=("$hint")
  done

  local IFS=', '
  printf '%s' "${hints[*]}"
}

lab_show_profile() {
  cat <<EOF
Lab profile:
  daughter_card  : ${DAUGHTER_CARD:-OOBE}
  host_connection: ${HOST_CONNECTION:-devkit}
  usb            : $([[ "${LAB_USB:-0}" -eq 1 ]] && echo y || echo n)  (usb2=$([[ "${LAB_USB2:-0}" -eq 1 ]] && echo y || echo n), usb3=$([[ "${LAB_USB3:-0}" -eq 1 ]] && echo y || echo n))
  usb_device_mode: $([[ "${LAB_USB_DEVICE_MODE:-0}" -eq 1 ]] && echo y || echo n)  (OTG/device — separate from usb thumbdrive)
  i2c            : $([[ "${LAB_I2C:-0}" -eq 1 ]] && echo y || echo n)
  i3c            : $([[ "${LAB_I3C:-0}" -eq 1 ]] && echo y || echo n)
  spi / debug2   : $([[ "${LAB_SPI:-0}" -eq 1 ]] && echo y || echo n)
  tsn_cfg2       : $([[ "${LAB_TSN_CFG2:-0}" -eq 1 ]] && echo y || echo n)
  fcs            : $([[ "${LAB_FCS:-0}" -eq 1 ]] && echo y || echo n)  (FCS hardware crypto via fcs_client)
  dma            : $([[ "${LAB_DMA:-0}" -eq 1 ]] && echo y || echo n)  (kernel dmatest module)
EOF
}
