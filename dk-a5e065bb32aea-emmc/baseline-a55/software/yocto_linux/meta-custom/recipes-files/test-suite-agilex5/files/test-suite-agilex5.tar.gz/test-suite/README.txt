emb-test-suite test-suite package

Platform   : agilex5
Build type : release
Built UTC  : 2026-09-14T06:47:29Z

Quick start - Linux:
  vi config/testsuite.conf     # edit lab flags (usb/i2c/...) and NET_IFACE, PEER_IP, etc.
  ./ts config                # review active lab profile
  ./ts list                  # all shipped tests are listed
  ./ts all                   # runs enabled tests; peripheral tests skip until usb=y, i2c=y, ...
  ./ts run usb/usb-rw        # run one test after enabling usb=y in config

Deploy note:
  Always install from the release .zip (unzip on the board). Do not copy manifest.tsv
  through terminals or editors that wrap long lines — that corrupts the test list.

Quick start - U-Boot:
  # To include pre-built U-Boot .scr files, rebuild using:
  make PLAT=<plat> BUILD_TYPE=<type> uboot

Host helpers (from repo checkout):
  bash tools/testsuite/uboot_runner.sh list
  bash tools/testsuite/uboot_runner.sh oobe-smoke
  bash tools/testsuite/analyze_uboot_log.sh console.log

Notes:
  - Linux defaults are maintained in tools/testsuite/config/<platform>.conf.
  - U-Boot defaults are maintained in tools/testsuite/config/uboot_<platform>.env.
  - Perl/shell conversion workflow: tools/testsuite/CONVERSION_WORKFLOW.md
  - The package still includes uboot/mkimage_all.sh for developers who modify
    config/uboot.env or *.cmd after extraction and want to regenerate *.scr.
    Regeneration requires UBOOT_SIGN_KEYDIR (GSRD-compatible FIT keys) and mkimage+dtc.
  - Prebuilt *.scr files are signed FIT images (sha256,rsa2048:dev), matching GSRD
    U-Boot CONFIG_BOOTSCR_FIT_SIGNATURE. Legacy mkimage -T script images are rejected.

Package layout:
  test-suite          Main Linux runner
  ts                  Short launcher
  config/             Customer-editable Linux and U-Boot defaults
  tests/              Packaged Linux solution scripts
  uboot/              Packaged U-Boot command scripts and optional .scr images
  assets/             Packaged supporting assets
  logs/               Runtime logs
  manifest.tsv        Packaged Linux test metadata
  uboot_manifest.tsv  Packaged U-Boot script metadata
  metadata.env        Package metadata
