#!/usr/bin/env bash
# Regenerate signed FIT *.scr images after editing *.cmd or config/uboot.env.
# Requires the same GSRD-compatible signing keys used at package build time.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
MKIMAGE_BIN="${MKIMAGE:-mkimage}"
KEYDIR="${UBOOT_SIGN_KEYDIR:-}"
KEYNAME="${UBOOT_SIGN_KEYNAME:-dev}"
ITS_PATH="${UBOOT_SCRIPT_ITS:-$SCRIPT_DIR/fit/uboot_script.its}"

if [[ "$MKIMAGE_BIN" == */* ]]; then
  [[ -x "$MKIMAGE_BIN" ]] || { echo "mkimage not executable: $MKIMAGE_BIN" >&2; exit 1; }
else
  command -v "$MKIMAGE_BIN" >/dev/null 2>&1 || {
    echo "mkimage not found. Install u-boot-tools or set MKIMAGE=/path/to/mkimage." >&2
    exit 1
  }
  MKIMAGE_BIN="$(command -v "$MKIMAGE_BIN")"
fi

# FIT signing needs dtc beside mkimage (ARC U-Boot tooltrees).
export PATH="$(cd "$(dirname "$MKIMAGE_BIN")" && pwd):$PATH"
command -v dtc >/dev/null 2>&1 || {
  echo "dtc not found on PATH (required for FIT mkimage)." >&2
  exit 1
}

if [[ -z "$KEYDIR" ]]; then
  echo "Set UBOOT_SIGN_KEYDIR to a directory containing ${KEYNAME}.key and ${KEYNAME}.crt" >&2
  exit 1
fi
[[ -f "$KEYDIR/${KEYNAME}.key" && -f "$KEYDIR/${KEYNAME}.crt" ]] || {
  echo "Signing keys not found under: $KEYDIR" >&2
  exit 1
}
[[ -f "$ITS_PATH" ]] || {
  echo "FIT ITS template not found: $ITS_PATH" >&2
  exit 1
}

sign_one() {
  local input="$1"
  local output="$2"
  local tmp
  tmp="$(mktemp -d)"
  cp "$input" "$tmp/script.txt"
  sed "s/key-name-hint = \"[^\"]*\"/key-name-hint = \"${KEYNAME}\"/" \
    "$ITS_PATH" > "$tmp/uboot_script.its"
  (
    cd "$tmp"
    "$MKIMAGE_BIN" -f uboot_script.its -k "$KEYDIR" -r "$output"
  ) >/dev/null
  rm -rf "$tmp"
  [[ -s "$output" ]] || { echo "Generated .scr is missing or empty: $output" >&2; exit 1; }
}

if [[ -f "$ROOT_DIR/config/uboot.env" ]]; then
  sign_one "$ROOT_DIR/config/uboot.env" "$ROOT_DIR/config/uboot.scr"
  echo "Generated config/uboot.scr (signed FIT)"
fi

find "$SCRIPT_DIR" -name '*.cmd' -type f | sort | while read -r cmd; do
  scr="${cmd%.cmd}.scr"
  sign_one "$cmd" "$scr"
  echo "Generated ${scr#$ROOT_DIR/} (signed FIT)"
done
