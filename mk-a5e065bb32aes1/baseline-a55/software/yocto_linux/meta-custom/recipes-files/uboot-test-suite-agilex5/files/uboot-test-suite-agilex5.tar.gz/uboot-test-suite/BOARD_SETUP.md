# Board Setup Notes

## Common Linux setup

Run the package from the extracted directory on the target board. Most tests assume root access because embedded board bring-up commonly requires `/sys`, `/proc`, block-device, or driver access.

```bash
./ts config check
./ts doctor
```

## Network

Edit `config/testsuite.conf` or override variables at runtime:

```bash
NET_IFACE=eth0
PEER_IP=192.168.9.100
LOCAL_IP=192.168.9.10
```

## Storage and destructive media tests

Confirm device names before enabling any write or erase flow. QSPI, MMC, USB write, RSU, reset, and FPGA state-changing tests may change board state. Keep a recovery path ready.

## USB

Set `usb=y` only when the required USB setup is connected. Keep `USB_MOUNT_RW=0` unless write testing to disposable USB media is intended.

## I2C/I3C/SPI/GPIO/UART

Set the bus, device, pin, or loopback configuration to match the actual board image and attached device. Keep peripheral lab flags disabled until the hardware setup is present.

## U-Boot

See UBOOT_QUICK_START.md. U-Boot destructive tests require setenv uboot_allow_destructive 1 and recovery access.
