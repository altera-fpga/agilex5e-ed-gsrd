# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/rsu_load_factory/test_steps.pl
echo "[uboot-rsu-load-factory] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] dcache off"
  if dcache off; then
    echo "[OK] dcache off"
  else
    echo "[FAIL] command failed: dcache off"
    exit 1
  fi
  echo "[cmd] rsu slot_load_factory"
  echo "[INFO] RSU command may reboot the board; script fails if it returns"
  rsu slot_load_factory
  echo "[FAIL] RSU command returned unexpectedly"
  exit 1
  echo "[cmd] dcache off"
  if dcache off; then
    echo "[OK] dcache off"
  else
    echo "[FAIL] command failed: dcache off"
    exit 1
  fi
  echo "[cmd] rsu check_running_factory"
  if rsu check_running_factory; then
    echo "[OK] rsu check_running_factory"
  else
    echo "[FAIL] command failed: rsu check_running_factory"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
