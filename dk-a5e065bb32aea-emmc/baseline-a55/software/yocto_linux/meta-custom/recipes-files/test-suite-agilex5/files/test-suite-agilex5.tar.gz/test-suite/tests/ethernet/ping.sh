#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: networking/linux/basic_ethernet/test_steps.sh
# Safety tags: smoke,network
# Review './ts info ethernet/ping' for setup, pass criteria, and recovery notes.
# Basic Ethernet ping test – shell port of networking/linux/basic_ethernet/test_steps.pl
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="ping-test"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

if [ "${1:-}" = "--desc" ]; then
  echo "Ping peer and verify 0% packet loss."
  exit 0
fi

if [ "${1:-}" = "--help" ] || [ "${1:-}" = "-h" ]; then
  cat <<'EOF'
Usage:
  test_steps.sh [peer-ip]

Examples:
  test_steps.sh 192.168.9.100
  PEER_IP=192.168.9.100 test_steps.sh
EOF
  exit 0
fi

: "${NET_IFACE:=eth0}"
: "${DEFAULT_STATIC_PEER:=192.168.9.100}"
: "${TARGET:=BOARD}"
: "${PING_TIMEOUT_SEC:=3}"


ts_log "Dumping network configuration (Perl flow: ifconfig)"
if command -v ifconfig >/dev/null 2>&1; then
  ifconfig
else
  ip addr show
fi
ip -4 addr show "$NET_IFACE" || ts_fail "Interface $NET_IFACE not found"

get_ipv4_addr() {
    local iface="$1"
    ip -4 addr show "$iface" | awk '/inet / { print $2 }' | head -n1 | cut -d/ -f1
}

IPV4_ADDR="$(get_ipv4_addr "$NET_IFACE" || true)"
if [ -z "${IPV4_ADDR:-}" ]; then
    ts_fail "Failed to parse IPv4 address for $NET_IFACE"
fi
ts_log "Detected IPv4 address on $NET_IFACE: $IPV4_ADDR"

USER_PEER_IP="${1:-}"
: "${PEER_IP:=}"

ETILE_SOURCE_IP=""
if [ -n "$USER_PEER_IP" ]; then
    ETILE_SOURCE_IP="$USER_PEER_IP"
elif [ -n "$PEER_IP" ]; then
    ETILE_SOURCE_IP="$PEER_IP"
else
    ETILE_SOURCE_IP="$DEFAULT_STATIC_PEER"
fi

ts_log "Pinging $ETILE_SOURCE_IP with timeout ${PING_TIMEOUT_SEC}s..."
PING_OUTPUT="$(ping "$ETILE_SOURCE_IP" -w "$PING_TIMEOUT_SEC" || true)"

echo "---------- ping output begin ----------"
echo "$PING_OUTPUT"
echo "---------- ping output end   ----------"

parse_packet_loss() {
    awk '
        /packet loss/ {
            for (i = 1; i <= NF; ++i) {
                if ($i ~ /%$/) {
                    gsub(/%/,"",$i);
                    print $i;
                    exit 0;
                }
            }
        }
    '
}

PACKET_LOSS="$(printf '%s
' "$PING_OUTPUT" | parse_packet_loss || echo "")"
if [ -z "$PACKET_LOSS" ]; then
    ts_fail "Unable to parse packet loss from ping output – assuming failure"
fi

ts_log "Packet loss: ${PACKET_LOSS}%"
if ! [[ "$PACKET_LOSS" =~ ^[0-9]+$ ]]; then
    ts_fail "Packet loss is not an integer: $PACKET_LOSS"
fi
if [ "$PACKET_LOSS" -gt 0 ]; then
    ts_fail "Ping test FAILED (${PACKET_LOSS}% packet loss)"
fi

ts_pass "Ping test PASSED (0% packet loss)"
exit 0
