# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_sw/uboot/rsu_not_cpb/test_steps.pl
echo "[uboot-rsu-not-cpb] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] iminfo"
  if iminfo; then
    echo "[OK] iminfo"
  else
    echo "[FAIL] command failed: iminfo"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] sf probe"
  if sf probe; then
    echo "[OK] sf probe"
  else
    echo "[FAIL] command failed: sf probe"
    exit 1
  fi
  echo "[cmd] sf update $loadaddr $address $filesize"
  if sf update $loadaddr $address $filesize; then
    echo "[OK] sf update $loadaddr $address $filesize"
  else
    echo "[FAIL] command failed: sf update $loadaddr $address $filesize"
    exit 1
  fi
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
