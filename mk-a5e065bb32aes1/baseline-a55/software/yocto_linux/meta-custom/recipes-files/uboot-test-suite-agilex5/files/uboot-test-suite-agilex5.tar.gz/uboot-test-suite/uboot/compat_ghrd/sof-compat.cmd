# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_ghrd/uboot/sof_compat/test_steps.pl
echo "[uboot-sof-compat] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] setenv ethaddr $ENV{BOARD_EMAC_ADDR0}"
  setenv ethaddr $ENV{BOARD_EMAC_ADDR0}
  echo "[cmd] setenv ethaddr1 $ENV{BOARD_EMAC_ADDR1}"
  setenv ethaddr1 $ENV{BOARD_EMAC_ADDR1}
  echo "[cmd] setenv ethaddr2 $ENV{BOARD_EMAC_ADDR2}"
  setenv ethaddr2 $ENV{BOARD_EMAC_ADDR2}
  echo "[cmd] dhcp"
  if dhcp; then
    echo "[OK] dhcp"
  else
    echo "[FAIL] command failed: dhcp"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] fpga load 0 $loadaddr $filesize"
  if fpga load 0 $loadaddr $filesize; then
    echo "[OK] fpga load 0 $loadaddr $filesize"
  else
    echo "[FAIL] command failed: fpga load 0 $loadaddr $filesize"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
