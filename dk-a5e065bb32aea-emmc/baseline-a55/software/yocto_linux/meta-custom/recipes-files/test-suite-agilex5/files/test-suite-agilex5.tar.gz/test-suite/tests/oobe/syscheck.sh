#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: oobe/linux/syscheck/test_steps.sh
# Safety tags: oobe,opt-in
# Review './ts info oobe/syscheck' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="syscheck"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Run a lightweight out-of-box system information check."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh

Checks kernel identity plus at least one of CPU, memory, block, or network probes.
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

checks_ok=0

ts_log "Kernel"
kernel_out=""
ts_capture kernel_out uname -a || ts_fail "uname failed"
printf '%s\n' "$kernel_out"
ts_assert_grep '.' "$kernel_out" "uname output was empty"
checks_ok=$((checks_ok + 1))

ts_log "CPU"
cpu_out=""
if ts_capture cpu_out sh -c "grep -E 'model name|Hardware|Processor|BogoMIPS' /proc/cpuinfo | head -20"; then
  printf '%s\n' "$cpu_out"
  [[ -n "${cpu_out// }" ]] && checks_ok=$((checks_ok + 1))
else
  ts_log "WARN: unable to read /proc/cpuinfo"
fi

ts_log "Memory"
mem_out=""
if ts_capture mem_out free -h; then
  printf '%s\n' "$mem_out"
  [[ -n "${mem_out// }" ]] && checks_ok=$((checks_ok + 1))
else
  ts_log "WARN: free failed"
fi

ts_log "Block devices"
blk_out=""
if ts_capture blk_out lsblk; then
  printf '%s\n' "$blk_out"
  [[ -n "${blk_out// }" ]] && checks_ok=$((checks_ok + 1))
else
  ts_log "WARN: lsblk failed"
fi

ts_log "Network"
net_out=""
if ts_capture net_out ip addr; then
  printf '%s\n' "$net_out"
  [[ -n "${net_out// }" ]] && checks_ok=$((checks_ok + 1))
else
  ts_log "WARN: ip addr failed"
fi

# Require kernel plus at least one platform probe to succeed.
[[ "$checks_ok" -ge 2 ]] || ts_fail "insufficient system information collected (ok=$checks_ok, ts_need >=2 checks)"
ts_pass "system check completed ($checks_ok probes succeeded)"
