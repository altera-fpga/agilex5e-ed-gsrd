# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_rsu/uboot/dcmf_acmf_compatibility_error/test_steps.pl
echo "[uboot-dcmf-acmf-compatibility-error] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] setenv autoload no"
  setenv autoload no
  echo "[cmd] dhcp"
  if dhcp; then
    echo "[OK] dhcp"
  else
    echo "[FAIL] command failed: dhcp"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] fatwrite mmc 0:1 $loadaddr $uboot_itb $filesize"
  if fatwrite mmc 0:1 $loadaddr $uboot_itb $filesize; then
    echo "[OK] fatwrite mmc 0:1 $loadaddr $uboot_itb $filesize"
  else
    echo "[FAIL] command failed: fatwrite mmc 0:1 $loadaddr $uboot_itb $filesize"
    exit 1
  fi
  echo "[cmd] fatls mmc 0:1"
  if fatls mmc 0:1; then
    echo "[OK] fatls mmc 0:1"
  else
    echo "[FAIL] command failed: fatls mmc 0:1"
    exit 1
  fi
  echo "[cmd] fatload mmc 0:1 $loadaddr $uboot_itb"
  if fatload mmc 0:1 $loadaddr $uboot_itb; then
    echo "[OK] fatload mmc 0:1 $loadaddr $uboot_itb"
  else
    echo "[FAIL] command failed: fatload mmc 0:1 $loadaddr $uboot_itb"
    exit 1
  fi
  echo "[cmd] iminfo"
  if iminfo; then
    echo "[OK] iminfo"
  else
    echo "[FAIL] command failed: iminfo"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] fatwrite mmc 0:1 $loadaddr $rpd_file $filesize"
  if fatwrite mmc 0:1 $loadaddr $rpd_file $filesize; then
    echo "[OK] fatwrite mmc 0:1 $loadaddr $rpd_file $filesize"
  else
    echo "[FAIL] command failed: fatwrite mmc 0:1 $loadaddr $rpd_file $filesize"
    exit 1
  fi
  echo "[cmd] fatls mmc 0\:1"
  if fatls mmc 0\:1; then
    echo "[OK] fatls mmc 0\:1"
  else
    echo "[FAIL] command failed: fatls mmc 0\:1"
    exit 1
  fi
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[cmd] sf probe"
  if sf probe; then
    echo "[OK] sf probe"
  else
    echo "[FAIL] command failed: sf probe"
    exit 1
  fi
  echo "[cmd] sf erase 0 +200000"
  if sf erase 0 +200000; then
    echo "[OK] sf erase 0 +200000"
  else
    echo "[FAIL] command failed: sf erase 0 +200000"
    exit 1
  fi
  echo "[cmd] fatload mmc 0 $loadaddr $file"
  if fatload mmc 0 $loadaddr $file; then
    echo "[OK] fatload mmc 0 $loadaddr $file"
  else
    echo "[FAIL] command failed: fatload mmc 0 $loadaddr $file"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] sf probe"
  if sf probe; then
    echo "[OK] sf probe"
  else
    echo "[FAIL] command failed: sf probe"
    exit 1
  fi
  echo "[cmd] sf update $loadaddr $address $filesize"
  if sf update $loadaddr $address $filesize; then
    echo "[OK] sf update $loadaddr $address $filesize"
  else
    echo "[FAIL] command failed: sf update $loadaddr $address $filesize"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
