# emb-test-suite test-suite package

Platform: agilex5  
Version: 2026.09.14  
Build type: release  
Built UTC: 2026-09-14T06:47:38Z

This package is a customer-facing HPS validation and bring-up test-suite. It is intended for devkit smoke, OOBE, and guided peripheral checks after Linux boots. It is not a replacement for internal farm, Simics, Xen, or full regression orchestration.

## Linux quick start

    ./ts help
    ./ts config check
    ./ts doctor
    ./ts list
    ./ts quick
    ./ts info ethernet/ping
    ./ts run ethernet/ping

## Safety model

./ts all and ./ts quick skip manual, multiboard, and destructive tests unless explicitly requested. Destructive Linux tests require both:

    TESTSUITE_ALLOW_DESTRUCTIVE=1 ./ts run <category/test> --yes

## Package documents

- QUICK_START.md - Linux first-use flow.
- BOARD_SETUP.md - network, storage, USB, I2C, I3C, SPI, GPIO, and destructive setup notes.
- KNOWN_LIMITATIONS.md - customer-use scope and known limitations.
- RELEASE_NOTES.md - package metadata and release-readiness notes.
- UBOOT_QUICK_START.md - U-Boot script loading and safety flow.
- UBOOT_INDEX.tsv - U-Boot command-script index.

## Useful commands

    ./ts config show
    ./ts config check
    ./ts list --verbose
    ./ts info <category/test>
    ./ts doctor <category/test>
    ./ts quick
    ./ts all
