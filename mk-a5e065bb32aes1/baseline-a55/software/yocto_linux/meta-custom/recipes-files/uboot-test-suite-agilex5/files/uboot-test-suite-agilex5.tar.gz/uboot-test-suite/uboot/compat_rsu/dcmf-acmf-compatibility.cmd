# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_rsu/uboot/dcmf_acmf_compatibility/test_steps.pl
echo "[uboot-dcmf-acmf-compatibility] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] setenv autoload no"
  setenv autoload no
  echo "[cmd] dhcp"
  if dhcp; then
    echo "[OK] dhcp"
  else
    echo "[FAIL] command failed: dhcp"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] fatwrite mmc 0:1 $loadaddr $uboot_itb $filesize"
  if fatwrite mmc 0:1 $loadaddr $uboot_itb $filesize; then
    echo "[OK] fatwrite mmc 0:1 $loadaddr $uboot_itb $filesize"
  else
    echo "[FAIL] command failed: fatwrite mmc 0:1 $loadaddr $uboot_itb $filesize"
    exit 1
  fi
  echo "[cmd] fatls mmc 0:1"
  if fatls mmc 0:1; then
    echo "[OK] fatls mmc 0:1"
  else
    echo "[FAIL] command failed: fatls mmc 0:1"
    exit 1
  fi
  echo "[cmd] fatload mmc 0:1 $loadaddr $uboot_itb"
  if fatload mmc 0:1 $loadaddr $uboot_itb; then
    echo "[OK] fatload mmc 0:1 $loadaddr $uboot_itb"
  else
    echo "[FAIL] command failed: fatload mmc 0:1 $loadaddr $uboot_itb"
    exit 1
  fi
  echo "[cmd] iminfo"
  if iminfo; then
    echo "[OK] iminfo"
  else
    echo "[FAIL] command failed: iminfo"
    exit 1
  fi
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[cmd] sf probe"
  if sf probe; then
    echo "[OK] sf probe"
  else
    echo "[FAIL] command failed: sf probe"
    exit 1
  fi
  echo "[cmd] setenv autoload no"
  setenv autoload no
  echo "[cmd] dhcp"
  if dhcp; then
    echo "[OK] dhcp"
  else
    echo "[FAIL] command failed: dhcp"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] sf probe"
  if sf probe; then
    echo "[OK] sf probe"
  else
    echo "[FAIL] command failed: sf probe"
    exit 1
  fi
  echo "[cmd] sf update $loadaddr $rpd_offset_string $filesize"
  if sf update $loadaddr $rpd_offset_string $filesize; then
    echo "[OK] sf update $loadaddr $rpd_offset_string $filesize"
  else
    echo "[FAIL] command failed: sf update $loadaddr $rpd_offset_string $filesize"
    exit 1
  fi
  echo "[cmd] sf read $loadaddr 0 100"
  if sf read $loadaddr 0 100; then
    echo "[OK] sf read $loadaddr 0 100"
  else
    echo "[FAIL] command failed: sf read $loadaddr 0 100"
    exit 1
  fi
  echo "[cmd] md $loadaddr 100"
  if md $loadaddr 100; then
    echo "[OK] md $loadaddr 100"
  else
    echo "[FAIL] command failed: md $loadaddr 100"
    exit 1
  fi
  echo "[cmd] sf read $loadaddr 80000 100"
  if sf read $loadaddr 80000 100; then
    echo "[OK] sf read $loadaddr 80000 100"
  else
    echo "[FAIL] command failed: sf read $loadaddr 80000 100"
    exit 1
  fi
  echo "[cmd] md $loadaddr 100"
  if md $loadaddr 100; then
    echo "[OK] md $loadaddr 100"
  else
    echo "[FAIL] command failed: md $loadaddr 100"
    exit 1
  fi
  echo "[cmd] sf read $loadaddr 100000 100"
  if sf read $loadaddr 100000 100; then
    echo "[OK] sf read $loadaddr 100000 100"
  else
    echo "[FAIL] command failed: sf read $loadaddr 100000 100"
    exit 1
  fi
  echo "[cmd] md $loadaddr 100"
  if md $loadaddr 100; then
    echo "[OK] md $loadaddr 100"
  else
    echo "[FAIL] command failed: md $loadaddr 100"
    exit 1
  fi
  echo "[cmd] sf read $loadaddr 200000 100"
  if sf read $loadaddr 200000 100; then
    echo "[OK] sf read $loadaddr 200000 100"
  else
    echo "[FAIL] command failed: sf read $loadaddr 200000 100"
    exit 1
  fi
  echo "[cmd] md $loadaddr 100"
  if md $loadaddr 100; then
    echo "[OK] md $loadaddr 100"
  else
    echo "[FAIL] command failed: md $loadaddr 100"
    exit 1
  fi
  echo "[cmd] rsu slot_erase 1"
  if rsu slot_erase 1; then
    echo "[OK] rsu slot_erase 1"
  else
    echo "[FAIL] command failed: rsu slot_erase 1"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] rsu slot_program_buf 1 $loadaddr $filesize"
  if rsu slot_program_buf 1 $loadaddr $filesize; then
    echo "[OK] rsu slot_program_buf 1 $loadaddr $filesize"
  else
    echo "[FAIL] command failed: rsu slot_program_buf 1 $loadaddr $filesize"
    exit 1
  fi
  echo "[cmd] rsu slot_verify_buf 1 $loadaddr $filesize"
  if rsu slot_verify_buf 1 $loadaddr $filesize; then
    echo "[OK] rsu slot_verify_buf 1 $loadaddr $filesize"
  else
    echo "[FAIL] command failed: rsu slot_verify_buf 1 $loadaddr $filesize"
    exit 1
  fi
  echo "[cmd] rsu slot_get_info 1"
  if rsu slot_get_info 1; then
    echo "[OK] rsu slot_get_info 1"
  else
    echo "[FAIL] command failed: rsu slot_get_info 1"
    exit 1
  fi
  echo "[cmd] rsu status_log"
  if rsu status_log; then
    echo "[OK] rsu status_log"
  else
    echo "[FAIL] command failed: rsu status_log"
    exit 1
  fi
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
