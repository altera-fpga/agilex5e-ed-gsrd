# Known Limitations

- This package is optimized for customer/devkit bring-up and smoke validation.
- Simics, internal farm orchestration, Xen, and host-side regression behavior are intentionally out of scope for this customer package.
- Some packaged scripts are productized smoke flows derived from validation tests; they may use safer defaults than internal regression flows.
- Manual and multiboard tests require user setup and are skipped by default.
- Destructive tests require explicit opt-in and may still require board-specific recovery planning.
- Tool availability depends on the target Linux image. Use `./ts doctor` to identify missing commands.
