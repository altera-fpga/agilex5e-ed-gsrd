# Release Notes

Package: emb-test-suite  
Version: 2026.09.14  
Platform: agilex5  
Build type: release  
Built UTC: 2026-09-14T06:47:29Z  
Source commit: 57e34d80078b  
Linux manifest SHA256: 3c725d5b7e235372b291a9bb41f1aecdfd63d946f4d7296aaf5eaf65f42018f9  
Linux config SHA256: 5db3393d955cf08b7066bb6ac87ca11499e56b94a5da115e76fde91937da24a7  
U-Boot manifest SHA256: none  
U-Boot config SHA256: none

## Release scope

This release contains customer-facing Linux and/or U-Boot test-suite assets for devkit bring-up and guided validation. It excludes internal Simics/farm/Xen orchestration.

## Safety

Manual, multiboard, and destructive tests are not run by default. Linux destructive tests require TESTSUITE_ALLOW_DESTRUCTIVE=1 and --yes. U-Boot destructive tests require setenv uboot_allow_destructive 1.
