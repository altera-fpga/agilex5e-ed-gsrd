# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
echo "[uboot-sdram] Start mtest memory test"

if test -z "${uboot_mtest_start}"; then setenv uboot_mtest_start 0x80200000; fi
if test -z "${uboot_mtest_end}"; then setenv uboot_mtest_end 0x80300000; fi
if test -z "${uboot_mtest_pattern}"; then setenv uboot_mtest_pattern 0xa5a5a5a5; fi
if test -z "${uboot_mtest_iterations}"; then setenv uboot_mtest_iterations 1; fi

echo "[uboot-sdram] range ${uboot_mtest_start}..${uboot_mtest_end} pattern ${uboot_mtest_pattern} iterations ${uboot_mtest_iterations}"
if mtest ${uboot_mtest_start} ${uboot_mtest_end} ${uboot_mtest_pattern} ${uboot_mtest_iterations}; then
  echo "[PASS] U-Boot mtest passed"
else
  echo "[FAIL] U-Boot mtest failed"
  exit 1
fi
