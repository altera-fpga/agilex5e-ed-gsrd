# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/rsu_corrupt_app_image_fallback/test_steps.pl
echo "[uboot-rsu-corrupt-app-image-fallback] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] dcache off"
  if dcache off; then
    echo "[OK] dcache off"
  else
    echo "[FAIL] command failed: dcache off"
    exit 1
  fi
  echo "[cmd] sf probe"
  if sf probe; then
    echo "[OK] sf probe"
  else
    echo "[FAIL] command failed: sf probe"
    exit 1
  fi
  echo "[cmd] sf erase ${start_addr_from_map} +20"
  if sf erase ${start_addr_from_map} +20; then
    echo "[OK] sf erase ${start_addr_from_map} +20"
  else
    echo "[FAIL] command failed: sf erase ${start_addr_from_map} +20"
    exit 1
  fi
  echo "[cmd] flash erase qspi\@ff8d2000 ${start_addr_from_map} 1"
  if flash erase qspi\@ff8d2000 ${start_addr_from_map} 1; then
    echo "[OK] flash erase qspi\@ff8d2000 ${start_addr_from_map} 1"
  else
    echo "[FAIL] command failed: flash erase qspi\@ff8d2000 ${start_addr_from_map} 1"
    exit 1
  fi
  echo "[cmd] rsu check_running_factory"
  if rsu check_running_factory; then
    echo "[OK] rsu check_running_factory"
  else
    echo "[FAIL] command failed: rsu check_running_factory"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
