# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from reset/uboot/watchdog_warm_reset/test_steps.pl
echo "[uboot-watchdog-warm-reset] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] mw.l 0xffd00204 0x11"
  if mw.l 0xffd00204 0x11; then
    echo "[OK] mw.l 0xffd00204 0x11"
  else
    echo "[FAIL] command failed: mw.l 0xffd00204 0x11"
    exit 1
  fi
  echo "[cmd] mw ffd00200 1"
  if mw ffd00200 1; then
    echo "[OK] mw ffd00200 1"
  else
    echo "[FAIL] command failed: mw ffd00200 1"
    exit 1
  fi
  echo "[cmd] wdt list"
  if wdt list; then
    echo "[OK] wdt list"
  else
    echo "[FAIL] command failed: wdt list"
    exit 1
  fi
  echo "[cmd] wdt dev watchdog\@907${i}000"
  if wdt dev watchdog\@907${i}000; then
    echo "[OK] wdt dev watchdog\@907${i}000"
  else
    echo "[FAIL] command failed: wdt dev watchdog\@907${i}000"
    exit 1
  fi
  echo "[cmd] wdt dev"
  if wdt dev; then
    echo "[OK] wdt dev"
  else
    echo "[FAIL] command failed: wdt dev"
    exit 1
  fi
  echo "[cmd] wdt start 200"
  if wdt start 200; then
    echo "[OK] wdt start 200"
  else
    echo "[FAIL] command failed: wdt start 200"
    exit 1
  fi
  echo "[cmd] wdt stop"
  if wdt stop; then
    echo "[OK] wdt stop"
  else
    echo "[FAIL] command failed: wdt stop"
    exit 1
  fi
  echo "[cmd] wdt start 100"
  if wdt start 100; then
    echo "[OK] wdt start 100"
  else
    echo "[FAIL] command failed: wdt start 100"
    exit 1
  fi
  echo "[cmd] wdt dev watchdog\@10d00${i}00"
  if wdt dev watchdog\@10d00${i}00; then
    echo "[OK] wdt dev watchdog\@10d00${i}00"
  else
    echo "[FAIL] command failed: wdt dev watchdog\@10d00${i}00"
    exit 1
  fi
  echo "[cmd] wdt dev"
  if wdt dev; then
    echo "[OK] wdt dev"
  else
    echo "[FAIL] command failed: wdt dev"
    exit 1
  fi
  echo "[cmd] wdt start 200"
  if wdt start 200; then
    echo "[OK] wdt start 200"
  else
    echo "[FAIL] command failed: wdt start 200"
    exit 1
  fi
  echo "[cmd] wdt stop"
  if wdt stop; then
    echo "[OK] wdt stop"
  else
    echo "[FAIL] command failed: wdt stop"
    exit 1
  fi
  echo "[cmd] wdt start 100"
  if wdt start 100; then
    echo "[OK] wdt start 100"
  else
    echo "[FAIL] command failed: wdt start 100"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
