# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/rsu_qpds_compatibility/test_steps.pl
echo "[uboot-rsu-qpds-compatibility] Start generated command sequence"
  echo "[cmd] dcache off"
  if dcache off; then
    echo "[OK] dcache off"
  else
    echo "[FAIL] command failed: dcache off"
    exit 1
  fi
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
