# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_rsu/uboot/upgrade_compatibility_opt3_nconfig/test_steps.pl
echo "[uboot-upgrade-compatibility-opt3-nconfig] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] setenv autoload no"
  setenv autoload no
  echo "[cmd] dhcp"
  if dhcp; then
    echo "[OK] dhcp"
  else
    echo "[FAIL] command failed: dhcp"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] fatwrite mmc 0:1 $loadaddr $uboot_itb $filesize"
  if fatwrite mmc 0:1 $loadaddr $uboot_itb $filesize; then
    echo "[OK] fatwrite mmc 0:1 $loadaddr $uboot_itb $filesize"
  else
    echo "[FAIL] command failed: fatwrite mmc 0:1 $loadaddr $uboot_itb $filesize"
    exit 1
  fi
  echo "[cmd] fatls mmc 0:1"
  if fatls mmc 0:1; then
    echo "[OK] fatls mmc 0:1"
  else
    echo "[FAIL] command failed: fatls mmc 0:1"
    exit 1
  fi
  echo "[cmd] fatload mmc 0:1 $loadaddr $uboot_itb"
  if fatload mmc 0:1 $loadaddr $uboot_itb; then
    echo "[OK] fatload mmc 0:1 $loadaddr $uboot_itb"
  else
    echo "[FAIL] command failed: fatload mmc 0:1 $loadaddr $uboot_itb"
    exit 1
  fi
  echo "[cmd] iminfo"
  if iminfo; then
    echo "[OK] iminfo"
  else
    echo "[FAIL] command failed: iminfo"
    exit 1
  fi
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[cmd] setenv autoload no"
  setenv autoload no
  echo "[cmd] dhcp"
  if dhcp; then
    echo "[OK] dhcp"
  else
    echo "[FAIL] command failed: dhcp"
    exit 1
  fi
  echo "[cmd] sleep 5"
  if sleep 5; then
    echo "[OK] sleep 5"
  else
    echo "[FAIL] command failed: sleep 5"
    exit 1
  fi
  echo "[cmd] for i in 1 2 3; do; if test '${ipaddr}' = ''; then dhcp && sleep 5; fi; done"
  if for i in 1 2 3; do; if test '${ipaddr}' = ''; then dhcp && sleep 5; fi; done; then
    echo "[OK] for i in 1 2 3; do; if test '${ipaddr}' = ''; then dhcp && sleep 5; fi; done"
  else
    echo "[FAIL] command failed: for i in 1 2 3; do; if test '${ipaddr}' = ''; then dhcp && sleep 5; fi; done"
    exit 1
  fi
  echo "[cmd] sf probe"
  if sf probe; then
    echo "[OK] sf probe"
  else
    echo "[FAIL] command failed: sf probe"
    exit 1
  fi
  echo "[cmd] sf read $loadaddr 420 20"
  if sf read $loadaddr 420 20; then
    echo "[OK] sf read $loadaddr 420 20"
  else
    echo "[FAIL] command failed: sf read $loadaddr 420 20"
    exit 1
  fi
  echo "[cmd] md $loadaddr 20"
  if md $loadaddr 20; then
    echo "[OK] md $loadaddr 20"
  else
    echo "[FAIL] command failed: md $loadaddr 20"
    exit 1
  fi
  echo "[cmd] rsu slot_enable 1"
  if rsu slot_enable 1; then
    echo "[OK] rsu slot_enable 1"
  else
    echo "[FAIL] command failed: rsu slot_enable 1"
    exit 1
  fi
  echo "[cmd] rsu slot_get_info 1"
  if rsu slot_get_info 1; then
    echo "[OK] rsu slot_get_info 1"
  else
    echo "[FAIL] command failed: rsu slot_get_info 1"
    exit 1
  fi
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[cmd] sf probe"
  if sf probe; then
    echo "[OK] sf probe"
  else
    echo "[FAIL] command failed: sf probe"
    exit 1
  fi
  echo "[cmd] sf read $loadaddr 420 20"
  if sf read $loadaddr 420 20; then
    echo "[OK] sf read $loadaddr 420 20"
  else
    echo "[FAIL] command failed: sf read $loadaddr 420 20"
    exit 1
  fi
  echo "[cmd] md $loadaddr 20"
  if md $loadaddr 20; then
    echo "[OK] md $loadaddr 20"
  else
    echo "[FAIL] command failed: md $loadaddr 20"
    exit 1
  fi
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
