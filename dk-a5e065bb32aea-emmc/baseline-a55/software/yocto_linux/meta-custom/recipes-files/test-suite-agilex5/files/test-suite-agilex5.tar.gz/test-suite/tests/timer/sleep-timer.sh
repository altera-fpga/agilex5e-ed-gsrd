#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: timers/linux/sleep_timer/test_steps.sh
# Safety tags: timer,smoke
# Review './ts info timer/sleep-timer' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="sleep-timer"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Verify Linux sleep duration against a configurable tolerance."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh [seconds]

Environment:
  TIMER_SLEEP_SEC=5
  TIMER_TOLERANCE_MS=500
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${TIMER_SLEEP_SEC:=5}"
: "${TIMER_TOLERANCE_MS:=500}"
SLEEP_SEC="${1:-$TIMER_SLEEP_SEC}"


START_NS="$(date +%s%N)"
sleep "$SLEEP_SEC"
END_NS="$(date +%s%N)"
ELAPSED_MS=$(( (END_NS - START_NS) / 1000000 ))
EXPECTED_MS=$(( SLEEP_SEC * 1000 ))
LOW=$(( EXPECTED_MS - TIMER_TOLERANCE_MS ))
HIGH=$(( EXPECTED_MS + TIMER_TOLERANCE_MS ))

ts_log "Expected ${EXPECTED_MS} ms, measured ${ELAPSED_MS} ms, tolerance ±${TIMER_TOLERANCE_MS} ms"
if [[ "$ELAPSED_MS" -lt "$LOW" || "$ELAPSED_MS" -gt "$HIGH" ]]; then
  ts_fail "sleep duration outside tolerance"
fi
ts_pass "timer sleep duration is within tolerance"
