# Linux Quick Start

1. Boot Linux on the supported devkit image.
2. Extract the release `.zip` on the target board. Avoid copying `manifest.tsv` through terminals or editors that wrap long lines.
3. Review the active configuration:

```bash
./ts config show
./ts config check
```

4. Run pre-flight checks:

```bash
./ts doctor
```

5. Run the safe OOBE/smoke profile:

```bash
./ts quick
```

6. Inspect a specific test before running it:

```bash
./ts info ethernet/ping
./ts run ethernet/ping
```

7. Review logs under `logs/` after every run.

Destructive tests are not enabled by default. Run them only after reviewing the setup and recovery notes:

```bash
TESTSUITE_ALLOW_DESTRUCTIVE=1 ./ts run qspi/qspi-rw --yes
```
