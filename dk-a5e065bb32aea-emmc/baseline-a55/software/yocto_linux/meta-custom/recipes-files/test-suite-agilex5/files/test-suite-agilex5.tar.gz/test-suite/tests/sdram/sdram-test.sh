#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: sdram/linux/sdram_memtester/test_steps.sh
# Safety tags: sdram,memory,performance
# Review './ts info sdram/sdram-test' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="sdram-test"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Run memtester 2M 1 by default, matching sdram_memtester/test_steps.pl."

usage() {
  cat <<'EOF_USAGE'
Usage:
  test_steps.sh [size]

Environment:
  MEMTEST_SIZE=2M
  MEMTEST_LOOPS=1
  MEMTEST_MODE=auto      # auto|memtester|dd
  MEMTEST_BIN=memtester
  BOARD_NFS_SERVER_HOSTNAME=<server>  Optional TFTP fallback.
  BOARD_RESOURCE=<resource path>      Optional TFTP path.
EOF_USAGE
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${MEMTEST_SIZE:=2M}"
: "${MEMTEST_LOOPS:=1}"
: "${MEMTEST_MODE:=auto}"
: "${MEMTEST_BIN:=memtester}"
SIZE="${1:-$MEMTEST_SIZE}"

WORKDIR="$(ts_mktemp_dir)"
cleanup() { rm -rf "$WORKDIR"; [[ -n "${TMPFILE:-}" ]] && rm -f "$TMPFILE"; }
trap cleanup EXIT

ts_stage_assets "$WORKDIR"

ts_log "Memory summary"
free -h || true

resolve_memtester() {
  local bin="$MEMTEST_BIN" remote=""
  if [[ -x "$bin" ]]; then printf '%s\n' "$bin"; return; fi
  if command -v "$bin" >/dev/null 2>&1; then command -v "$bin"; return; fi
  if [[ -x "$WORKDIR/$(basename "$bin")" ]]; then printf '%s\n' "$WORKDIR/$(basename "$bin")"; return; fi
  if [[ -n "${BOARD_NFS_SERVER_HOSTNAME:-}" ]] && command -v tftp >/dev/null 2>&1; then
    remote="${BOARD_RESOURCE:+/${BOARD_RESOURCE}/}$(basename "$bin")"
    ts_log "Attempting Perl-compatible TFTP fetch: $remote from $BOARD_NFS_SERVER_HOSTNAME"
    if (cd "$WORKDIR" && tftp -g -r "$remote" "$BOARD_NFS_SERVER_HOSTNAME"); then
      chmod +x "$WORKDIR/$(basename "$bin")"
      printf '%s\n' "$WORKDIR/$(basename "$bin")"
      return
    fi
  fi
  return 1
}

if [[ "$MEMTEST_MODE" != "dd" ]] && memtester_path="$(resolve_memtester)"; then
  chmod +x "$memtester_path"
  output="$($memtester_path "$SIZE" "$MEMTEST_LOOPS" 2>&1)" || { printf '%s\n' "$output"; ts_fail "memtester failed"; }
  printf '%s\n' "$output"
  ts_assert_grep 'Done\.' "$output" "memtester did not report Done."
  ts_pass "memtester $SIZE $MEMTEST_LOOPS completed"
  exit 0
fi

ts_log "memtester not available; running dd RAM-backed fallback"
ts_need dd
ts_need awk
TEST_DIR="/dev/shm"
[[ -d "$TEST_DIR" ]] || TEST_DIR="/tmp"
TMPFILE="$(mktemp "$TEST_DIR/sdram-test.XXXXXX")"
COUNT_MB="${SDRAM_DD_MB:-128}"
ts_log "Running dd RAM-backed write/read test (${COUNT_MB} MiB)"
dd if=/dev/zero of="$TMPFILE" bs=1M count="$COUNT_MB" conv=fsync status=progress
dd if="$TMPFILE" of=/dev/null bs=1M status=progress
ts_pass "memory fallback test completed"
