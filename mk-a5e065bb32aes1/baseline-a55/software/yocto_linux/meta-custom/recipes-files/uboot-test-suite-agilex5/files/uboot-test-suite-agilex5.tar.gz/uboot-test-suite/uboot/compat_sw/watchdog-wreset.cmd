# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_sw/uboot/watchdog_wreset/test_steps.pl
echo "[uboot-watchdog-wreset] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] setexpr newaddr $loadaddr + 0x06000000"
  setexpr newaddr $loadaddr + 0x06000000
  echo "[cmd] mw 2000000 aaaaaaaa 1"
  if mw 2000000 aaaaaaaa 1; then
    echo "[OK] mw 2000000 aaaaaaaa 1"
  else
    echo "[FAIL] command failed: mw 2000000 aaaaaaaa 1"
    exit 1
  fi
  echo "[cmd] mw $loadaddr aaaaaaaa 1"
  if mw $loadaddr aaaaaaaa 1; then
    echo "[OK] mw $loadaddr aaaaaaaa 1"
  else
    echo "[FAIL] command failed: mw $loadaddr aaaaaaaa 1"
    exit 1
  fi
  echo "[cmd] md $loadaddr 4"
  if md $loadaddr 4; then
    echo "[OK] md $loadaddr 4"
  else
    echo "[FAIL] command failed: md $loadaddr 4"
    exit 1
  fi
  echo "[cmd] mw 8000000 aaaaaaaa 1"
  if mw 8000000 aaaaaaaa 1; then
    echo "[OK] mw 8000000 aaaaaaaa 1"
  else
    echo "[FAIL] command failed: mw 8000000 aaaaaaaa 1"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] wdt dev watchdog\@10d00200"
  if wdt dev watchdog\@10d00200; then
    echo "[OK] wdt dev watchdog\@10d00200"
  else
    echo "[FAIL] command failed: wdt dev watchdog\@10d00200"
    exit 1
  fi
  echo "[cmd] wdt dev"
  if wdt dev; then
    echo "[OK] wdt dev"
  else
    echo "[FAIL] command failed: wdt dev"
    exit 1
  fi
  echo "[cmd] wdt start 200"
  if wdt start 200; then
    echo "[OK] wdt start 200"
  else
    echo "[FAIL] command failed: wdt start 200"
    exit 1
  fi
  echo "[cmd] mw.l 0xffd00204 0x11"
  if mw.l 0xffd00204 0x11; then
    echo "[OK] mw.l 0xffd00204 0x11"
  else
    echo "[FAIL] command failed: mw.l 0xffd00204 0x11"
    exit 1
  fi
  echo "[cmd] mw ffd00200 1"
  if mw ffd00200 1; then
    echo "[OK] mw ffd00200 1"
  else
    echo "[FAIL] command failed: mw ffd00200 1"
    exit 1
  fi
  echo "[cmd] setexpr newaddr $loadaddr + 0x06000000"
  setexpr newaddr $loadaddr + 0x06000000
  echo "[cmd] md 2000000 4"
  if md 2000000 4; then
    echo "[OK] md 2000000 4"
  else
    echo "[FAIL] command failed: md 2000000 4"
    exit 1
  fi
  echo "[cmd] md $loadaddr 4"
  if md $loadaddr 4; then
    echo "[OK] md $loadaddr 4"
  else
    echo "[FAIL] command failed: md $loadaddr 4"
    exit 1
  fi
  echo "[cmd] md 8000000 4"
  if md 8000000 4; then
    echo "[OK] md 8000000 4"
  else
    echo "[FAIL] command failed: md 8000000 4"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
