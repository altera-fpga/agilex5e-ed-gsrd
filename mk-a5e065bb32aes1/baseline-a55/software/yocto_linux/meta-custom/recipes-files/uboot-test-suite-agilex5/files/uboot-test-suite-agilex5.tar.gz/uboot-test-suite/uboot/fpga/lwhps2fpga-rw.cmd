# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from fpga_bridge/uboot/lwhps2fpga_rw/test_steps.pl
echo "[uboot-lwhps2fpga-rw] Start generated command sequence"
  echo "[cmd] bridge enable"
  if bridge enable; then
    echo "[OK] bridge enable"
  else
    echo "[FAIL] command failed: bridge enable"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
