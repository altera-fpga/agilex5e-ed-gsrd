#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: sdmmc/linux/create_new_partition/test_steps.sh
# Safety tags: opt-in,destructive-op,board-state
# Review './ts info sdmmc/create-new-partition' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="create-new-partition"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Create partition 4 and verify mount/write, matching sdmmc/create_new_partition test_steps.pl."

usage() {
  cat <<'EOF_USAGE'
Usage:
  test_steps.sh [--yes] [block-device]

Environment:
  SDMMC_DEV=/dev/mmcblk0
  SDMMC_PARTITION_INDEX=4
  TESTSUITE_ALLOW_DESTRUCTIVE=1

This is destructive: it adds/recreates partition 4 using fdisk, formats it as
ext4, mounts it, creates abc.txt, verifies it, and unmounts it. The original
Perl flow reboots after fdisk; this shell flow uses partprobe/udevadm and tells
you to reboot manually only if the kernel cannot see the new partition.
EOF_USAGE
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

CONFIRMED=0
if [[ "${1:-}" == "--yes" ]]; then CONFIRMED=1; shift; fi

: "${SDMMC_DEV:=/dev/mmcblk0}"
: "${SDMMC_PARTITION_INDEX:=4}"
DEV="${1:-$SDMMC_DEV}"
BASE="$(basename "$DEV")"
PART="/dev/${BASE}p${SDMMC_PARTITION_INDEX}"
MNT="/mnt/${BASE}_p${SDMMC_PARTITION_INDEX}"

ts_require_root
ts_require_destructive "$CONFIRMED"
ts_need fdisk
ts_need mkfs.ext4
ts_need mount
ts_need umount
ts_need touch
[[ -b "$DEV" ]] || ts_fail "block device not found: $DEV"

ts_log "Detected MMC devices"
ls /dev/mmcblk* 2>/dev/null || true

ts_log "Creating partition ${SDMMC_PARTITION_INDEX} on $DEV using Perl fdisk script"
printf "n\np\n${SDMMC_PARTITION_INDEX}\n\n\np\nw\n" | fdisk "$DEV" || ts_fail "fdisk failed"
partprobe "$DEV" 2>/dev/null || true
udevadm settle 2>/dev/null || true
sleep 2
[[ -b "$PART" ]] || ts_fail "$PART not visible after fdisk; reboot the board then rerun with existing partition"

ts_run "mkfs.ext4 $PART" mkfs.ext4 -F "$PART"
mkdir -p "$MNT"
ts_run "mount $PART $MNT" mount "$PART" "$MNT"
(
  cd "$MNT"
  ts_run "touch abc.txt" touch abc.txt
  [[ -e abc.txt ]] || ts_fail "abc.txt not created"
  ls abc.txt
)
cd /
ts_run "umount $MNT" umount "$MNT"
ts_pass "create-new-partition flow completed"
