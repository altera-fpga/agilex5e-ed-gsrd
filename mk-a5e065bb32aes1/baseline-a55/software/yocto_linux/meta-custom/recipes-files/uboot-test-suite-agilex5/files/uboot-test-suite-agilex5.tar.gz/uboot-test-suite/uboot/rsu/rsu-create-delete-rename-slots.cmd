# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/rsu_create_delete_rename_slots/test_steps.pl
echo "[uboot-rsu-create-delete-rename-slots] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] setenv autoload no"
  setenv autoload no
  echo "[cmd] printenv"
  if printenv; then
    echo "[OK] printenv"
  else
    echo "[FAIL] command failed: printenv"
    exit 1
  fi
  echo "[cmd] setenv ethaddr 00:df:00:33:56:00"
  setenv ethaddr 00:df:00:33:56:00
  echo "[cmd] dhcp"
  if dhcp; then
    echo "[OK] dhcp"
  else
    echo "[FAIL] command failed: dhcp"
    exit 1
  fi
  echo "[cmd] dcache off"
  if dcache off; then
    echo "[OK] dcache off"
  else
    echo "[FAIL] command failed: dcache off"
    exit 1
  fi
  echo "[cmd] rsu slot_delete ${p5_slot_id}"
  if rsu slot_delete ${p5_slot_id}; then
    echo "[OK] rsu slot_delete ${p5_slot_id}"
  else
    echo "[FAIL] command failed: rsu slot_delete ${p5_slot_id}"
    exit 1
  fi
  echo "[cmd] rsu slot_by_name ${partition}"
  if rsu slot_by_name ${partition}; then
    echo "[OK] rsu slot_by_name ${partition}"
  else
    echo "[FAIL] command failed: rsu slot_by_name ${partition}"
    exit 1
  fi
  echo "[cmd] rsu slot_create ${partition} 1900000 500000"
  if rsu slot_create ${partition} 1900000 500000; then
    echo "[OK] rsu slot_create ${partition} 1900000 500000"
  else
    echo "[FAIL] command failed: rsu slot_create ${partition} 1900000 500000"
    exit 1
  fi
  echo "[cmd] rsu slot_program_buf ${p5_slot_id} $loadaddr $filesize"
  if rsu slot_program_buf ${p5_slot_id} $loadaddr $filesize; then
    echo "[OK] rsu slot_program_buf ${p5_slot_id} $loadaddr $filesize"
  else
    echo "[FAIL] command failed: rsu slot_program_buf ${p5_slot_id} $loadaddr $filesize"
    exit 1
  fi
  echo "[cmd] rsu slot_get_info ${p5_slot_id}"
  if rsu slot_get_info ${p5_slot_id}; then
    echo "[OK] rsu slot_get_info ${p5_slot_id}"
  else
    echo "[FAIL] command failed: rsu slot_get_info ${p5_slot_id}"
    exit 1
  fi
  echo "[cmd] rsu slot_enable ${p5_slot_id}"
  if rsu slot_enable ${p5_slot_id}; then
    echo "[OK] rsu slot_enable ${p5_slot_id}"
  else
    echo "[FAIL] command failed: rsu slot_enable ${p5_slot_id}"
    exit 1
  fi
  echo "[cmd] dcache off"
  if dcache off; then
    echo "[OK] dcache off"
  else
    echo "[FAIL] command failed: dcache off"
    exit 1
  fi
  echo "[cmd] rsu slot_rename 11 ${new_partition_name}"
  if rsu slot_rename 11 ${new_partition_name}; then
    echo "[OK] rsu slot_rename 11 ${new_partition_name}"
  else
    echo "[FAIL] command failed: rsu slot_rename 11 ${new_partition_name}"
    exit 1
  fi
  echo "[cmd] rsu slot_rename 5 SSBL.P7"
  if rsu slot_rename 5 SSBL.P7; then
    echo "[OK] rsu slot_rename 5 SSBL.P7"
  else
    echo "[FAIL] command failed: rsu slot_rename 5 SSBL.P7"
    exit 1
  fi
  echo "[cmd] dcache off"
  if dcache off; then
    echo "[OK] dcache off"
  else
    echo "[FAIL] command failed: dcache off"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
