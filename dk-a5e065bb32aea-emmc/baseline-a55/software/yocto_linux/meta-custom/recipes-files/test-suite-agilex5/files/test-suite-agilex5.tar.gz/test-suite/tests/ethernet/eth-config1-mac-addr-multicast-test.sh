#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: networking/linux/ETH/Config1/mac_addr_multicast_test/test_steps.sh
# Safety tags: opt-in,network,multiboard
# Review './ts info ethernet/eth-config1-mac-addr-multicast-test' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="mac-multicast"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Run multicast MAC smoke test using the on-board Ethernet interface."

usage() {
  cat <<'USAGE'
Usage:
  test_steps.sh [iface]

Environment:
  NET_IFACE=eth0
  MCAST_GROUP=224.0.50.50
  MCAST_DST_MAC=01:00:5e:01:01:01
  MCAST_PACKET_COUNT=5

This is the on-board test-suite shell version of networking/linux/ETH/Config1/mac_addr_multicast_test/test_steps.pl.
It adds a multicast route, sends multicast packets from the board using scapy when available,
and prints NIC statistics before/after for manual comparison.
USAGE
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${NET_IFACE:=eth0}"
: "${MCAST_GROUP:=224.0.50.50}"
: "${MCAST_DST_MAC:=01:00:5e:01:01:01}"
: "${MCAST_PACKET_COUNT:=5}"

IFACE="${1:-$NET_IFACE}"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  ts_fail "this test requires root privileges to modify multicast routes"
fi

ts_need ip
ts_need python3

ip link show "$IFACE" >/dev/null || ts_fail "interface not found: $IFACE"

cleanup() {
  ip route del 224.0.0.0/4 dev "$IFACE" >/dev/null 2>&1 || true
}
trap cleanup EXIT

ts_log "Interface: $IFACE"
ip -d link show "$IFACE"

ts_log "Adding multicast route"
ip route replace 224.0.0.0/4 dev "$IFACE"

ts_log "Statistics before"
ethtool -S "$IFACE" 2>/dev/null | grep -i 'multicast\|mcast\|rx_\|tx_' | head -40 || true

ts_log "Sending ${MCAST_PACKET_COUNT} multicast packets to ${MCAST_GROUP}/${MCAST_DST_MAC}"
python3 - "$IFACE" "$MCAST_DST_MAC" "$MCAST_GROUP" "$MCAST_PACKET_COUNT" <<'PY'
import sys
iface, dst_mac, group, count = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
try:
    from scapy.all import Ether, IP, sendp
except Exception as exc:
    raise SystemExit(f"scapy is required for packet generation: {exc}")
sendp(Ether(dst=dst_mac)/IP(dst=group, ttl=1), count=count, iface=iface, verbose=False)
PY

sleep 2

ts_log "Statistics after"
ethtool -S "$IFACE" 2>/dev/null | grep -i 'multicast\|mcast\|rx_\|tx_' | head -40 || true

before_mc="$(ethtool -S "$IFACE" 2>/dev/null | grep -iE 'multicast|mcast' | head -5 || true)"
after_mc="$(ethtool -S "$IFACE" 2>/dev/null | grep -iE 'multicast|mcast' | head -5 || true)"
if [[ -z "${before_mc}${after_mc}" ]]; then
  ts_log "WARN: ethtool multicast counters unavailable; packet send completed"
else
  ts_log "Multicast counter sample before:"
  printf '%s
' "$before_mc"
  ts_log "Multicast counter sample after:"
  printf '%s
' "$after_mc"
fi
ts_pass "multicast packet generation completed"
