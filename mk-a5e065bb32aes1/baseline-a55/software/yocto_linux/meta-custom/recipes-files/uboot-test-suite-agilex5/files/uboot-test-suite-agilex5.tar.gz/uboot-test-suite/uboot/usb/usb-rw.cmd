# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
echo "[uboot-usb-rw] Start USB storage read/write smoke test"

if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive USB FAT write test not armed. Set uboot_allow_destructive=1 to run."
  exit 0
fi

if test -z "${uboot_usb_dev}"; then setenv uboot_usb_dev 0; fi
if test -z "${uboot_usb_part}"; then setenv uboot_usb_part 1; fi
if test -z "${uboot_usb_test_file}"; then setenv uboot_usb_test_file testsuite_usb.txt; fi
if test -z "${uboot_pattern_addr}"; then setenv uboot_pattern_addr ${loadaddr}; fi
if test -z "${uboot_read_addr}"; then setexpr uboot_read_addr ${loadaddr} + 0x1000; fi
if test -z "${uboot_usb_pattern}"; then setenv uboot_usb_pattern 0x5a; fi
if test -z "${uboot_usb_size}"; then setenv uboot_usb_size 0x100; fi

if usb reset; then
  echo "[uboot-usb-rw] usb reset OK"
else
  echo "[FAIL] USB reset failed"
  exit 1
fi

if mw.b ${uboot_pattern_addr} ${uboot_usb_pattern} ${uboot_usb_size}; then
  echo "[uboot-usb-rw] pattern buffer prepared"
else
  echo "[FAIL] USB pattern buffer preparation failed"
  exit 1
fi

if fatwrite usb ${uboot_usb_dev}:${uboot_usb_part} ${uboot_pattern_addr} ${uboot_usb_test_file} ${uboot_usb_size}; then
  echo "[uboot-usb-rw] write OK"
else
  echo "[FAIL] USB fatwrite failed"
  exit 1
fi

if fatload usb ${uboot_usb_dev}:${uboot_usb_part} ${uboot_read_addr} ${uboot_usb_test_file}; then
  echo "[uboot-usb-rw] read OK"
else
  echo "[FAIL] USB fatload failed"
  exit 1
fi

if cmp.b ${uboot_pattern_addr} ${uboot_read_addr} ${uboot_usb_size}; then
  echo "[uboot-usb-rw] compare OK"
else
  echo "[FAIL] U-Boot USB read/write compare failed"
  exit 1
fi

if fatrm usb ${uboot_usb_dev}:${uboot_usb_part} ${uboot_usb_test_file}; then
  echo "[uboot-usb-rw] cleanup OK"
else
  echo "[uboot-usb-rw] cleanup failed; test file may remain: ${uboot_usb_test_file}"
fi

echo "[PASS] U-Boot USB read/write compare passed"
