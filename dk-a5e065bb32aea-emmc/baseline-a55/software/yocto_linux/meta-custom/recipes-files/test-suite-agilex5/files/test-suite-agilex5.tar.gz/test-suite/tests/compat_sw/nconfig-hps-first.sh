#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: compat_sw/linux/nconfig_hps_first/test_steps.sh
# Safety tags: opt-in,destructive-op,board-state
# Review './ts info compat_sw/nconfig-hps-first' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_sw/linux/nconfig_hps_first/test_steps.pl
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="nconfig-hps-first"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Run on-board command sequence ported from compat_sw/linux/nconfig_hps_first/test_steps.pl."
usage() {
  cat <<'EOF'
Usage:
  test_steps.sh [--yes]

This is an on-board test-suite shell wrapper generated from the original regtest
compat_sw/linux/nconfig_hps_first/test_steps.pl. It executes the literal target-side command sequence that can run on
Linux without PeRT/ARC/telnet orchestration. Board-specific resources, host-side
programming steps, and telnet wait patterns are intentionally not embedded.

Environment:
  TESTSUITE_ALLOW_DESTRUCTIVE=1  Required for reset/flash/partition/reconfig flows.
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi
CONFIRMED=0
if [[ "${1:-}" == "--yes" ]]; then CONFIRMED=1; shift; fi


ts_require_root

ts_require_destructive "$CONFIRMED"

ts_need 'ls'
ts_need 'mount'
ts_need 'mkdir'
ts_need 'depmod'
ts_need 'sync'
ts_need 'umount'
ts_need 'lsmod'
ts_need 'insmod'
ts_need 'chmod'
ts_need 'memtest_16'

WORKDIR="$(ts_mktemp_dir)"
cleanup() { rm -rf "$WORKDIR"; }
trap cleanup EXIT

ts_stage_assets "$WORKDIR"

cat > "$WORKDIR/original_commands.sh" <<'TESTSUITE_ORIGINAL_COMMANDS'
ls -l
mount /dev/mmcblk0p2 /mnt
mkdir -p /mnt/lib/firmware /mnt/home/root
ls /mnt/home/root
ls /mnt/lib/firmware
mkdir -p /mnt/lib/modules/\$(uname -r)
depmod -a -b /mnt
sync
umount /mnt
ls
lsmod
lsmod
insmod fpga-bridge.ko
insmod fpga-region.ko
insmod of-fpga-region.ko
insmod altera-freeze-bridge.ko
insmod stratix10-soc.ko
lsmod
ls /lib/firmware
ls -la
chmod +x memtest_16
./memtest_16
TESTSUITE_ORIGINAL_COMMANDS

ts_log "Executing command sequence"
cd "$WORKDIR"
if grep -Eq '^[[:space:]]*(reboot|reset[[:space:]]+-)' "$WORKDIR/original_commands.sh"; then
  pre_script="$WORKDIR/pre_reboot_commands.sh"
  awk '/^[[:space:]]*(reboot|reset[[:space:]]+-)/ { exit } { print }' \
    "$WORKDIR/original_commands.sh" > "$pre_script"
  if [[ -s "$pre_script" ]]; then
    ts_log "NOTE: sequence includes reboot/reset; running pre-reboot phase only"
    ts_run "pre-reboot command sequence" bash -eux "$pre_script"
    ts_pass "pre-reboot phase completed (reboot/reset expected; verify post-boot state manually)"
    exit 0
  fi
  ts_log "NOTE: destructive reboot/reset-only sequence; executing armed flow"
  ts_run "reboot/reset command sequence" bash -eux "$WORKDIR/original_commands.sh"
  ts_pass "reboot/reset command sequence completed"
  exit 0
fi
ts_run "command sequence" bash -eux "$WORKDIR/original_commands.sh"
ts_pass "command sequence completed"
