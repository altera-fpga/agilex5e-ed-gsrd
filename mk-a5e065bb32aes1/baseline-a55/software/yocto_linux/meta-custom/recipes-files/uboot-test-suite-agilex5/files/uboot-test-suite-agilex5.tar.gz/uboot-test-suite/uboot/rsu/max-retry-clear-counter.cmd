# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/max_retry_clear_counter/test_steps.pl
echo "[uboot-max-retry-clear-counter] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[cmd] dhcp"
  if dhcp; then
    echo "[OK] dhcp"
  else
    echo "[FAIL] command failed: dhcp"
    exit 1
  fi
  echo "[cmd] mw ffd00200 1"
  if mw ffd00200 1; then
    echo "[OK] mw ffd00200 1"
  else
    echo "[FAIL] command failed: mw ffd00200 1"
    exit 1
  fi
  echo "[cmd] mw.l 0xffd00204 0x11"
  if mw.l 0xffd00204 0x11; then
    echo "[OK] mw.l 0xffd00204 0x11"
  else
    echo "[FAIL] command failed: mw.l 0xffd00204 0x11"
    exit 1
  fi
  echo "[cmd] mw ffd00200 1"
  if mw ffd00200 1; then
    echo "[OK] mw ffd00200 1"
  else
    echo "[FAIL] command failed: mw ffd00200 1"
    exit 1
  fi
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[cmd] rsu reset_retry_counter"
  if rsu reset_retry_counter; then
    echo "[OK] rsu reset_retry_counter"
  else
    echo "[FAIL] command failed: rsu reset_retry_counter"
    exit 1
  fi
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[cmd] mw ffd00200 1"
  if mw ffd00200 1; then
    echo "[OK] mw ffd00200 1"
  else
    echo "[FAIL] command failed: mw ffd00200 1"
    exit 1
  fi
  echo "[cmd] mw.l 0xffd00204 0x11"
  if mw.l 0xffd00204 0x11; then
    echo "[OK] mw.l 0xffd00204 0x11"
  else
    echo "[FAIL] command failed: mw.l 0xffd00204 0x11"
    exit 1
  fi
  echo "[cmd] mw ffd00200 1"
  if mw ffd00200 1; then
    echo "[OK] mw ffd00200 1"
  else
    echo "[FAIL] command failed: mw ffd00200 1"
    exit 1
  fi
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[cmd] rsu update 2000000"
  echo "[INFO] RSU command may reboot the board; script fails if it returns"
  rsu update 2000000
  echo "[FAIL] RSU command returned unexpectedly"
  exit 1
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[cmd] mw ffd00200 1"
  if mw ffd00200 1; then
    echo "[OK] mw ffd00200 1"
  else
    echo "[FAIL] command failed: mw ffd00200 1"
    exit 1
  fi
  echo "[cmd] mw.l 0xffd00204 0x11"
  if mw.l 0xffd00204 0x11; then
    echo "[OK] mw.l 0xffd00204 0x11"
  else
    echo "[FAIL] command failed: mw.l 0xffd00204 0x11"
    exit 1
  fi
  echo "[cmd] mw ffd00200 1"
  if mw ffd00200 1; then
    echo "[OK] mw ffd00200 1"
  else
    echo "[FAIL] command failed: mw ffd00200 1"
    exit 1
  fi
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
