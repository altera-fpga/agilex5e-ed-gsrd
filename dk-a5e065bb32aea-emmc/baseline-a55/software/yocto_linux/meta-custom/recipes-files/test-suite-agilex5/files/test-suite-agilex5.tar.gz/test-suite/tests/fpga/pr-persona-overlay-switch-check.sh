#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: pr/linux/pr_persona_overlay_switch_check/test_steps.sh
# Safety tags: opt-in
# Review './ts info fpga/pr-persona-overlay-switch-check' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from pr/linux/pr_persona_overlay_switch_check/test_steps.pl
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="pr-persona-overlay-switch-check"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Run on-board command sequence ported from pr/linux/pr_persona_overlay_switch_check/test_steps.pl."
usage() {
  cat <<'EOF'
Usage:
  test_steps.sh [--yes]

This is an on-board test-suite shell wrapper generated from the original regtest
pr/linux/pr_persona_overlay_switch_check/test_steps.pl. It executes the literal target-side command sequence that can run on
Linux without PeRT/ARC/telnet orchestration. Board-specific resources, host-side
programming steps, and telnet wait patterns are intentionally not embedded.

Environment:
  TESTSUITE_ALLOW_DESTRUCTIVE=1  Required for reset/flash/partition/reconfig flows.
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi
CONFIRMED=0
if [[ "${1:-}" == "--yes" ]]; then CONFIRMED=1; shift; fi


ts_require_root

ts_need 'ls'
ts_need 'dtbt'
ts_need 'find'
ts_need 'cat'

WORKDIR="$(ts_mktemp_dir)"
cleanup() { rm -rf "$WORKDIR"; }
trap cleanup EXIT

ts_stage_assets "$WORKDIR"

cat > "$WORKDIR/original_commands.sh" <<'TESTSUITE_ORIGINAL_COMMANDS'
ls -la /boot/devicetree
ls -la /lib/firmware
dtbt -a ${pr_prefix}_fpga_static_region.dtbo -p /boot/devicetree
dtbt -l
dtbt -a ${pr_prefix}_persona0.dtbo -p /boot/devicetree
find / -name sysid
cat /sys/bus/platform/drivers/altera_sysid/f9000800.sysid/sysid/id
dtbt -r ${pr_prefix}_persona0.dtbo -p /boot/devicetree
dtbt -a ${pr_prefix}_persona1.dtbo -p /boot/devicetree
find / -name sysid
cat /sys/bus/platform/drivers/altera_sysid/f9000900.sysid/sysid/id
dtbt -r ${pr_prefix}_persona1.dtbo -p /boot/devicetree
dtbt -r ${pr_prefix}_fpga_static_region.dtbo
systemctl start fpgaconfig\@fpga_static_region.service
dtbt -l
systemctl start fpgaconfig\@persona0.service
find / -name sysid
cat /sys/bus/platform/drivers/altera_sysid/f9000800.sysid/sysid/id
systemctl stop fpgaconfig\@persona0.service
systemctl start fpgaconfig\@persona1.service
find / -name sysid
cat /sys/bus/platform/drivers/altera_sysid/f9000900.sysid/sysid/id
systemctl stop fpgaconfig\@persona1.service
TESTSUITE_ORIGINAL_COMMANDS

ts_log "Executing command sequence"
cd "$WORKDIR"
if grep -Eq '^[[:space:]]*(reboot|reset[[:space:]]+-)' "$WORKDIR/original_commands.sh"; then
  pre_script="$WORKDIR/pre_reboot_commands.sh"
  awk '/^[[:space:]]*(reboot|reset[[:space:]]+-)/ { exit } { print }' \
    "$WORKDIR/original_commands.sh" > "$pre_script"
  if [[ -s "$pre_script" ]]; then
    ts_log "NOTE: sequence includes reboot/reset; running pre-reboot phase only"
    ts_run "pre-reboot command sequence" bash -eux "$pre_script"
    ts_pass "pre-reboot phase completed (reboot/reset expected; verify post-boot state manually)"
    exit 0
  fi
  ts_log "NOTE: destructive reboot/reset-only sequence; executing armed flow"
  ts_run "reboot/reset command sequence" bash -eux "$WORKDIR/original_commands.sh"
  ts_pass "reboot/reset command sequence completed"
  exit 0
fi
ts_run "command sequence" bash -eux "$WORKDIR/original_commands.sh"
ts_pass "command sequence completed"
