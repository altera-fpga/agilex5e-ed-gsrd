#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: crypto/linux/open_close_session/test_steps.sh
# Safety tags: crypto,smoke,requires-fcs
# Review './ts info crypto/crypto-smoke' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="crypto-smoke"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Open and close FCS crypto sessions, matching crypto/linux/open_close_session/test_steps.pl."

usage() {
  cat <<'EOF_USAGE'
Usage:
  test_steps.sh

Environment:
  FCS_CLIENT=fcs_client
  FCS_ITERATIONS=10
  TESTSUITE_ASSETS_DIR=<dir>   Optional directory containing fcs_client/libs/modules.

The original Perl flow loads/copies FCS dependencies using regtest helpers, then
opens and closes an FCS session for 10 iterations. This customer shell script
expects the image to already contain the FCS driver stack or for the needed
userspace files to be staged through TESTSUITE_ASSETS_DIR.
EOF_USAGE
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${FCS_CLIENT:=fcs_client}"
: "${FCS_ITERATIONS:=10}"

WORKDIR="$(ts_mktemp_dir)"
cleanup() { rm -rf "$WORKDIR"; }
trap cleanup EXIT

ts_stage_assets "$WORKDIR"

if [[ -x "$FCS_CLIENT" ]]; then
  cp "$FCS_CLIENT" "$WORKDIR/fcs_client"
elif command -v "$FCS_CLIENT" >/dev/null 2>&1; then
  cp "$(command -v "$FCS_CLIENT")" "$WORKDIR/fcs_client"
elif [[ -x "$WORKDIR/$(basename "$FCS_CLIENT")" ]]; then
  mv "$WORKDIR/$(basename "$FCS_CLIENT")" "$WORKDIR/fcs_client"
fi
chmod +x "$WORKDIR/fcs_client" 2>/dev/null || true
[[ -x "$WORKDIR/fcs_client" ]] || ts_fail "fcs_client not found in PATH, FCS_CLIENT, or TESTSUITE_ASSETS_DIR"

for ((iter = 1; iter <= FCS_ITERATIONS; iter++)); do
  ts_log "Iteration: $iter"
  ts_log "Open session"
  sid="$(ts_fcs_open_session "$WORKDIR")"
  ts_log "Session ID: $sid"
  ts_log "Close session"
  ts_fcs_close_session "$WORKDIR" "$sid" >/dev/null
done

ts_pass "FCS open/close session completed for ${FCS_ITERATIONS} iteration(s)"
