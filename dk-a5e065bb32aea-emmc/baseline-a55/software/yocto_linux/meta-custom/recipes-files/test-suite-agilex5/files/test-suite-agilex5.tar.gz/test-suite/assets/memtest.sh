#!/bin/bash
# memtest.sh - Memory bandwidth test using standard Linux commands
# Bash equivalent of memtest.c (optimized version)

# Configuration - Adjusted for dd performance
MEGABYTES=1000             # Test with 1000 MB per iteration
SIZE=$((MEGABYTES * 1024 * 1024))  # MB in bytes
SINGLE_ITERATIONS=20     # 20 iterations
MULTI_ITERATIONS=10        # 10 iterations per thread

# Use RAM disk for testing (faster than disk)
TEST_DIR="/dev/shm"
if [ ! -d "$TEST_DIR" ]; then
    TEST_DIR="/tmp"
fi

# Function to get time in seconds with decimals
get_time() {
    date +%s.%N
}

# Function: Single-threaded memory test
single_thread_test() {
    echo "========= Single Thread ========="
    echo ""
    
    for ((j=0; j<$SINGLE_ITERATIONS; j++)); do
        # Use /dev/shm for RAM-based testing
        TMPFILE="$TEST_DIR/memtest_$$_$j"
        
        # Start timing
        START=$(get_time)
        
        # Single large write (equivalent to repeated memset)
        dd if=/dev/zero of="$TMPFILE" bs=1M count=$MEGABYTES 2>/dev/null
        
        # End timing
        END=$(get_time)
        
        # Calculate time in seconds
        TIME_SEC=$(echo "$END - $START" | bc)
        
        # Check for zero or invalid time (prevent divide by zero)
        if [ -z "$TIME_SEC" ] || [ "$(echo "$TIME_SEC == 0" | bc)" -eq 1 ]; then
            echo "Warning: Operation completed too fast (TIME_SEC=$TIME_SEC), skipping iteration $j"
            rm -f "$TMPFILE"
            continue
        fi
        
        # Calculate datarate in MB/s
        DATARATE=$(echo "scale=6; $MEGABYTES / $TIME_SEC" | bc)
        
        echo "Single Thread Datarate: $DATARATE MB/s"
        
        # Cleanup
        rm -f "$TMPFILE"
    done
}

# Function: Multi-threaded memory test worker
multi_thread_worker() {
    local thread_id=$1
    
    for ((j=0; j<$MULTI_ITERATIONS; j++)); do
        # Use /dev/shm for RAM-based testing
        TMPFILE="$TEST_DIR/memtest_${thread_id}_$j"
        
        # Start timing
        START=$(get_time)
        
        # Single large write
        dd if=/dev/zero of="$TMPFILE" bs=1M count=$MEGABYTES 2>/dev/null
        
        # End timing
        END=$(get_time)
        
        # Calculate time in seconds
        TIME_SEC=$(echo "$END - $START" | bc)
        
        # Check for zero or invalid time (prevent divide by zero)
        if [ -z "$TIME_SEC" ] || [ "$(echo "$TIME_SEC == 0" | bc)" -eq 1 ]; then
            echo "Warning: Thread $thread_id - Operation completed too fast (TIME_SEC=$TIME_SEC), skipping iteration $j"
            rm -f "$TMPFILE"
            continue
        fi
        
        # Calculate datarate in MB/s
        DATARATE=$(echo "scale=6; $MEGABYTES / $TIME_SEC" | bc)
        
        echo "Thread $thread_id: Datarate: $DATARATE MB/s"
        
        # Cleanup
        rm -f "$TMPFILE"
    done
}

# Function: Multi-threaded memory test
multi_thread_test() {
    echo ""
    echo ""
    echo "========= Multi Thread ========="
    echo ""
    
    # Start two threads in background
    multi_thread_worker $$ &
    PID1=$!
    
    multi_thread_worker $(($$ + 1)) &
    PID2=$!
    
    # Wait for both threads to complete
    wait $PID1
    wait $PID2
}

# Main execution
main() {
    # Check if bc is available
    if ! command -v bc &> /dev/null; then
        echo "Error: 'bc' command not found. Please install bc."
        echo "  apt-get install bc"
        echo "  or"
        echo "  yum install bc"
        exit 1
    fi
    
    # Verify nanosecond timing support
    TEST_TIME=$(date +%s.%N)
    if [[ ! $TEST_TIME =~ \. ]]; then
        echo "Warning: System doesn't support nanosecond precision (date +%s.%N)"
        echo "Results may be inaccurate for fast operations"
    fi
    
    # Run single thread test
    single_thread_test
    
    # Run multi thread test
    multi_thread_test
    
    echo ""
    echo "Finished!"
}

# Run main function
main
