#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: uart/linux/uart_loopback/test_steps.sh
# Safety tags: uart,opt-in
# Review './ts info uart/uart-loopback' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="uart-loopback"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Run an optional UART loopback test using a configured tty device."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh [tty-device]

Environment:
  UART_DEV=/dev/ttyS1
  UART_BAUD=115200
  UART_LOOPBACK=0

Notes:
  - Default mode lists tty devices only.
  - Set UART_LOOPBACK=1 when TX/RX loopback wiring is connected.
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${UART_DEV:=/dev/ttyS1}"
: "${UART_BAUD:=115200}"
: "${UART_LOOPBACK:=0}"
DEV="${1:-$UART_DEV}"


ts_log "Available ttyS/ttyAMA devices"
ls -l /dev/ttyS* /dev/ttyAMA* 2>/dev/null || true

if [[ "$UART_LOOPBACK" != "1" ]]; then
  ts_pass "UART discovery completed. Set UART_LOOPBACK=1 for loopback transfer."
  exit 0
fi

[[ -c "$DEV" ]] || ts_fail "UART device not found: $DEV"
command -v stty >/dev/null 2>&1 || ts_fail "stty not found"
command -v timeout >/dev/null 2>&1 || ts_fail "timeout not found"

PAYLOAD="testsuite-uart-$RANDOM"
stty -F "$DEV" "$UART_BAUD" raw -echo -crtscts || ts_fail "failed to configure $DEV"
TMP="$(mktemp /tmp/uart-loopback.XXXXXX)"
trap 'rm -f "$TMP"' EXIT

timeout 3 cat "$DEV" > "$TMP" &
CAT_PID=$!
sleep 0.2
printf '%s' "$PAYLOAD" > "$DEV"
sleep 0.5
kill "$CAT_PID" 2>/dev/null || true
wait "$CAT_PID" 2>/dev/null || true

if grep -q "$PAYLOAD" "$TMP"; then
  ts_pass "UART loopback payload received"
else
  ts_fail "loopback payload not received"
fi
