# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/rsu_update_app_image/test_steps.pl
echo "[uboot-rsu-update-app-image] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] setenv autoload no"
  setenv autoload no
  echo "[cmd] printenv"
  if printenv; then
    echo "[OK] printenv"
  else
    echo "[FAIL] command failed: printenv"
    exit 1
  fi
  echo "[cmd] setenv ethaddr 00:df:00:33:56:00"
  setenv ethaddr 00:df:00:33:56:00
  echo "[cmd] dhcp"
  if dhcp; then
    echo "[OK] dhcp"
  else
    echo "[FAIL] command failed: dhcp"
    exit 1
  fi
  echo "[cmd] dcache off"
  if dcache off; then
    echo "[OK] dcache off"
  else
    echo "[FAIL] command failed: dcache off"
    exit 1
  fi
  echo "[cmd] rsu status_log"
  if rsu status_log; then
    echo "[OK] rsu status_log"
  else
    echo "[FAIL] command failed: rsu status_log"
    exit 1
  fi
  echo "[cmd] rsu slot_erase 3"
  if rsu slot_erase 3; then
    echo "[OK] rsu slot_erase 3"
  else
    echo "[FAIL] command failed: rsu slot_erase 3"
    exit 1
  fi
  echo "[cmd] rsu slot_program_buf 3 $loadaddr $filesize"
  if rsu slot_program_buf 3 $loadaddr $filesize; then
    echo "[OK] rsu slot_program_buf 3 $loadaddr $filesize"
  else
    echo "[FAIL] command failed: rsu slot_program_buf 3 $loadaddr $filesize"
    exit 1
  fi
  echo "[cmd] rsu slot_enable 3"
  if rsu slot_enable 3; then
    echo "[OK] rsu slot_enable 3"
  else
    echo "[FAIL] command failed: rsu slot_enable 3"
    exit 1
  fi
  echo "[cmd] dcache off"
  if dcache off; then
    echo "[OK] dcache off"
  else
    echo "[FAIL] command failed: dcache off"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
