# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
echo "[uboot-spi] Start SPI command smoke test"

if test -z "${uboot_spi_bus}"; then setenv uboot_spi_bus 0; fi
if test -z "${uboot_spi_cs}"; then setenv uboot_spi_cs 0; fi
if test -z "${uboot_spi_hz}"; then setenv uboot_spi_hz 1000000; fi
if test -z "${uboot_spi_mode}"; then setenv uboot_spi_mode 0; fi
if test -z "${uboot_spi_tx}"; then setenv uboot_spi_tx deadbeef; fi
if test -z "${uboot_spi_rx_len}"; then setenv uboot_spi_rx_len 4; fi

if sspi ${uboot_spi_bus}:${uboot_spi_cs}.${uboot_spi_hz}.${uboot_spi_mode} ${uboot_spi_tx}; then
  echo "[PASS] U-Boot SPI command sequence completed"
else
  echo "[FAIL] U-Boot SPI command failed"
  exit 1
fi
