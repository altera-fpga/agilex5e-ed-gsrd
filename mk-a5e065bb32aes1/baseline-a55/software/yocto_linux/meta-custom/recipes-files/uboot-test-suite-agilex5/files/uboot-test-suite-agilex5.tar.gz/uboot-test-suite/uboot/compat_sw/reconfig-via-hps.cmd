# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_sw/uboot/reconfig_via_hps/test_steps.pl
echo "[uboot-reconfig-via-hps] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] iminfo"
  if iminfo; then
    echo "[OK] iminfo"
  else
    echo "[FAIL] command failed: iminfo"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] setexpr newaddr $loadaddr + 0x06000000"
  setexpr newaddr $loadaddr + 0x06000000
  echo "[cmd] fpga load 0 $loadaddr $filesize"
  if fpga load 0 $loadaddr $filesize; then
    echo "[OK] fpga load 0 $loadaddr $filesize"
  else
    echo "[FAIL] command failed: fpga load 0 $loadaddr $filesize"
    exit 1
  fi
  echo "[cmd] bridge enable"
  if bridge enable; then
    echo "[OK] bridge enable"
  else
    echo "[FAIL] command failed: bridge enable"
    exit 1
  fi
  echo "[cmd] mw 80000000 aaaaaaaa"
  if mw 80000000 aaaaaaaa; then
    echo "[OK] mw 80000000 aaaaaaaa"
  else
    echo "[FAIL] command failed: mw 80000000 aaaaaaaa"
    exit 1
  fi
  echo "[cmd] md 80000000 1"
  if md 80000000 1; then
    echo "[OK] md 80000000 1"
  else
    echo "[FAIL] command failed: md 80000000 1"
    exit 1
  fi
  echo "[cmd] mw 8003ff00 deadbeef"
  if mw 8003ff00 deadbeef; then
    echo "[OK] mw 8003ff00 deadbeef"
  else
    echo "[FAIL] command failed: mw 8003ff00 deadbeef"
    exit 1
  fi
  echo "[cmd] md 8003ff00 1"
  if md 8003ff00 1; then
    echo "[OK] md 8003ff00 1"
  else
    echo "[FAIL] command failed: md 8003ff00 1"
    exit 1
  fi
  echo "[cmd] bridge disable"
  if bridge disable; then
    echo "[OK] bridge disable"
  else
    echo "[FAIL] command failed: bridge disable"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
