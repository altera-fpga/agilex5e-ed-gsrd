#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: crypto/linux/hmac_sha2/test_steps.sh
# Safety tags: opt-in,requires-fcs
# Review './ts info crypto/hmac-sha2' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# On-board test-suite shell port of crypto/linux/hmac_sha2/test_steps.pl
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="hmac-sha2"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Run FCS HMAC-SHA2 session smoke and optional sign/verify when assets are packaged."
FCS_CID="${FCS_CID:-5788739}"
FCS_KEY_256_ID="${FCS_KEY_256_ID:-0x22220256}"

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh

Environment:
  FCS_CID=<context-id>
  FCS_KEY_256_ID=<key-id>
  FCS_RUN_FULL=1           Run one 256-bit HMAC sign/verify path when assets exist.

Required packaged assets for FCS_RUN_FULL=1:
  fcs_client, key_256.obj, user_data.bin

Notes:
  - Always opens and closes an FCS session with output validation.
  - Full HMAC coverage still depends on packaged FCS assets from the original regtest.
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${FCS_RUN_FULL:=0}"

ts_need fcs_client

WORKDIR="$(ts_mktemp_dir)"
cleanup() { rm -rf "$WORKDIR"; }
trap cleanup EXIT

ts_stage_assets "$WORKDIR"

if [[ ! -x "$WORKDIR/fcs_client" && -x "$(command -v fcs_client)" ]]; then
  cp "$(command -v fcs_client)" "$WORKDIR/fcs_client"
  chmod +x "$WORKDIR/fcs_client"
fi
[[ -x "$WORKDIR/fcs_client" ]] || ts_fail "fcs_client not found in PATH or staged assets"

ts_log "Open FCS session"
sid="$(ts_fcs_open_session "$WORKDIR")"
ts_log "Session ID: $sid"

if [[ "$FCS_RUN_FULL" == "1" ]]; then
  for req in key_256.obj user_data.bin; do
    [[ -f "$WORKDIR/$req" ]] || ts_fail "FCS_RUN_FULL=1 requires packaged asset: $req"
  done

  ts_log "Import HMAC 256-bit key"
  import_out=""
  ts_capture import_out bash -c "cd '$WORKDIR' && ./fcs_client -B -s '$sid' -i key_256.obj"
  printf '%s\n' "$import_out"
  ts_fcs_reject_errors "$import_out" "import key"

  ts_log "Generate HMAC digest (256-bit)"
  sign_out=""
  ts_capture sign_out bash -c "cd '$WORKDIR' && ./fcs_client -N -s '$sid' -n '$FCS_CID' -k '$FCS_KEY_256_ID' -g 2 -j 0 -i user_data.bin -o signature.bin"
  printf '%s\n' "$sign_out"
  ts_fcs_reject_errors "$sign_out" "HMAC digest generation"
  [[ -s "$WORKDIR/signature.bin" ]] || ts_fail "signature.bin was not created"

  ts_log "Verify HMAC digest (256-bit)"
  verify_out=""
  ts_capture verify_out bash -c "cd '$WORKDIR' && ./fcs_client -O -s '$sid' -n '$FCS_CID' -k '$FCS_KEY_256_ID' -j 0 -z 'user_data.bin#signature.bin' -o response.bin"
  printf '%s\n' "$verify_out"
  ts_fcs_reject_errors "$verify_out" "HMAC verify"
  [[ -s "$WORKDIR/response.bin" ]] || ts_fail "response.bin was not created"
else
  ts_log "Skipping full HMAC path (set FCS_RUN_FULL=1 when FCS assets are packaged)"
fi

ts_log "Close FCS session"
ts_fcs_close_session "$WORKDIR" "$sid" >/dev/null

if [[ "$FCS_RUN_FULL" == "1" ]]; then
  ts_pass "FCS HMAC-SHA2 session and 256-bit sign/verify completed"
else
  ts_pass "FCS session open/close smoke completed"
fi
