# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from fpga_bridge/uboot/read_pre_written_fpga_design/test_steps.pl
echo "[uboot-read-pre-written-fpga-design] Start generated command sequence"
  echo "[cmd] bridge enable"
  if bridge enable; then
    echo "[OK] bridge enable"
  else
    echo "[FAIL] command failed: bridge enable"
    exit 1
  fi
  echo "[cmd] md 0x40000000 1"
  if md 0x40000000 1; then
    echo "[OK] md 0x40000000 1"
  else
    echo "[FAIL] command failed: md 0x40000000 1"
    exit 1
  fi
  echo "[cmd] md 0x400003fc 1"
  if md 0x400003fc 1; then
    echo "[OK] md 0x400003fc 1"
  else
    echo "[FAIL] command failed: md 0x400003fc 1"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
