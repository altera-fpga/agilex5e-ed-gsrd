#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: i3c/linux/dw_i3c_probe/test_steps.sh
# Safety tags: i3c,smoke,requires-i3c
# Review './ts info i3c/i3c-probe' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="i3c-probe"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Verify Agilex5 dw-i3c-master probe, DEVICE_CTRL enable bits, and driver binding."

usage() {
  cat <<'EOF_USAGE'
Usage:
  test_steps.sh

Environment:
  I3C0_DEVICE_CTRL=0x10DA0000
  I3C1_DEVICE_CTRL=0x10DA1000
  I3C0_ADDR_TAG=10da0000
  I3C1_ADDR_TAG=10da1000
  I3C_REQUIRE_DEVICE=0
EOF_USAGE
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${I3C0_DEVICE_CTRL:=0x10DA0000}"
: "${I3C1_DEVICE_CTRL:=0x10DA1000}"
: "${I3C0_ADDR_TAG:=10da0000}"
: "${I3C1_ADDR_TAG:=10da1000}"
: "${I3C_REQUIRE_DEVICE:=0}"
DEVICE_CTRL_ENABLE_MASK=$((0x80000000))

read_devmem2_value() {
  local addr="$1" out="" val=""
  ts_need devmem2
  out="$(devmem2 "$addr" 2>&1)" || { printf '%s\n' "$out"; ts_fail "devmem2 read failed at $addr"; }
  printf '%s\n' "$out"
  val="$(sed -nE 's/.*Read at address[^(]*\([^)]*\):[[:space:]]*(0x[0-9a-fA-F]+).*/\1/p' <<< "$out" | tail -n 1)"
  ts_assert_nonempty "$val" "unable to parse devmem2 value at $addr"
  printf '%s\n' "$val"
}

check_dmesg_no_probe_failure() {
  local output
  output="$(dmesg)"
  ts_assert_not_grep 'probe with driver dw-i3c-master failed' "$output" "dw-i3c-master probe failed in dmesg"
  ts_assert_not_grep 'i3c_master_register failed' "$output" "i3c_master_register failed in dmesg"
  ts_assert_not_grep 'dw_i3c_common_probe.*failed' "$output" "dw_i3c_common_probe failed in dmesg"
  ts_log "PASSED: dmesg has no dw-i3c probe failure"
}

check_device_ctrl_enable() {
  local label="$1" addr="$2" val raw
  val="$(read_devmem2_value "$addr" | tail -n 1)"
  raw="${val#0x}"; raw="${raw#0X}"
  if (( (16#$raw & DEVICE_CTRL_ENABLE_MASK) == 0 )); then
    ts_fail "$label DEVICE_CTRL ENABLE bit is not set at $addr (read $val)"
  fi
  ts_log "PASSED: $label DEVICE_CTRL ENABLE set at $addr ($val)"
}

check_driver_bound() {
  local label="$1" tag="$2" entries=""
  entries="$(ls /sys/bus/platform/drivers/dw-i3c-master/ 2>/dev/null || true)"
  printf '%s\n' "$entries"
  ts_assert_grep "$tag" "$entries" "$label ($tag) not bound to dw-i3c-master"
  ts_log "PASSED: $label ($tag) bound to dw-i3c-master"
}

check_dmesg_no_probe_failure
check_device_ctrl_enable i3c0 "$I3C0_DEVICE_CTRL"
check_device_ctrl_enable i3c1 "$I3C1_DEVICE_CTRL"
check_driver_bound i3c0 "$I3C0_ADDR_TAG"
check_driver_bound i3c1 "$I3C1_ADDR_TAG"

if [[ "$I3C_REQUIRE_DEVICE" == "1" ]]; then
  [[ -d /sys/bus/i3c/devices ]] || ts_fail "/sys/bus/i3c/devices not found"
  device_count="$(find /sys/bus/i3c/devices -mindepth 1 -maxdepth 1 2>/dev/null | wc -l)"
  [[ "$device_count" -gt 0 ]] || ts_fail "I3C_REQUIRE_DEVICE=1 but no I3C devices enumerated"
fi

ts_log "I3C sysfs devices"
find /sys/bus/i3c/devices -maxdepth 2 \( -type l -o -type d \) 2>/dev/null | sort || true

ts_pass "Agilex5 dw-i3c probe check completed"
