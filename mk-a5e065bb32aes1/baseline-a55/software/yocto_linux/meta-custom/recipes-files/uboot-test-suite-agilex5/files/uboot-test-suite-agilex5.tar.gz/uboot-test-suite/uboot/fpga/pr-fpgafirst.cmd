# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from pr/uboot/pr_fpgafirst/test_steps.pl
echo "[uboot-pr-fpgafirst] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] md f9000800 1; md f9000900 1"
  if md f9000800 1; md f9000900 1; then
    echo "[OK] md f9000800 1; md f9000900 1"
  else
    echo "[FAIL] command failed: md f9000800 1; md f9000900 1"
    exit 1
  fi
  echo "[cmd] fpga load 0 $loadaddr $filesize"
  if fpga load 0 $loadaddr $filesize; then
    echo "[OK] fpga load 0 $loadaddr $filesize"
  else
    echo "[FAIL] command failed: fpga load 0 $loadaddr $filesize"
    exit 1
  fi
  echo "[cmd] md f9000800 1; md f9000900 1"
  if md f9000800 1; md f9000900 1; then
    echo "[OK] md f9000800 1; md f9000900 1"
  else
    echo "[FAIL] command failed: md f9000800 1; md f9000900 1"
    exit 1
  fi
  echo "[cmd] bdinfo"
  if bdinfo; then
    echo "[OK] bdinfo"
  else
    echo "[FAIL] command failed: bdinfo"
    exit 1
  fi
  echo "[cmd] fdt resize"
  if fdt resize; then
    echo "[OK] fdt resize"
  else
    echo "[FAIL] command failed: fdt resize"
    exit 1
  fi
  echo "[cmd] echo delay"
  if echo delay; then
    echo "[OK] echo delay"
  else
    echo "[FAIL] command failed: echo delay"
    exit 1
  fi
  echo "[cmd] fdt list \/aliases"
  if fdt list \/aliases; then
    echo "[OK] fdt list \/aliases"
  else
    echo "[FAIL] command failed: fdt list \/aliases"
    exit 1
  fi
  echo "[cmd] echo delay"
  if echo delay; then
    echo "[OK] echo delay"
  else
    echo "[FAIL] command failed: echo delay"
    exit 1
  fi
  echo "[cmd] dhcp"
  if dhcp; then
    echo "[OK] dhcp"
  else
    echo "[FAIL] command failed: dhcp"
    exit 1
  fi
  echo "[cmd] sleep 5"
  if sleep 5; then
    echo "[OK] sleep 5"
  else
    echo "[FAIL] command failed: sleep 5"
    exit 1
  fi
  echo "[cmd] echo delay"
  if echo delay; then
    echo "[OK] echo delay"
  else
    echo "[FAIL] command failed: echo delay"
    exit 1
  fi
  echo "[cmd] bridge enable"
  if bridge enable; then
    echo "[OK] bridge enable"
  else
    echo "[FAIL] command failed: bridge enable"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] pr start"
  if pr start; then
    echo "[OK] pr start"
  else
    echo "[FAIL] command failed: pr start"
    exit 1
  fi
  echo "[cmd] pr end"
  if pr end; then
    echo "[OK] pr end"
  else
    echo "[FAIL] command failed: pr end"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
