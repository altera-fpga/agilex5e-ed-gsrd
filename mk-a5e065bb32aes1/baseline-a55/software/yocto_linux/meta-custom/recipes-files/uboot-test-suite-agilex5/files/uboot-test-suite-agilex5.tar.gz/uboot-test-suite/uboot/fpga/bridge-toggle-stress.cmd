# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from fpga_bridge/uboot/bridge_toggle_stress/test_steps.pl
echo "[uboot-bridge-toggle-stress] Start generated command sequence"
  echo "[cmd] mw ${h2f_start_range} 0xcafe0000"
  if mw ${h2f_start_range} 0xcafe0000; then
    echo "[OK] mw ${h2f_start_range} 0xcafe0000"
  else
    echo "[FAIL] command failed: mw ${h2f_start_range} 0xcafe0000"
    exit 1
  fi
  echo "[cmd] mw ${h2f_addr1} 0xcafe00ff"
  if mw ${h2f_addr1} 0xcafe00ff; then
    echo "[OK] mw ${h2f_addr1} 0xcafe00ff"
  else
    echo "[FAIL] command failed: mw ${h2f_addr1} 0xcafe00ff"
    exit 1
  fi
  echo "[cmd] bridge enable"
  if bridge enable; then
    echo "[OK] bridge enable"
  else
    echo "[FAIL] command failed: bridge enable"
    exit 1
  fi
  echo "[cmd] md ${h2f_start_range} 1"
  if md ${h2f_start_range} 1; then
    echo "[OK] md ${h2f_start_range} 1"
  else
    echo "[FAIL] command failed: md ${h2f_start_range} 1"
    exit 1
  fi
  echo "[cmd] md ${h2f_addr1} 1"
  if md ${h2f_addr1} 1; then
    echo "[OK] md ${h2f_addr1} 1"
  else
    echo "[FAIL] command failed: md ${h2f_addr1} 1"
    exit 1
  fi
  echo "[cmd] bridge disable"
  if bridge disable; then
    echo "[OK] bridge disable"
  else
    echo "[FAIL] command failed: bridge disable"
    exit 1
  fi
  echo "[cmd] bridge enable"
  if bridge enable; then
    echo "[OK] bridge enable"
  else
    echo "[FAIL] command failed: bridge enable"
    exit 1
  fi
  echo "[cmd] md ${h2f_start_range} 1"
  if md ${h2f_start_range} 1; then
    echo "[OK] md ${h2f_start_range} 1"
  else
    echo "[FAIL] command failed: md ${h2f_start_range} 1"
    exit 1
  fi
  echo "[cmd] md ${h2f_addr1} 1"
  if md ${h2f_addr1} 1; then
    echo "[OK] md ${h2f_addr1} 1"
  else
    echo "[FAIL] command failed: md ${h2f_addr1} 1"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
