# U-Boot Quick Start

Load defaults first, then run a script.

Packaged `*.scr` files are **signed FIT** images (same GSRD `dev` key path as
`boot.scr.uimg`). Modern U-Boot with `CONFIG_BOOTSCR_FIT_SIGNATURE` rejects
legacy `mkimage -T script` images with:
`Legacy boot script rejected: signed FIT required`.

## FAT/MMC example

```bash
fatload mmc 0:1 ${scriptaddr} uboot-test-suite/config/uboot.scr
source ${scriptaddr}
fatload mmc 0:1 ${scriptaddr} uboot-test-suite/uboot/suite/oobe-smoke.scr
source ${scriptaddr}
```

## TFTP example

If the package is under a TFTP server subdirectory, set `uboot_ts_root` to that full prefix before running the batch script.

```bash
setenv uboot_ts_load tftp
setenv uboot_ts_root uboot-test-suite
tftp ${scriptaddr} ${uboot_ts_root}/config/uboot.scr
source ${scriptaddr}
tftp ${scriptaddr} ${uboot_ts_root}/uboot/suite/oobe-smoke.scr
source ${scriptaddr}
```

Example for a lab path:

```bash
setenv uboot_ts_load tftp
setenv uboot_ts_root board/debug/SM_devkit/SM72/19/uboot-test-suite
tftp ${scriptaddr} ${uboot_ts_root}/config/uboot.scr
source ${scriptaddr}
tftp ${scriptaddr} ${uboot_ts_root}/uboot/suite/oobe-smoke.scr
source ${scriptaddr}
```

## Regenerating scripts after edits

From the extracted package (host with mkimage + dtc):

```bash
export MKIMAGE=/path/to/mkimage
export UBOOT_SIGN_KEYDIR=/path/to/keys   # must contain dev.key and dev.crt
./uboot/mkimage_all.sh
```

## Destructive U-Boot tests

Destructive U-Boot scripts are disabled by default. Run only after confirming the target offset/device is safe and board recovery is available:

```bash
setenv uboot_allow_destructive 1
```

Review UBOOT_INDEX.tsv before running individual scripts.
