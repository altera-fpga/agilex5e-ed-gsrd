#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: sdmtest/linux/sm_hwmon/test_steps.sh
# Safety tags: hwmon,sdm,smoke
# Review './ts info hwmon/sm-hwmon' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="hwmon"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Read system manager HWMON temperature and voltage nodes."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh [hwmon-path]

Environment:
  HWMON_PATH=/sys/class/hwmon/hwmon1
  HWMON_REQUIRE_ALL=0
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${HWMON_PATH:=/sys/class/hwmon/hwmon1}"
: "${HWMON_REQUIRE_ALL:=0}"
PATH_ARG="${1:-$HWMON_PATH}"


[[ -d "$PATH_ARG" ]] || ts_fail "hwmon path not found: $PATH_ARG"

found=0
for node in "$PATH_ARG"/temp*_input "$PATH_ARG"/in*_input; do
  [[ -r "$node" ]] || continue
  found=1
  value="$(cat "$node")"
  printf '%-40s %s\n' "$(basename "$node")" "$value"
  if [[ "$HWMON_REQUIRE_ALL" == "1" && ! "$value" =~ ^-?[0-9]+$ ]]; then
    ts_fail "non-numeric HWMON value in $node"
  fi
done

[[ "$found" -eq 1 ]] || ts_fail "no readable temp*_input or in*_input nodes found"
ts_pass "HWMON read completed"
