#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: i3c/linux/basic_i3c_rw/test_steps.sh
# Safety tags: opt-in,requires-i3c
# Review './ts info i3c/basic-i3c-rw' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="basic-i3c-rw"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Run the Agilex5 I3C temperature-sensor flow equivalent to test_steps.pl."

usage() {
  cat <<'EOF_USAGE'
Usage:
  test_steps.sh [--profile agilex5|simics-eeprom|probe]

Default profile is agilex5, matching the Agilex5 branch in test_steps.pl.
Use --profile simics-eeprom to run the SIMICS EEPROM branch that exists in the
same Perl regtest. Use --profile probe for enumeration-only diagnostics.

Environment:
  I3C_PROFILE=agilex5|simics-eeprom|probe
  I3C_DEV=auto                         # /dev/i3c-1-236152a0098 if present, else first /dev/i3c-*
  I3C_TRANSFER_BIN=i3ctransfer          # path/name; staged asset is also accepted
  I3C_MIN_TEMP_C=15
  I3C_MAX_TEMP_C=30
  I2C_EEPROM_VALID_ADDRS="0x54 0x55 0x56 0x57"
  I2C_EEPROM_INVALID_ADDRS="0x52 0x53 0x58"
  I2C_EEPROM_BUS=2
  I2C_EEPROM_INVALID_BUS=0
EOF_USAGE
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

PROFILE="${I3C_PROFILE:-agilex5}"
if [[ "${1:-}" == "--profile" ]]; then PROFILE="${2:?profile required}"; shift 2; fi

: "${I3C_DEV:=auto}"
: "${I3C_TRANSFER_BIN:=i3ctransfer}"
: "${I3C_MIN_TEMP_C:=15}"
: "${I3C_MAX_TEMP_C:=30}"
: "${I2C_EEPROM_VALID_ADDRS:=0x54 0x55 0x56 0x57}"
: "${I2C_EEPROM_INVALID_ADDRS:=0x52 0x53 0x58}"
: "${I2C_EEPROM_BUS:=2}"
: "${I2C_EEPROM_INVALID_BUS:=0}"

WORKDIR="$(ts_mktemp_dir)"
cleanup() { rm -rf "$WORKDIR"; }
trap cleanup EXIT

ts_stage_assets "$WORKDIR"

normalize_hex_byte() {
  local raw="${1#0x}"
  raw="${raw#0X}"
  printf '0x%02x' "$((16#$raw))"
}

hex_to_dec() {
  local raw="${1#0x}"
  raw="${raw#0X}"
  printf '%d' "$((16#$raw))"
}

assert_hex_eq() {
  local expected actual label
  expected="$(normalize_hex_byte "$1")"
  actual="$(normalize_hex_byte "$2")"
  label="$3"
  [[ "$expected" == "$actual" ]] || ts_fail "$label mismatch: expected $expected, got $actual"
}

sensor_temp_c_from_bytes() {
  local msb lsb sum
  msb="$(hex_to_dec "$1")"
  lsb="$(hex_to_dec "$2")"
  sum=$(( (msb << 4) + (lsb >> 4) ))
  awk -v s="$sum" 'BEGIN { printf "%.4f", s * 0.0625 }'
}

threshold_bytes_from_c() {
  local c="$1"
  awk -v c="$c" 'BEGIN {
    raw = int((c / 0.0625) + 0.5);
    if (c == 15) {
      printf "0x%02X 0x%02X", int(raw / 16) % 256, raw % 16;
    } else {
      shifted = raw * 16;
      printf "0x%02X 0x%02X", int(shifted / 256) % 256, shifted % 256;
    }
  }'
}

resolve_i3ctransfer() {
  local bin="$I3C_TRANSFER_BIN"
  if [[ -x "$bin" ]]; then printf '%s\n' "$bin"; return; fi
  if command -v "$bin" >/dev/null 2>&1; then command -v "$bin"; return; fi
  if [[ -x "$WORKDIR/$(basename "$bin")" ]]; then printf '%s\n' "$WORKDIR/$(basename "$bin")"; return; fi
  if [[ -x "$WORKDIR/i3ctransfer" ]]; then printf '%s\n' "$WORKDIR/i3ctransfer"; return; fi
  ts_fail "i3ctransfer not found. Put it in PATH, set I3C_TRANSFER_BIN, or stage it via TESTSUITE_ASSETS_DIR."
}

resolve_i3c_dev() {
  local dev="$I3C_DEV" candidate
  if [[ "$dev" != "auto" ]]; then
    [[ "$dev" == /dev/* ]] || dev="/dev/$dev"
    [[ -e "$dev" ]] || ts_fail "I3C device not found: $dev"
    printf '%s\n' "$dev"
    return
  fi
  for candidate in /dev/i3c-1-236152a0098 /dev/i3c-1-random /dev/i3c-*; do
    [[ -e "$candidate" ]] || continue
    printf '%s\n' "$candidate"
    return
  done
  ts_fail "No /dev/i3c-* device found"
}

extract_received_hex() {
  local text="$1" len="$2"
  awk '
    found { for (i = 1; i <= NF; i++) if ($i ~ /^0x[0-9a-fA-F]+$/) print $i }
    /received data:/ { found = 1; next }
  ' <<< "$text" | head -n "$len" | tr '\n' ' '
}

read_i3c_bytes() {
  local xfer="$1" dev="$2" reg="$3" len="$4" out="" rc=0 bytes=""
  set +e
  out="$($xfer -d "$dev" -w "$reg" -r "$len" 2>&1)"
  rc=$?
  set -e
  printf '%s\n' "$out" >&2
  [[ $rc -eq 0 ]] || ts_fail "i3ctransfer read failed: dev=$dev reg=$reg len=$len"
  ts_assert_not_grep 'Error: Read failed' "$out" "i3ctransfer read reported failure"
  bytes="$(extract_received_hex "$out" "$len")"
  if [[ -z "${bytes// }" ]]; then
    bytes="$(grep -Eo '0x[[:xdigit:]]+' <<< "$out" | tail -n "$len" | tr '\n' ' ')"
  fi
  [[ "$(wc -w <<< "$bytes")" -ge "$len" ]] || ts_fail "i3ctransfer returned fewer than $len byte(s): $out"
  printf '%s\n' "$bytes"
}

write_i3c_bytes() {
  local xfer="$1" dev="$2" reg="$3"
  shift 3
  local payload="$reg"
  local b
  for b in "$@"; do payload+=",$b"; done
  ts_run "i3ctransfer write $payload" "$xfer" -d "$dev" -w "$payload" -r $((1 + $#))
}

run_probe() {
  ts_log "I3C /dev nodes"
  ls -l /dev/ | grep i3c || true
  ts_log "I3C sysfs devices"
  find /sys/bus/i3c/devices -maxdepth 2 \( -type l -o -type d \) 2>/dev/null | sort || true
  ts_pass "I3C probe inspection completed"
}

run_simics_eeprom() {
  local addr readback transfer_out bytes_found out rc
  ts_need i2cdetect
  ts_need i2cget
  ts_need i2cset
  ts_need i2ctransfer
  ts_log "Running SIMICS EEPROM branch from i3c/linux/basic_i3c_rw/test_steps.pl"
  out="$(i2cdetect -l)"
  printf '%s\n' "$out"
  for bus in i2c-0 i2c-1 i2c-2; do
    ts_assert_grep "$bus" "$out" "$bus not listed by i2cdetect -l"
  done
  for addr in $I2C_EEPROM_INVALID_ADDRS; do
    set +e
    readback="$(i2cget -y "$I2C_EEPROM_INVALID_BUS" "$addr" 0 2>&1)"
    rc=$?
    set -e
    printf '%s\n' "$readback"
    if [[ $rc -eq 0 ]] && ! grep -qi 'Read failed' <<< "$readback"; then
      ts_fail "invalid EEPROM address $addr unexpectedly responded"
    fi
  done
  for addr in $I2C_EEPROM_VALID_ADDRS; do
    readback="$(i2cget -y "$I2C_EEPROM_BUS" "$addr" 0)"
    assert_hex_eq 0x00 "$readback" "EEPROM initial byte addr=$addr"
    ts_run "EEPROM write addr=$addr" i2cset -y "$I2C_EEPROM_BUS" "$addr" 0 0xBE
    readback="$(i2cget -y "$I2C_EEPROM_BUS" "$addr" 0)"
    assert_hex_eq 0xBE "$readback" "EEPROM readback addr=$addr"
  done
  for addr in $I2C_EEPROM_VALID_ADDRS; do
    transfer_out="$(i2ctransfer -y "$I2C_EEPROM_BUS" "w2@${addr}" 0x0 0x0 r8)"
    printf '%s\n' "$transfer_out"
    bytes_found="$(grep -Eo '0x[[:xdigit:]]+' <<< "$transfer_out" | wc -l)"
    [[ "$bytes_found" -eq 8 ]] || ts_fail "EEPROM transfer did not return 8 bytes for $addr"
  done
  ts_pass "SIMICS EEPROM coverage completed"
}

run_agilex5_i3c() {
  local xfer dev data temp conf write_conf read_conf tlow thigh rb_tlow rb_thigh
  xfer="$(resolve_i3ctransfer)"
  chmod +x "$xfer" 2>/dev/null || true
  dev="$(resolve_i3c_dev)"
  ts_log "Using I3C device=$dev transfer=$xfer"

  data=( $(read_i3c_bytes "$xfer" "$dev" 0x00 2) )
  [[ ${#data[@]} -ge 2 ]] || ts_fail "I3C temperature read returned fewer than 2 bytes"
  temp="$(sensor_temp_c_from_bytes "${data[0]}" "${data[1]}")"
  ts_log "Temperature register: ${data[*]} => ${temp} C"
  awk -v t="$temp" -v min="$I3C_MIN_TEMP_C" -v max="$I3C_MAX_TEMP_C" 'BEGIN { exit !(t >= min && t <= max) }' || \
    ts_fail "i3c temperature ${temp} C is outside expected ${I3C_MIN_TEMP_C}-${I3C_MAX_TEMP_C} C"

  conf=( $(read_i3c_bytes "$xfer" "$dev" 0x01 2) )
  if [[ "$(normalize_hex_byte "${conf[0]}")" == "0x00" ]]; then write_conf="0x28"; else write_conf="0x00"; fi
  write_i3c_bytes "$xfer" "$dev" 0x01 "$write_conf"
  read_conf=( $(read_i3c_bytes "$xfer" "$dev" 0x01 2) )
  assert_hex_eq "$write_conf" "${read_conf[0]}" "I3C config readback"

  write_i3c_bytes "$xfer" "$dev" 0x02 0x4B 0x00
  write_i3c_bytes "$xfer" "$dev" 0x03 0x50 0x00
  ts_log "Default T-Low readback: $(read_i3c_bytes "$xfer" "$dev" 0x02 2)"
  ts_log "Default T-High readback: $(read_i3c_bytes "$xfer" "$dev" 0x03 2)"

  tlow=( $(threshold_bytes_from_c 15) )
  thigh=( $(threshold_bytes_from_c 30) )
  write_i3c_bytes "$xfer" "$dev" 0x02 "${tlow[0]}" "${tlow[1]}"
  rb_tlow=( $(read_i3c_bytes "$xfer" "$dev" 0x02 2) )
  assert_hex_eq "${tlow[0]}" "${rb_tlow[0]}" "T-Low MSB"
  assert_hex_eq "${tlow[1]}" "${rb_tlow[1]}" "T-Low LSB"

  write_i3c_bytes "$xfer" "$dev" 0x03 "${thigh[0]}" "${thigh[1]}"
  rb_thigh=( $(read_i3c_bytes "$xfer" "$dev" 0x03 2) )
  assert_hex_eq "${thigh[0]}" "${rb_thigh[0]}" "T-High MSB"
  assert_hex_eq "${thigh[1]}" "${rb_thigh[1]}" "T-High LSB"

  ts_pass "Agilex5 I3C read/write temperature sensor flow completed"
}

case "$PROFILE" in
  agilex5) run_agilex5_i3c ;;
  simics-eeprom|eeprom) run_simics_eeprom ;;
  probe) run_probe ;;
  *) ts_fail "unknown I3C profile: $PROFILE" ;;
esac
