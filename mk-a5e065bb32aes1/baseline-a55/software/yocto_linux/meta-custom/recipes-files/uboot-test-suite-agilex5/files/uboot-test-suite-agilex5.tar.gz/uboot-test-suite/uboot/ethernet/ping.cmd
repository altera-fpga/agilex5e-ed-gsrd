# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
echo "[uboot-ethernet] Start Ethernet ping test"

if test -z "${uboot_ipaddr}"; then setenv uboot_ipaddr 192.168.9.10; fi
if test -z "${uboot_serverip}"; then setenv uboot_serverip 192.168.9.100; fi
if test -z "${uboot_ping_ip}"; then setenv uboot_ping_ip ${uboot_serverip}; fi
if test -z "${uboot_netmask}"; then setenv uboot_netmask 255.255.255.0; fi

setenv autoload no
if test -n "${uboot_ethaddr}"; then
  if test -z "${ethaddr}"; then
    setenv ethaddr ${uboot_ethaddr}
  else
    echo "[uboot-ethernet] keeping existing ethaddr=${ethaddr}"
  fi
fi
setenv ipaddr ${uboot_ipaddr}
setenv serverip ${uboot_serverip}
setenv netmask ${uboot_netmask}
if test -n "${uboot_gatewayip}"; then setenv gatewayip ${uboot_gatewayip}; fi

if printenv ethaddr ipaddr serverip netmask gatewayip autoload; then
  echo "[uboot-ethernet] network environment printed"
else
  echo "[FAIL] printenv network settings failed"
  exit 1
fi

if dhcp; then
  echo "[uboot-ethernet] DHCP completed"
else
  echo "[uboot-ethernet] DHCP failed or unavailable; continue with configured static IP"
fi

if ping ${uboot_ping_ip}; then
  echo "[PASS] U-Boot Ethernet ping target is alive: ${uboot_ping_ip}"
else
  echo "[FAIL] U-Boot Ethernet ping failed: ${uboot_ping_ip}"
  exit 1
fi
