#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: networking/linux/ETH/Config1/iperf3_test/test_steps.sh
# Safety tags: performance,network,multiboard
# Review './ts info ethernet/iperf-client' for setup, pass criteria, and recovery notes.
# iperf3 throughput test – shell port for ETH/Config1/iperf3_test
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="iperf3-test"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

if [ "${1:-}" = "--desc" ]; then
  echo "Run Iperf3 test in client or server mode between two DUTs."
  exit 0
fi

if [ "${1:-}" = "--help" ] || [ "${1:-}" = "-h" ]; then
  cat <<'EOF'
Usage:
  test_steps.sh server
  test_steps.sh <server-ip>

Examples:
  test_steps.sh server
  test_steps.sh 192.168.9.100
  IPERF_SERVER_IP=192.168.9.100 test_steps.sh

Environment:
  IPERF_PACKET_SIZES="64 128 256 512 1024 2048 4096 8192 9000"
  IPERF_BIND_IP=<local-ip>       # server bind IP, auto from NET_IFACE when unset
  IPERF_SERVER_LIFETIME_SEC=90   # background server lifetime for --background-server
EOF
  exit 0
fi

: "${NET_IFACE:=eth0}"
: "${IPERF_TIME_SEC:=10}"
: "${IPERF_PACKET_SIZES:=64 128 256 512 1024 2048 4096 8192 9000}"
: "${IPERF_SERVER_LIFETIME_SEC:=90}"
: "${IPERF_BIND_IP:=}"
: "${TARGET:=BOARD}"

TMP_OUT=""
cleanup() { [[ -n "${TMP_OUT:-}" ]] && rm -f "$TMP_OUT"; }
trap cleanup EXIT

MODE="client"
if [ "${1:-}" = "server" ] || [ "${1:-}" = "--server" ] || [ "${1:-}" = "-s" ]; then
    MODE="server"
    shift || true
elif [ "${1:-}" = "--background-server" ]; then
    MODE="background-server"
    shift || true
fi

if ! command -v iperf3 >/dev/null 2>&1; then
    ts_fail "iperf3 not found in PATH – please install iperf3 on this system"
fi

ts_log "Dumping network configuration (Perl flow: ifconfig)"
if command -v ifconfig >/dev/null 2>&1; then
    ifconfig
else
    ip addr show
fi
ip -4 addr show "$NET_IFACE" || ts_fail "Interface $NET_IFACE not found"
if [ -z "$IPERF_BIND_IP" ]; then
    IPERF_BIND_IP="$(ip -4 addr show "$NET_IFACE" | awk '/inet / {print $2}' | head -n1 | cut -d/ -f1)"
fi

run_live_with_log() {
    local logfile="$1"; shift
    local cmd=( "$@" )
    if command -v stdbuf >/dev/null 2>&1; then
        cmd=( stdbuf -oL -eL "${cmd[@]}" )
    fi
    if ! "${cmd[@]}" 2>&1 | tee "$logfile"; then
        return 1
    fi
    return 0
}

if [ "$MODE" = "background-server" ]; then
    ts_log "Starting Perl-compatible background server on ${IPERF_BIND_IP:-0.0.0.0} for ${IPERF_SERVER_LIFETIME_SEC}s"
    nohup bash -c "iperf3 -s -B ${IPERF_BIND_IP:-0.0.0.0} > /dev/null 2>&1 & sleep ${IPERF_SERVER_LIFETIME_SEC}; pkill iperf3" > /dev/null 2>&1 &
    ts_pass "background iperf3 server launched"
    exit 0
fi

if [ "$MODE" = "server" ]; then
    ts_log "Running in SERVER mode"
    TMP_OUT="$(mktemp /tmp/iperf3_server.XXXXXX)"
    ts_log "Starting iperf3 server (single-connection, then exit) bound to ${IPERF_BIND_IP:-0.0.0.0}"
    echo "---------- iperf3 output begin ----------"
    if ! run_live_with_log "$TMP_OUT" iperf3 -s -B "${IPERF_BIND_IP:-0.0.0.0}" -1; then
        echo "---------- iperf3 output end   ----------"
        echo "Log file: $TMP_OUT"
        ts_fail "iperf3 server exited with error (see output above)"
    fi
    echo "---------- iperf3 output end   ----------"
    if ! grep -q "receiver" "$TMP_OUT"; then
        rm -f "$TMP_OUT"
        ts_fail "Did not find 'receiver' summary line in iperf3 server output – treating as failure"
    fi
    rm -f "$TMP_OUT"
    ts_pass "iperf3 SERVER test PASSED (see above for measured bandwidth)"
    exit 0
fi

ts_log "Running in CLIENT mode"
SERVER_IP="${1:-}"
: "${IPERF_SERVER_IP:=}"
if [ -z "$SERVER_IP" ] && [ -n "$IPERF_SERVER_IP" ]; then
    SERVER_IP="$IPERF_SERVER_IP"
fi

if [ -z "$SERVER_IP" ]; then
    ts_fail "No iperf3 server IP provided. Use:
  test_steps.sh <server-ip>
or set IPERF_SERVER_IP, or run in server mode:
  test_steps.sh server"
fi

ts_log "Using iperf3 server IP: $SERVER_IP"
ts_log "Test duration: ${IPERF_TIME_SEC}s"
TMP_OUT="$(mktemp /tmp/iperf3_client.XXXXXX)"
ts_log "Running: iperf3 -c $SERVER_IP -t $IPERF_TIME_SEC"
echo "---------- iperf3 output begin ----------"
if ! run_live_with_log "$TMP_OUT" iperf3 -c "$SERVER_IP" -t "$IPERF_TIME_SEC"; then
    echo "---------- iperf3 output end   ----------"
    echo "Log file: $TMP_OUT"
    ts_fail "iperf3 client exited with error (see output above)"
fi
echo "---------- iperf3 output end   ----------"
if ! grep -q "receiver" "$TMP_OUT"; then
    rm -f "$TMP_OUT"
    ts_fail "Did not find 'receiver' summary line in iperf3 output – treating as failure"
fi
rm -f "$TMP_OUT"
ts_pass "iperf3 CLIENT test PASSED (see above for measured bandwidth)"
exit 0