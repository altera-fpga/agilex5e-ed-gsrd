# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from qspi/uboot/qspi_access/test_steps.pl
echo "[uboot-qspi-access] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] sf probe"
  if sf probe; then
    echo "[OK] sf probe"
  else
    echo "[FAIL] command failed: sf probe"
    exit 1
  fi
  echo "[cmd] sf erase 0x06000000 100000"
  if sf erase 0x06000000 100000; then
    echo "[OK] sf erase 0x06000000 100000"
  else
    echo "[FAIL] command failed: sf erase 0x06000000 100000"
    exit 1
  fi
  echo "[cmd] mw 0x10000 FACECAFE"
  if mw 0x10000 FACECAFE; then
    echo "[OK] mw 0x10000 FACECAFE"
  else
    echo "[FAIL] command failed: mw 0x10000 FACECAFE"
    exit 1
  fi
  echo "[cmd] md 0x10000 1"
  if md 0x10000 1; then
    echo "[OK] md 0x10000 1"
  else
    echo "[FAIL] command failed: md 0x10000 1"
    exit 1
  fi
  echo "[cmd] sf write 0x10000 0x06000000 4"
  if sf write 0x10000 0x06000000 4; then
    echo "[OK] sf write 0x10000 0x06000000 4"
  else
    echo "[FAIL] command failed: sf write 0x10000 0x06000000 4"
    exit 1
  fi
  echo "[cmd] sf read 0x20000 0x06000000 4"
  if sf read 0x20000 0x06000000 4; then
    echo "[OK] sf read 0x20000 0x06000000 4"
  else
    echo "[FAIL] command failed: sf read 0x20000 0x06000000 4"
    exit 1
  fi
  echo "[cmd] md 0x20000 1"
  if md 0x20000 1; then
    echo "[OK] md 0x20000 1"
  else
    echo "[FAIL] command failed: md 0x20000 1"
    exit 1
  fi
  echo "[cmd] reset"
  echo "[INFO] reset command should reboot the board; script fails if it returns"
  reset
  echo "[FAIL] reset command returned unexpectedly"
  exit 1
  echo "[cmd] sf probe"
  if sf probe; then
    echo "[OK] sf probe"
  else
    echo "[FAIL] command failed: sf probe"
    exit 1
  fi
  echo "[cmd] sf read 0x30000 0x06000000 4"
  if sf read 0x30000 0x06000000 4; then
    echo "[OK] sf read 0x30000 0x06000000 4"
  else
    echo "[FAIL] command failed: sf read 0x30000 0x06000000 4"
    exit 1
  fi
  echo "[cmd] md 0x30000 1"
  if md 0x30000 1; then
    echo "[OK] md 0x30000 1"
  else
    echo "[FAIL] command failed: md 0x30000 1"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
