#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: sdmmc/linux/sd_info/test_steps.sh
# Safety tags: sdmmc,storage,smoke
# Review './ts info sdmmc/sd-info' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="sd-info"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="List SD/MMC devices and run the Perl-equivalent mount/touch/umount check."

usage() {
  cat <<'EOF_USAGE'
Usage:
  test_steps.sh [--yes] [block-device]

Environment:
  SDMMC_DEV=/dev/mmcblk0
  SDMMC_PARTITION=/dev/mmcblk0p1
  SDMMC_MOUNT_RW=0
  TESTSUITE_ALLOW_DESTRUCTIVE=1

The Perl regtest mounts the first partition read-write, creates abc.txt, checks
it, then unmounts. This shell script keeps read-only as the default customer
mode and runs the exact write check only when SDMMC_MOUNT_RW=1 and armed.
EOF_USAGE
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

CONFIRMED=0
if [[ "${1:-}" == "--yes" ]]; then CONFIRMED=1; shift; fi

: "${SDMMC_DEV:=/dev/mmcblk0}"
: "${SDMMC_PARTITION:=${SDMMC_DEV}p1}"
: "${SDMMC_MOUNT_RW:=0}"

DEV="${1:-$SDMMC_DEV}"
PART="$SDMMC_PARTITION"

ts_need lsblk
ts_need fdisk
ts_need mount
ts_need umount
[[ -b "$DEV" ]] || ts_fail "block device not found: $DEV"

ts_log "Detected /dev/mmcblk* nodes"
ls /dev/mmcblk* 2>/dev/null || true
ts_log "fdisk layout"
fdisk -l

ts_log "Block layout"
lsblk -o NAME,MAJ:MIN,SIZE,TYPE,FSTYPE,MOUNTPOINTS

[[ -b "$PART" ]] || ts_fail "partition not found: $PART"
MNT="$(mktemp -d /tmp/sd-info.XXXXXX)"
cleanup() { mountpoint -q "$MNT" && umount "$MNT" || true; rmdir "$MNT" 2>/dev/null || true; }
trap cleanup EXIT

if [[ "$SDMMC_MOUNT_RW" == "1" ]]; then
  ts_require_root
  ts_require_destructive "$CONFIRMED"
  ts_run "mount $PART" mount "$PART" "$MNT"
  ls "$MNT"
  ts_run "touch abc.txt" touch "$MNT/abc.txt"
  [[ -e "$MNT/abc.txt" ]] || ts_fail "abc.txt was not created"
  ls "$MNT/abc.txt"
else
  ts_run "mount -o ro $PART" mount -o ro "$PART" "$MNT"
  ls "$MNT"
fi

cd /
ts_run "umount $MNT" umount "$MNT"
ts_pass "SD/MMC mount check completed"
