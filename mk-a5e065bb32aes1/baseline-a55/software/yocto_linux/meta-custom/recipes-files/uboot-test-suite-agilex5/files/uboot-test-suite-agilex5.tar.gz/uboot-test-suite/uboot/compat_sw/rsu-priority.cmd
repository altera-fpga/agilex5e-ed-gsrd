# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_sw/uboot/rsu_priority/test_steps.pl
echo "[uboot-rsu-priority] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] iminfo"
  if iminfo; then
    echo "[OK] iminfo"
  else
    echo "[FAIL] command failed: iminfo"
    exit 1
  fi
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[cmd] rsu slot_enable 1"
  if rsu slot_enable 1; then
    echo "[OK] rsu slot_enable 1"
  else
    echo "[FAIL] command failed: rsu slot_enable 1"
    exit 1
  fi
  echo "[cmd] rsu slot_get_info 1"
  if rsu slot_get_info 1; then
    echo "[OK] rsu slot_get_info 1"
  else
    echo "[FAIL] command failed: rsu slot_get_info 1"
    exit 1
  fi
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
