#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: qspi/linux/qspi_rw/test_steps.sh
# Safety tags: qspi,flash,destructive-op
# Review './ts info qspi/qspi-rw' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="qspi-rw"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Erase/write/read/compare an MTD NOR region. Destructive; requires explicit opt-in."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh [--yes] [mtd-dev] [offset] [size]

Environment:
  QSPI_MTD_DEV=/dev/mtd0
  QSPI_RW_OFFSET=0x06000000
  QSPI_RW_SIZE=0x10000
  QSPI_ERASE_SIZE=0x10000
  QSPI_PATTERN_FILE=<file>
  QSPI_REGTEST_COMPAT=0       # 1 = use Perl flow values: /dev/mtd0 offset 0, erase 20 MiB, write/read 2,048,000 bytes
  TESTSUITE_ALLOW_DESTRUCTIVE=1

Examples:
  TESTSUITE_ALLOW_DESTRUCTIVE=1 test_steps.sh --yes /dev/mtd0 0x06000000 0x10000

Notes:
  - This test erases flash. Choose an unused, board-approved offset.
  - The default offset intentionally points away from common boot regions, but must still be reviewed per board image layout.
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

CONFIRMED=0
if [[ "${1:-}" == "--yes" ]]; then CONFIRMED=1; shift; fi

: "${QSPI_REGTEST_COMPAT:=0}"
if [[ "$QSPI_REGTEST_COMPAT" == "1" ]]; then
  : "${QSPI_MTD_DEV:=/dev/mtd0}"
  : "${QSPI_RW_OFFSET:=0}"
  : "${QSPI_RW_SIZE:=2048000}"
  : "${QSPI_ERASE_SIZE:=20971520}"
else
  : "${QSPI_MTD_DEV:=/dev/mtd0}"
  : "${QSPI_RW_OFFSET:=0x06000000}"
  : "${QSPI_RW_SIZE:=0x10000}"
  : "${QSPI_ERASE_SIZE:=$QSPI_RW_SIZE}"
fi

MTD_DEV="${1:-$QSPI_MTD_DEV}"
OFFSET="${2:-$QSPI_RW_OFFSET}"
SIZE="${3:-$QSPI_RW_SIZE}"
ERASE_SIZE="${QSPI_ERASE_SIZE}"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  ts_fail "must run as root because this test accesses MTD flash"
fi

if [[ "$CONFIRMED" -ne 1 || "${TESTSUITE_ALLOW_DESTRUCTIVE:-0}" != "1" ]]; then
  ts_fail "destructive flash test not armed. Re-run with both TESTSUITE_ALLOW_DESTRUCTIVE=1 and --yes after confirming the offset is safe."
fi

ts_need dd
ts_need cmp
ts_need md5sum
ts_need hexdump
ts_need mtd_debug

[[ -c "$MTD_DEV" || -e "$MTD_DEV" ]] || ts_fail "MTD device not found: $MTD_DEV"

WORKDIR="$(mktemp -d /tmp/qspi-rw.XXXXXX)"
cleanup() { rm -rf "$WORKDIR"; }
trap cleanup EXIT

SRC="$WORKDIR/write.bin"
DST="$WORKDIR/read.bin"

ts_log "Device      : $MTD_DEV"
ts_log "Offset      : $OFFSET"
ts_log "Size        : $SIZE"
ts_log "Erase size  : $ERASE_SIZE"

ts_log "MTD layout"
cat /proc/mtd || true
[[ -e "$MTD_DEV" ]] || ts_fail "MTD device not present: $MTD_DEV"
ts_log "QSPI kernel log sample"
dmesg | grep -iE 'spi-nor|cadence|qspi|mtd' | tail -30 || true

if [[ -n "${QSPI_PATTERN_FILE:-}" ]]; then
  [[ -f "$QSPI_PATTERN_FILE" ]] || ts_fail "QSPI_PATTERN_FILE not found: $QSPI_PATTERN_FILE"
  dd if="$QSPI_PATTERN_FILE" of="$SRC" bs=1 count=$((SIZE)) status=none
else
  dd if=/dev/urandom of="$SRC" bs=1 count=$((SIZE)) status=none
fi

ts_log "Erasing flash region"
mtd_debug erase "$MTD_DEV" "$OFFSET" "$ERASE_SIZE"

ts_log "Writing pattern"
mtd_debug write "$MTD_DEV" "$OFFSET" "$SIZE" "$SRC"

ts_log "Reading back"
mtd_debug read "$MTD_DEV" "$OFFSET" "$SIZE" "$DST"

ts_log "Checksums"
md5sum "$SRC" "$DST"

# Keep the exact Perl-regtest comparison command available in the shell flow.
ts_run "diff written and read images" diff -q "$SRC" "$DST"
if cmp -s "$SRC" "$DST"; then
  ts_pass "readback matches written image"
else
  echo "---------- expected ----------"
  hexdump -C "$SRC" | head
  echo "---------- actual ------------"
  hexdump -C "$DST" | head
  ts_fail "readback mismatch"
fi
