# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
echo "[uboot-qspi] Start QSPI read/write test"

if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive QSPI write test not armed. Set uboot_allow_destructive=1 to run."
  exit 0
fi

if test -z "${uboot_qspi_offset}"; then setenv uboot_qspi_offset 0x06000000; fi
if test -z "${uboot_qspi_erase_size}"; then setenv uboot_qspi_erase_size 0x100000; fi
if test -z "${uboot_qspi_size}"; then setenv uboot_qspi_size 0x100; fi
if test -z "${uboot_qspi_pattern}"; then setenv uboot_qspi_pattern 0xa5; fi
if test -z "${uboot_pattern_addr}"; then setenv uboot_pattern_addr ${loadaddr}; fi
if test -z "${uboot_read_addr}"; then setexpr uboot_read_addr ${loadaddr} + 0x1000; fi

echo "[uboot-qspi] pattern addr : ${uboot_pattern_addr}"
echo "[uboot-qspi] readback addr: ${uboot_read_addr}"
echo "[uboot-qspi] flash offset : ${uboot_qspi_offset}"
echo "[uboot-qspi] erase size   : ${uboot_qspi_erase_size}"
echo "[uboot-qspi] rw size      : ${uboot_qspi_size}"

if sf probe; then
  echo "[uboot-qspi] sf probe OK"
else
  echo "[FAIL] sf probe failed"
  exit 1
fi

if sf erase ${uboot_qspi_offset} ${uboot_qspi_erase_size}; then
  echo "[uboot-qspi] erase OK"
else
  echo "[FAIL] sf erase failed"
  exit 1
fi

if mw.b ${uboot_pattern_addr} ${uboot_qspi_pattern} ${uboot_qspi_size}; then
  echo "[uboot-qspi] pattern buffer prepared"
else
  echo "[FAIL] pattern buffer preparation failed"
  exit 1
fi

if mw.b ${uboot_read_addr} 0x00 ${uboot_qspi_size}; then
  echo "[uboot-qspi] readback buffer cleared"
else
  echo "[FAIL] readback buffer clear failed"
  exit 1
fi

if sf write ${uboot_pattern_addr} ${uboot_qspi_offset} ${uboot_qspi_size}; then
  echo "[uboot-qspi] write OK"
else
  echo "[FAIL] sf write failed"
  exit 1
fi

if sf read ${uboot_read_addr} ${uboot_qspi_offset} ${uboot_qspi_size}; then
  echo "[uboot-qspi] read OK"
else
  echo "[FAIL] sf read failed"
  exit 1
fi

if cmp.b ${uboot_pattern_addr} ${uboot_read_addr} ${uboot_qspi_size}; then
  echo "[PASS] U-Boot QSPI read/write compare passed"
else
  echo "[FAIL] U-Boot QSPI read/write compare failed"
  exit 1
fi
