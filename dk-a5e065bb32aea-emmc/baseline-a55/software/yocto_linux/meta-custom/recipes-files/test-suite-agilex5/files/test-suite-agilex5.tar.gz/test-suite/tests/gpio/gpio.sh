#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: gpio/linux/gpio_toggle/test_steps.sh
# Safety tags: gpio,smoke
# Review './ts info gpio/gpio' for setup, pass criteria, and recovery notes.
# GPIO toggle test – shell port of gpio/linux/gpio_toggle/test_steps.pl
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="gpio-toggle"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

if [ "${1:-}" = "--desc" ]; then
  echo "Toggle GPIO pin and verify the readback."
  exit 0
fi

if [ "${1:-}" = "--help" ] || [ "${1:-}" = "-h" ]; then
  cat <<'EOF_HELP'
Usage:
  test_steps.sh [gpio-pin]

Examples:
  test_steps.sh
  test_steps.sh 512

Notes:
  - Requires root because it writes to /sys/class/gpio/export
  - Uses the legacy sysfs GPIO interface
EOF_HELP
   exit 0
fi

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  if command -v sudo >/dev/null 2>&1; then exec sudo -E "$0" "$@"; fi
  ts_fail "must run as root (or install sudo)."
fi

# -------------------------------------------------------------------
# Configuration (override with env vars or CLI)
# -------------------------------------------------------------------
# Priority for pin selection:
#   1) CLI arg: ./test-suite run gpio gpio-toggle-test <gpio-pin>
#   2) GPIO_PIN env var
#   3) Default: 512 (to match original test)
GPIO_PIN="${1:-${GPIO_PIN:-512}}"

SYSFS_GPIO_DIR="/sys/class/gpio"
GPIO_PIN_DIR="${SYSFS_GPIO_DIR}/gpio${GPIO_PIN}"


# -------------------------------------------------------------------
# 1. Check that /sys/class/gpio exists
# -------------------------------------------------------------------
if [ ! -d "$SYSFS_GPIO_DIR" ]; then
    ts_fail "GPIO sysfs directory not found at $SYSFS_GPIO_DIR (is GPIO enabled in kernel?)"
fi

ts_log "Listing $SYSFS_GPIO_DIR:"
ls "$SYSFS_GPIO_DIR"

# -------------------------------------------------------------------
# 2. Export the pin
# -------------------------------------------------------------------
ts_log "Exporting GPIO pin $GPIO_PIN"
if [ -d "$GPIO_PIN_DIR" ]; then
    ts_log "GPIO $GPIO_PIN already exported, unexporting first"
    echo "$GPIO_PIN" > "${SYSFS_GPIO_DIR}/unexport" || ts_fail "Failed to unexport pre-existing GPIO$GPIO_PIN"
fi

echo "$GPIO_PIN" > "${SYSFS_GPIO_DIR}/export" || ts_fail "Failed to export GPIO$GPIO_PIN"

if [ ! -d "$GPIO_PIN_DIR" ]; then
    sleep 0.1
fi

if [ ! -d "$GPIO_PIN_DIR" ]; then
    ts_fail "GPIO pin directory $GPIO_PIN_DIR not found after export"
fi

ts_log "GPIO pin directory exists: $GPIO_PIN_DIR"

# -------------------------------------------------------------------
# 3. Read current direction, then set to 'out'
# -------------------------------------------------------------------
DIR_FILE="${GPIO_PIN_DIR}/direction"
VAL_FILE="${GPIO_PIN_DIR}/value"

if [ ! -f "$DIR_FILE" ]; then
    ts_fail "Direction file not found: $DIR_FILE"
fi
if [ ! -f "$VAL_FILE" ]; then
    ts_fail "Value file not found: $VAL_FILE"
fi

CUR_DIR="$(cat "$DIR_FILE")"
ts_log "Current direction of GPIO$GPIO_PIN: '$CUR_DIR'"

ts_log "Setting direction of GPIO$GPIO_PIN to 'out'"
echo "out" > "$DIR_FILE" || ts_fail "Failed to set direction to 'out'"

NEW_DIR="$(cat "$DIR_FILE")"
ts_log "New direction of GPIO$GPIO_PIN: '$NEW_DIR'"

if [ "$NEW_DIR" != "out" ]; then
    ts_fail "Direction readback mismatch: expected 'out', got '$NEW_DIR'"
fi

# -------------------------------------------------------------------
# 4. Toggle value: 0 then 1, verifying each
# -------------------------------------------------------------------
ts_log "Writing 0 to GPIO$GPIO_PIN"
echo "0" > "$VAL_FILE" || ts_fail "Failed to write 0 to value file"
VAL0="$(cat "$VAL_FILE")"
ts_log "Readback after 0: $VAL0"
if [ "$VAL0" != "0" ]; then
    ts_fail "Value readback mismatch after writing 0 (got '$VAL0')"
fi

ts_log "Writing 1 to GPIO$GPIO_PIN"
echo "1" > "$VAL_FILE" || ts_fail "Failed to write 1 to value file"
VAL1="$(cat "$VAL_FILE")"
ts_log "Readback after 1: $VAL1"
if [ "$VAL1" != "1" ]; then
    ts_fail "Value readback mismatch after writing 1 (got '$VAL1')"
fi

# -------------------------------------------------------------------
# 5. Unexport the pin and confirm removal
# -------------------------------------------------------------------
ts_log "Unexporting GPIO$GPIO_PIN"
echo "$GPIO_PIN" > "${SYSFS_GPIO_DIR}/unexport" || ts_fail "Failed to unexport GPIO$GPIO_PIN"

sleep 0.1

if [ -d "$GPIO_PIN_DIR" ]; then
    ts_fail "GPIO pin directory $GPIO_PIN_DIR still exists after unexport"
fi

ts_pass "GPIO toggle test PASSED for pin $GPIO_PIN"
exit 0