#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: usb/linux/usb3_rw/test_steps.sh
# Safety tags: usb,storage,opt-in,destructive-op,requires-usb3
# Review './ts info usb/usb-rw' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="usb3-rw"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Run USB storage mount/write/remove flow equivalent to the USB Perl rw test."

usage() {
  cat <<'EOF_USAGE'
Usage:
  test_steps.sh [--yes] [partition]

Environment:
  USB_PARTITION=/dev/sda1
  USB_MOUNT_RW=0
  USB_LARGE_WRITE=0            # USB3 Perl flow: 1 GiB random write when enabled
  TESTSUITE_ALLOW_DESTRUCTIVE=1

Default mode mounts read-only. The Perl flow mounts read-write, creates
empty_file.txt, lists it, removes it, and verifies removal; enable with
USB_MOUNT_RW=1 plus --yes or TESTSUITE_ALLOW_DESTRUCTIVE=1.
EOF_USAGE
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

CONFIRMED=0
if [[ "${1:-}" == "--yes" ]]; then CONFIRMED=1; shift; fi

: "${USB_PARTITION:=/dev/sda1}"
: "${USB_MOUNT_RW:=0}"
: "${USB_LARGE_WRITE:=0}"
PART="${1:-$USB_PARTITION}"

ts_need fdisk
ts_need mount
ts_need umount
ts_need df
[[ -b "$PART" ]] || ts_fail "USB partition not found: $PART"

ts_log "USB/block partition table"
fdisk -l

MNT="/media/usb-drive"
mkdir -p "$MNT"
cleanup() { mountpoint -q "$MNT" && umount "$MNT" || true; }
trap cleanup EXIT

if [[ "$USB_MOUNT_RW" == "1" ]]; then
  ts_require_root
  ts_require_destructive "$CONFIRMED"
  ts_run "mount $PART $MNT" mount "$PART" "$MNT"
  (
    cd "$MNT"
    df -h "$MNT"
    ts_run "create 1 KiB sparse file" dd if=/dev/zero of=empty_file.txt bs=1 count=1 seek=1023
    if [[ "$USB_LARGE_WRITE" == "1" ]]; then
      ts_log "Running optional USB3 1 GiB random write from Perl flow"
      time dd if=/dev/random of=empty_file.txt bs=1M count=1024
    fi
    ls -l
    [[ -e empty_file.txt ]] || ts_fail "empty_file.txt was not created"
    rm empty_file.txt
    if ls empty_file.txt >/dev/null 2>&1; then
      ts_fail "empty_file.txt still exists after rm"
    fi
  )
else
  ts_run "mount -o ro $PART $MNT" mount -o ro "$PART" "$MNT"
  (
    cd "$MNT"
    df -h "$MNT"
    ls -l | head -40 || true
  )
fi

cd ~
ts_run "umount $MNT" umount "$MNT"
ts_pass "USB3 storage rw check completed"
