# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
echo "[uboot-i2c] Start I2C detect/read smoke test"

if test -z "${uboot_i2c_bus}"; then setenv uboot_i2c_bus 0; fi
if test -z "${uboot_i2c_addr}"; then setenv uboot_i2c_addr; fi
if test -z "${uboot_i2c_reg}"; then setenv uboot_i2c_reg 0x0; fi

if i2c bus; then
  echo "[uboot-i2c] i2c bus list OK"
else
  echo "[FAIL] i2c bus failed"
  exit 1
fi

if i2c dev ${uboot_i2c_bus}; then
  echo "[uboot-i2c] selected bus ${uboot_i2c_bus}"
else
  echo "[FAIL] i2c dev ${uboot_i2c_bus} failed"
  exit 1
fi

if i2c probe; then
  echo "[uboot-i2c] i2c probe OK"
else
  echo "[FAIL] i2c probe failed"
  exit 1
fi

if test -n "${uboot_i2c_addr}"; then
  if i2c md ${uboot_i2c_addr} ${uboot_i2c_reg} 1; then
    echo "[uboot-i2c] read OK from addr ${uboot_i2c_addr} reg ${uboot_i2c_reg}"
  else
    echo "[FAIL] i2c md failed for addr ${uboot_i2c_addr} reg ${uboot_i2c_reg}"
    exit 1
  fi
else
  echo "[uboot-i2c] uboot_i2c_addr not set; probe-only smoke test completed"
fi

echo "[PASS] U-Boot I2C command sequence completed"
