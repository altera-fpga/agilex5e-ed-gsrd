#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: fpga_bridge/linux/lwhps2fpga_rw/test_steps.sh
# Safety tags: fpga,bridge,opt-in
# Review './ts info fpga/lwhps2fpga-read' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="lwhps2fpga"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Optional Lightweight HPS-to-FPGA bridge devmem read/write smoke test."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh

Environment:
  BRIDGE_ADDR=0xf9000000
  BRIDGE_EXPECTED=
  BRIDGE_WRITE_VALUE=
  TESTSUITE_ALLOW_DESTRUCTIVE=1

Notes:
  - Default mode reads one 32-bit word only.
  - Writes require BRIDGE_WRITE_VALUE and TESTSUITE_ALLOW_DESTRUCTIVE=1.
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${BRIDGE_ADDR:=0xff200000}"
command -v devmem2 >/dev/null 2>&1 || command -v devmem >/dev/null 2>&1 || ts_fail "devmem2/devmem not found"

cleanup() { rm -f /tmp/lwhps2fpga_read.$$; }
trap cleanup EXIT

read_word() {
  if command -v devmem2 >/dev/null 2>&1; then devmem2 "$BRIDGE_ADDR" | tee /tmp/hps2fpga_read.$$; else devmem "$BRIDGE_ADDR" 32 | tee /tmp/hps2fpga_read.$$; fi
}

ts_log "Reading bridge address $BRIDGE_ADDR"
read_word

if [[ -n "${BRIDGE_EXPECTED:-}" ]] && ! grep -qi "${BRIDGE_EXPECTED#0x}" /tmp/hps2fpga_read.$$; then
  ts_fail "expected value $BRIDGE_EXPECTED not observed"
fi

if [[ -n "${BRIDGE_WRITE_VALUE:-}" ]]; then
  [[ "${TESTSUITE_ALLOW_DESTRUCTIVE:-0}" == "1" ]] || ts_fail "write not armed. Set TESTSUITE_ALLOW_DESTRUCTIVE=1."
  ts_log "Writing $BRIDGE_WRITE_VALUE to $BRIDGE_ADDR"
  if command -v devmem2 >/dev/null 2>&1; then devmem2 "$BRIDGE_ADDR" w "$BRIDGE_WRITE_VALUE"; else devmem "$BRIDGE_ADDR" 32 "$BRIDGE_WRITE_VALUE"; fi
fi
rm -f /tmp/hps2fpga_read.$$
ts_pass "Lightweight HPS-to-FPGA bridge check completed"
