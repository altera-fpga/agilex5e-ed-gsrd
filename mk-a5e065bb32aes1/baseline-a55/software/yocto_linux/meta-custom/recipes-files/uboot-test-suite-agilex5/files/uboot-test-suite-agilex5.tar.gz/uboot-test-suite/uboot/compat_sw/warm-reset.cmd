# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_sw/uboot/warm_reset/test_steps.pl
echo "[uboot-warm-reset] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] setexpr newaddr $loadaddr + 0x06000000"
  setexpr newaddr $loadaddr + 0x06000000
  echo "[cmd] mw 2000000 aaaaaaaa 1"
  if mw 2000000 aaaaaaaa 1; then
    echo "[OK] mw 2000000 aaaaaaaa 1"
  else
    echo "[FAIL] command failed: mw 2000000 aaaaaaaa 1"
    exit 1
  fi
  echo "[cmd] mw $loadaddr aaaaaaaa 1"
  if mw $loadaddr aaaaaaaa 1; then
    echo "[OK] mw $loadaddr aaaaaaaa 1"
  else
    echo "[FAIL] command failed: mw $loadaddr aaaaaaaa 1"
    exit 1
  fi
  echo "[cmd] md $loadaddr 4"
  if md $loadaddr 4; then
    echo "[OK] md $loadaddr 4"
  else
    echo "[FAIL] command failed: md $loadaddr 4"
    exit 1
  fi
  echo "[cmd] mw 8000000 aaaaaaaa 1"
  if mw 8000000 aaaaaaaa 1; then
    echo "[OK] mw 8000000 aaaaaaaa 1"
  else
    echo "[FAIL] command failed: mw 8000000 aaaaaaaa 1"
    exit 1
  fi
  echo "[cmd] version"
  if version; then
    echo "[OK] version"
  else
    echo "[FAIL] command failed: version"
    exit 1
  fi
  echo "[cmd] reset -w"
  echo "[INFO] reset command should reboot the board; script fails if it returns"
  reset -w
  echo "[FAIL] reset command returned unexpectedly"
  exit 1
  echo "[cmd] setenv reset warm"
  setenv reset warm
  echo "[cmd] reset"
  echo "[INFO] reset command should reboot the board; script fails if it returns"
  reset
  echo "[FAIL] reset command returned unexpectedly"
  exit 1
  echo "[cmd] setexpr newaddr $loadaddr + 0x06000000"
  setexpr newaddr $loadaddr + 0x06000000
  echo "[cmd] md 2000000 4"
  if md 2000000 4; then
    echo "[OK] md 2000000 4"
  else
    echo "[FAIL] command failed: md 2000000 4"
    exit 1
  fi
  echo "[cmd] md $loadaddr 4"
  if md $loadaddr 4; then
    echo "[OK] md $loadaddr 4"
  else
    echo "[FAIL] command failed: md $loadaddr 4"
    exit 1
  fi
  echo "[cmd] md 8000000 4"
  if md 8000000 4; then
    echo "[OK] md 8000000 4"
  else
    echo "[FAIL] command failed: md 8000000 4"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
