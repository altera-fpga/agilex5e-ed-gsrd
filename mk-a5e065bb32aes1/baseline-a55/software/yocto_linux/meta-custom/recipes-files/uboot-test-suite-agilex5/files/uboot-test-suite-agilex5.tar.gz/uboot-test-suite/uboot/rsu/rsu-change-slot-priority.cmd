# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/rsu_change_slot_priority/test_steps.pl
echo "[uboot-rsu-change-slot-priority] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] setenv autoload no"
  setenv autoload no
  echo "[cmd] printenv"
  if printenv; then
    echo "[OK] printenv"
  else
    echo "[FAIL] command failed: printenv"
    exit 1
  fi
  echo "[cmd] setenv ethaddr 00:df:00:33:56:00"
  setenv ethaddr 00:df:00:33:56:00
  echo "[cmd] dhcp"
  if dhcp; then
    echo "[OK] dhcp"
  else
    echo "[FAIL] command failed: dhcp"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] fatwrite mmc 0:1 $loadaddr app.rpd $filesize"
  if fatwrite mmc 0:1 $loadaddr app.rpd $filesize; then
    echo "[OK] fatwrite mmc 0:1 $loadaddr app.rpd $filesize"
  else
    echo "[FAIL] command failed: fatwrite mmc 0:1 $loadaddr app.rpd $filesize"
    exit 1
  fi
  echo "[cmd] fatrm mmc 0:1 u-boot.itb"
  if fatrm mmc 0:1 u-boot.itb; then
    echo "[OK] fatrm mmc 0:1 u-boot.itb"
  else
    echo "[FAIL] command failed: fatrm mmc 0:1 u-boot.itb"
    exit 1
  fi
  echo "[cmd] fatls mmc 0"
  if fatls mmc 0; then
    echo "[OK] fatls mmc 0"
  else
    echo "[FAIL] command failed: fatls mmc 0"
    exit 1
  fi
  echo "[cmd] dcache off"
  if dcache off; then
    echo "[OK] dcache off"
  else
    echo "[FAIL] command failed: dcache off"
    exit 1
  fi
  echo "[cmd] rsu init"
  if rsu init; then
    echo "[OK] rsu init"
  else
    echo "[FAIL] command failed: rsu init"
    exit 1
  fi
  echo "[cmd] rsu slot_enable ${next_slot_id}"
  if rsu slot_enable ${next_slot_id}; then
    echo "[OK] rsu slot_enable ${next_slot_id}"
  else
    echo "[FAIL] command failed: rsu slot_enable ${next_slot_id}"
    exit 1
  fi
  echo "[cmd] dcache off"
  if dcache off; then
    echo "[OK] dcache off"
  else
    echo "[FAIL] command failed: dcache off"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
