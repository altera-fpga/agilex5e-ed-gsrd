# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
echo "[uboot-mmc] Start MMC/SD information test"

if test -z "${uboot_mmc_dev}"; then setenv uboot_mmc_dev 0; fi
if test -z "${uboot_mmc_part}"; then setenv uboot_mmc_part 1; fi

if mmc list; then
  echo "[uboot-mmc] mmc list OK"
else
  echo "[FAIL] mmc list failed"
  exit 1
fi

if mmc dev ${uboot_mmc_dev}; then
  echo "[uboot-mmc] selected mmc dev ${uboot_mmc_dev}"
else
  echo "[FAIL] mmc dev ${uboot_mmc_dev} failed"
  exit 1
fi

if mmc info; then
  echo "[uboot-mmc] mmc info OK"
else
  echo "[FAIL] mmc info failed"
  exit 1
fi

if part list mmc ${uboot_mmc_dev}; then
  echo "[uboot-mmc] partition list OK"
else
  echo "[FAIL] part list mmc ${uboot_mmc_dev} failed"
  exit 1
fi

if fatls mmc ${uboot_mmc_dev}:${uboot_mmc_part}; then
  echo "[uboot-mmc] FAT partition listing OK"
else
  echo "[uboot-mmc] FAT partition listing failed or non-FAT partition; information-only test continues"
fi

echo "[PASS] U-Boot MMC/SD information command sequence completed"
