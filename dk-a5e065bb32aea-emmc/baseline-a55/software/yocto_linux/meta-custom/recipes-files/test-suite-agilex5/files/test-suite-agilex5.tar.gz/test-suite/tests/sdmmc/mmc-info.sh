#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: sdmmc/linux/mmc_info/test_steps.sh
# Safety tags: sdmmc,emmc,storage,smoke
# Review './ts info sdmmc/mmc-info' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="mmc-info"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Display MMC information and optionally run the destructive Perl mmc_info partition/write flow."

usage() {
  cat <<'EOF_USAGE'
Usage:
  test_steps.sh [--yes] [block-device]

Environment:
  MMC_DEV=/dev/mmcblk0
  MMC_PARTITION=/dev/mmcblk0p1
  MMC_REGTEST_COMPAT=0          # 1 = run fdisk/mkfs/mount/touch flow from test_steps.pl
  TESTSUITE_ALLOW_DESTRUCTIVE=1

Default mode is read-only information. The Perl regtest flow repartitions and
formats /dev/mmcblk0p1, so it is only run when MMC_REGTEST_COMPAT=1 and the
flow is armed with --yes or TESTSUITE_ALLOW_DESTRUCTIVE=1.
EOF_USAGE
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

CONFIRMED=0
if [[ "${1:-}" == "--yes" ]]; then CONFIRMED=1; shift; fi

: "${MMC_DEV:=/dev/mmcblk0}"
: "${MMC_PARTITION:=${MMC_DEV}p1}"
: "${MMC_REGTEST_COMPAT:=0}"

DEV="${1:-$MMC_DEV}"
PART="$MMC_PARTITION"
BASENAME="$(basename "$DEV")"
SYS="/sys/block/$BASENAME/device"

ts_need lsblk
[[ -b "$DEV" ]] || ts_fail "block device not found: $DEV"

ts_log "Block layout"
lsblk -o NAME,MAJ:MIN,SIZE,TYPE,FSTYPE,MOUNTPOINTS "$DEV"

if [[ -d "$SYS" ]]; then
  for f in name type cid csd date fwrev hwrev manfid oemid serial; do
    [[ -r "$SYS/$f" ]] && printf '%-10s: %s\n' "$f" "$(cat "$SYS/$f")"
  done
else
  ts_log "No MMC sysfs detail node found at $SYS"
fi

if [[ "$MMC_REGTEST_COMPAT" != "1" ]]; then
  ts_pass "MMC/eMMC information check completed"
  exit 0
fi

ts_require_root
ts_require_destructive "$CONFIRMED"
ts_need fdisk
ts_need mkfs.fat
ts_need mount
ts_need umount

MNT="/mnt/mmc_p1"
cleanup() { mountpoint -q "$MNT" && umount "$MNT" || true; }
trap cleanup EXIT

ts_log "Running destructive Perl-compatible mmc_info flow on $DEV / $PART"
printf 'n\np\n1\n\n\np\nw\n' | fdisk "$DEV" || ts_fail "fdisk partition creation failed"
partprobe "$DEV" 2>/dev/null || true
sleep 2
[[ -b "$PART" ]] || ts_fail "partition not found after fdisk: $PART"
ts_run "mkfs.fat $PART" mkfs.fat "$PART"
mkdir -p "$MNT"
ts_run "mount $PART $MNT" mount "$PART" "$MNT"
(
  cd "$MNT"
  ts_run "touch abc.txt" touch abc.txt
  [[ -e abc.txt ]] || ts_fail "abc.txt not created on $PART"
  ls abc.txt
)
ts_pass "Perl-compatible MMC partition/write flow completed"
