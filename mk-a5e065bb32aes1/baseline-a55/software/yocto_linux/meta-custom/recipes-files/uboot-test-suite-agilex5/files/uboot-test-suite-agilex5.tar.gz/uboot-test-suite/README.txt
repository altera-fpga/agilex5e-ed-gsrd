emb-test-suite test-suite package

Platform   : agilex5
Build type : release
Built UTC  : 2026-09-14T06:47:38Z

Quick start - Linux:
  (Linux test-suite not included in this U-Boot-only package)

Deploy note:
  Always install from the release .zip (unzip on the board). Do not copy manifest.tsv
  through terminals or editors that wrap long lines — that corrupts the test list.

Quick start - U-Boot:
  # From U-Boot, load pre-built scripts directly:
  fatload mmc 0:1 ${scriptaddr} config/uboot.scr; source ${scriptaddr}
  fatload mmc 0:1 ${scriptaddr} uboot/suite/oobe-smoke.scr; source ${scriptaddr}
  # Single test example:
  fatload mmc 0:1 ${scriptaddr} uboot/ethernet/ping.scr; source ${scriptaddr}

Host helpers (from repo checkout):
  bash tools/testsuite/uboot_runner.sh list
  bash tools/testsuite/uboot_runner.sh oobe-smoke
  bash tools/testsuite/analyze_uboot_log.sh console.log

Notes:
  - Linux defaults are maintained in tools/testsuite/config/<platform>.conf.
  - U-Boot defaults are maintained in tools/testsuite/config/uboot_<platform>.env.
  - Perl/shell conversion workflow: tools/testsuite/CONVERSION_WORKFLOW.md
  - The package still includes uboot/mkimage_all.sh for developers who modify
    config/uboot.env or *.cmd after extraction and want to regenerate *.scr.
    Regeneration requires UBOOT_SIGN_KEYDIR (GSRD-compatible FIT keys) and mkimage+dtc.
  - Prebuilt *.scr files are signed FIT images (sha256,rsa2048:dev), matching GSRD
    U-Boot CONFIG_BOOTSCR_FIT_SIGNATURE. Legacy mkimage -T script images are rejected.

Package layout:
  config/uboot.env          Editable U-Boot default variables
  config/uboot.scr          Prebuilt U-Boot config script
  uboot/<category>/<test>.cmd   Source U-Boot command script
  uboot/<category>/<test>.scr   Prebuilt U-Boot script image
  uboot/suite/oobe-smoke.scr    Default OOBE smoke batch
  uboot_manifest.tsv        Packaged U-Boot script metadata
  metadata.env              Package metadata
