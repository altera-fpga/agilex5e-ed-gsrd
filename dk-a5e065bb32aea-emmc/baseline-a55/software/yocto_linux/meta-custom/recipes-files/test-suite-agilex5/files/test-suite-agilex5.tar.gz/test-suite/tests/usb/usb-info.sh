#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: usb/linux/usb3_info/test_steps.sh
# Safety tags: usb,smoke,requires-usb3
# Review './ts info usb/usb-info' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="usb-info"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Display USB topology and storage enumeration."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh

Environment:
  USB_REQUIRE_STORAGE=0
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${USB_REQUIRE_STORAGE:=0}"

ts_log "USB devices"
if command -v lsusb >/dev/null 2>&1; then
  lsusb
  lsusb -t || true
else
  find /sys/bus/usb/devices -maxdepth 2 -type d | sort
fi

ts_log "Block devices"
lsblk -o NAME,TRAN,SIZE,TYPE,FSTYPE,MOUNTPOINTS || true

if [[ "$USB_REQUIRE_STORAGE" == "1" ]] && ! lsblk -S | grep -qi usb; then
  ts_fail "USB storage device not detected"
fi

ts_pass "USB enumeration completed"
