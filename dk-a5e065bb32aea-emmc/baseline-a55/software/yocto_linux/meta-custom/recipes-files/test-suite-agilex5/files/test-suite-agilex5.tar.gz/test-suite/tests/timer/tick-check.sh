#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: timers/linux/tick_adjustment/test_steps.sh
# Safety tags: timer,clocksource,smoke
# Review './ts info timer/tick-check' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="tick-check"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Run adjtick when available, otherwise perform monotonic clocksource fallback."

usage() {
  cat <<'EOF_USAGE'
Usage:
  test_steps.sh

Environment:
  ADJTICK_BIN=adjtick
  BOARD_NFS_SERVER_HOSTNAME=<server>    # optional TFTP fallback matching Perl flow
  BOARD_RESOURCE=<resource path>        # optional TFTP path
  TICK_SAMPLE_SEC=3

The original Perl flow copies/tftps adjtick, chmods it, and expects
"fail:0 xfail:0". This shell script does the same when adjtick is present or
can be fetched; otherwise it runs the existing monotonic uptime fallback.
EOF_USAGE
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${ADJTICK_BIN:=adjtick}"
: "${TICK_SAMPLE_SEC:=3}"

WORKDIR="$(ts_mktemp_dir)"
cleanup() { rm -rf "$WORKDIR"; }
trap cleanup EXIT

ts_stage_assets "$WORKDIR"

resolve_adjtick() {
  local bin="$ADJTICK_BIN" remote=""
  if [[ -x "$bin" ]]; then printf '%s\n' "$bin"; return; fi
  if command -v "$bin" >/dev/null 2>&1; then command -v "$bin"; return; fi
  if [[ -x "$WORKDIR/$(basename "$bin")" ]]; then printf '%s\n' "$WORKDIR/$(basename "$bin")"; return; fi
  if [[ -n "${BOARD_NFS_SERVER_HOSTNAME:-}" ]] && command -v tftp >/dev/null 2>&1; then
    remote="${BOARD_RESOURCE:+/${BOARD_RESOURCE}/}$(basename "$bin")"
    ts_log "Attempting Perl-compatible TFTP fetch: $remote from $BOARD_NFS_SERVER_HOSTNAME"
    if (cd "$WORKDIR" && tftp -g -r "$remote" "$BOARD_NFS_SERVER_HOSTNAME"); then
      chmod +x "$WORKDIR/$(basename "$bin")"
      printf '%s\n' "$WORKDIR/$(basename "$bin")"
      return
    fi
  fi
  return 1
}

if adjtick_path="$(resolve_adjtick)"; then
  chmod +x "$adjtick_path"
  ts_log "Running adjtick: $adjtick_path"
  output="$($adjtick_path 2>&1)" || { printf '%s\n' "$output"; ts_fail "adjtick returned failure"; }
  printf '%s\n' "$output"
  ts_assert_grep 'fail:0[[:space:]]+xfail:0' "$output" "adjtick did not report fail:0 xfail:0"
  ts_pass "adjtick tick adjustment test completed"
  exit 0
fi

ts_log "adjtick not available; running monotonic uptime fallback"
ts_log "Clocksource"
cat /sys/devices/system/clocksource/clocksource0/current_clocksource 2>/dev/null || true
cat /sys/devices/system/clocksource/clocksource0/available_clocksource 2>/dev/null || true

START="$(cut -d' ' -f1 /proc/uptime)"
sleep "$TICK_SAMPLE_SEC"
END="$(cut -d' ' -f1 /proc/uptime)"

awk -v start="$START" -v end="$END" -v expected="$TICK_SAMPLE_SEC" '
BEGIN {
  delta = end - start;
  printf("[tick-check] uptime delta %.3f sec\n", delta);
  if (delta < expected - 0.5 || delta > expected + 0.5) exit 1;
}' || ts_fail "monotonic tick delta outside expected range"

ts_pass "tick/clocksource fallback check completed"
