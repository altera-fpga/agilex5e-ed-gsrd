# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from i3c/uboot/basic_i3c_rw/test_steps.pl
echo "[uboot-basic-i3c-rw] Start generated command sequence"
  echo "[cmd] i3c list"
  if i3c list; then
    echo "[OK] i3c list"
  else
    echo "[FAIL] command failed: i3c list"
    exit 1
  fi
  echo "[cmd] i3c current"
  if i3c current; then
    echo "[OK] i3c current"
  else
    echo "[FAIL] command failed: i3c current"
    exit 1
  fi
  echo "[cmd] i3c device_list"
  if i3c device_list; then
    echo "[OK] i3c device_list"
  else
    echo "[FAIL] command failed: i3c device_list"
    exit 1
  fi
  echo "[cmd] i3c read 2 0"
  if i3c read 2 0; then
    echo "[OK] i3c read 2 0"
  else
    echo "[FAIL] command failed: i3c read 2 0"
    exit 1
  fi
  echo "[cmd] i3c write 031E00 3 0"
  if i3c write 031E00 3 0; then
    echo "[OK] i3c write 031E00 3 0"
  else
    echo "[FAIL] command failed: i3c write 031E00 3 0"
    exit 1
  fi
  echo "[cmd] i3c write 03 1 0"
  if i3c write 03 1 0; then
    echo "[OK] i3c write 03 1 0"
  else
    echo "[FAIL] command failed: i3c write 03 1 0"
    exit 1
  fi
  echo "[cmd] i3c write 020F00 3 0"
  if i3c write 020F00 3 0; then
    echo "[OK] i3c write 020F00 3 0"
  else
    echo "[FAIL] command failed: i3c write 020F00 3 0"
    exit 1
  fi
  echo "[cmd] i3c write 02 1 0"
  if i3c write 02 1 0; then
    echo "[OK] i3c write 02 1 0"
  else
    echo "[FAIL] command failed: i3c write 02 1 0"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
