#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: oobe/linux/combined_oobe/test_steps.sh
# Safety tags: oobe,smoke
# Review './ts info oobe/combined-oobe' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="combined-oobe"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Run OOBE syschk and hello-world applications from the on-board rootfs."

usage() {
  cat <<'USAGE'
Usage:
  test_steps.sh

Environment:
  OOBE_APP_DIR=/home/root/alteraFPGA
  OOBE_SYSCHK_TIMEOUT_SEC=10

This is the on-board test-suite shell version of oobe/linux/combined_oobe/test_steps.pl.
It runs syschk with a bounded timeout, then runs hello and verifies the Hello world banner.
USAGE
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${OOBE_APP_DIR:=/home/root/alteraFPGA}"
: "${OOBE_SYSCHK_TIMEOUT_SEC:=10}"

SYSCHK_LOG=""
cleanup() {
  # EXIT traps must not change the test result.  The syschk temp log may
  # already have been removed by run_syschk_bounded(), and a bare [[ ... ]]
  # would return 1 and make a successfully completed test look failed.
  if [[ -n "${SYSCHK_LOG:-}" && -f "$SYSCHK_LOG" ]]; then
    rm -f "$SYSCHK_LOG" || true
  fi
  return 0
}
trap cleanup EXIT

stop_syschk_tree() {
  local pid="$1"
  local child

  [[ -n "$pid" ]] || return 0

  for child in $(pgrep -P "$pid" 2>/dev/null || true); do
    stop_syschk_tree "$child"
  done

  kill -TERM "$pid" 2>/dev/null || true
  sleep 1
  if kill -0 "$pid" 2>/dev/null; then
    kill -KILL "$pid" 2>/dev/null || true
  fi
  wait "$pid" 2>/dev/null || true
}

run_syschk_bounded() {
  local log_file=""
  local pid=""
  local waited=0
  local saw_fpga=0
  local saw_hps=0

  log_file="$(mktemp "${TMPDIR:-/tmp}/combined-oobe-syschk.XXXXXX")"
  SYSCHK_LOG="$log_file"

  ts_log "Running syschk (stop after LED output or ${OOBE_SYSCHK_TIMEOUT_SEC}s)"

  # syschk redraws the console continuously. Run it in a new session with I/O
  # redirected to a temp log (never kill the caller's process group — that
  # dropped the SSH shell with rc=130).
  set +e
  if command -v setsid >/dev/null 2>&1 && command -v script >/dev/null 2>&1; then
    setsid script -qefc "./syschk" "$log_file" </dev/null >/dev/null 2>&1 &
  elif command -v setsid >/dev/null 2>&1; then
    setsid ./syschk >>"$log_file" 2>&1 </dev/null &
  else
    ./syschk >>"$log_file" 2>&1 </dev/null &
  fi
  pid=$!
  set -e

  while [[ "$waited" -lt "$OOBE_SYSCHK_TIMEOUT_SEC" ]]; do
    if [[ "$saw_fpga" -eq 0 ]] && grep -q 'fpga_led' "$log_file" 2>/dev/null; then
      saw_fpga=1
    fi
    if [[ "$saw_hps" -eq 0 ]] && grep -q 'hps_led' "$log_file" 2>/dev/null; then
      saw_hps=1
    fi
    if [[ "$saw_fpga" -eq 1 && "$saw_hps" -eq 1 ]]; then
      break
    fi
    if ! kill -0 "$pid" 2>/dev/null; then
      break
    fi
    sleep 1
    waited=$((waited + 1))
  done

  set +e
  stop_syschk_tree "$pid"
  set -e

  if grep -Eq 'hps_led|fpga_led' "$log_file" 2>/dev/null; then
    ts_log "syschk LED status (sample):"
    grep -E 'hps_led|fpga_led' "$log_file" | head -5 || true
  else
    rm -f "$log_file"
    ts_fail "syschk output did not contain expected LED entries"
  fi

  rm -f "$log_file" || true
  SYSCHK_LOG=""
}

ts_need grep

[[ -d "$OOBE_APP_DIR" ]] || ts_fail "OOBE app directory not found: $OOBE_APP_DIR"
[[ -x "$OOBE_APP_DIR/syschk" ]] || ts_fail "syschk not executable under $OOBE_APP_DIR"
[[ -x "$OOBE_APP_DIR/hello" ]] || ts_fail "hello not executable under $OOBE_APP_DIR"

cd "$OOBE_APP_DIR"

run_syschk_bounded

ts_log "Running hello"
hello_output="$(./hello 2>&1)"
printf '%s\n' "$hello_output"
# OOBE rootfs variants print either banner (see hello_world vs combined_oobe regtests).
if ! printf '%s\n' "$hello_output" | grep -Eq 'Hello world|Hello SoC FPGA!'; then
  ts_fail "hello output did not contain expected greeting (Hello world or Hello SoC FPGA!)"
fi

ts_pass "combined OOBE test completed"
