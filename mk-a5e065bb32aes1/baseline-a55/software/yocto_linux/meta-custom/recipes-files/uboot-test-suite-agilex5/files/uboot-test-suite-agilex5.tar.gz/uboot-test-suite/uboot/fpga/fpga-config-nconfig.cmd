# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from fpga_config/uboot/fpga_config_nconfig/test_steps.pl
echo "[uboot-fpga-config-nconfig] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] fpga load 0 $loadaddr $filesize"
  if fpga load 0 $loadaddr $filesize; then
    echo "[OK] fpga load 0 $loadaddr $filesize"
  else
    echo "[FAIL] command failed: fpga load 0 $loadaddr $filesize"
    exit 1
  fi
  echo "[cmd] setenv autoload no"
  setenv autoload no
  echo "[cmd] dhcp"
  if dhcp; then
    echo "[OK] dhcp"
  else
    echo "[FAIL] command failed: dhcp"
    exit 1
  fi
  echo "[cmd] fpga load 0 $loadaddr $filesize"
  if fpga load 0 $loadaddr $filesize; then
    echo "[OK] fpga load 0 $loadaddr $filesize"
  else
    echo "[FAIL] command failed: fpga load 0 $loadaddr $filesize"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
