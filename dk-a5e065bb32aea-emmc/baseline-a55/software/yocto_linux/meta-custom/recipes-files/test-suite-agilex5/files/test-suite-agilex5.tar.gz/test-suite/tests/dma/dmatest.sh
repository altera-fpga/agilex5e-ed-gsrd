#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: dma/linux/dmatest/test_steps.sh
# Safety tags: dma,kernel,opt-in,requires-dma
# Review './ts info dma/dmatest' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="dmatest"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Run Linux kernel dmatest on discovered DMA channels."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh

Environment:
  DMATEST_ITERATIONS=10
  DMATEST_TIMEOUT=2000
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${DMATEST_ITERATIONS:=10}"
: "${DMATEST_TIMEOUT:=2000}"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then ts_fail "must run as root"; fi
modprobe dmatest 2>/dev/null || true
[[ -d /sys/module/dmatest/parameters ]] || ts_fail "dmatest sysfs parameters not found"

mapfile -t channels < <(ls -1 /sys/class/dma 2>/dev/null || true)
[[ "${#channels[@]}" -gt 0 ]] || ts_fail "no DMA channels found under /sys/class/dma"

printf '%s\n' "$DMATEST_TIMEOUT" > /sys/module/dmatest/parameters/timeout
printf '%s\n' "$DMATEST_ITERATIONS" > /sys/module/dmatest/parameters/iterations
printf '1\n' > /sys/module/dmatest/parameters/verbose 2>/dev/null || true
printf '0\n' > /sys/module/dmatest/parameters/run 2>/dev/null || true

for ch in "${channels[@]}"; do
  ts_log "Adding DMA channel $ch"
  printf '%s\n' "$ch" > /sys/module/dmatest/parameters/channel || true
done

ts_log "Starting dmatest"
printf '1\n' > /sys/module/dmatest/parameters/run
sleep 5

dm_out=""
dm_out="$(dmesg | grep -i dmatest | tail -80 || true)"
printf '%s\n' "$dm_out"
if printf '%s\n' "$dm_out" | grep -Eiq 'test failed|[1-9][0-9]* failures'; then
  ts_fail "dmatest reported failure in dmesg"
fi
if ! printf '%s\n' "$dm_out" | grep -qi 'dmatest'; then
  ts_fail "no dmatest output found in dmesg"
fi
ts_pass "dmatest completed; see dmesg above for channel results"
