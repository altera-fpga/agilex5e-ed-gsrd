#!/usr/bin/env bash
# Packaged by HPS test-suite builder.
# Original source: spi/linux/spi_rw/test_steps.sh
# Safety tags: spi,smoke,opt-in,requires-spi
# Review './ts info spi/spi-smoke' for setup, pass criteria, and recovery notes.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTSUITE_SCRIPT_DIR="$SCRIPT_DIR"
TESTSUITE_TEST_TAG="spi-test"
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "${TESTSUITE_ROOT}/lib/bootstrap.sh"
else
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/../../../tools/testsuite/lib/bootstrap.sh"
fi

DESCRIPTION="Run SPI EEPROM or SIMICS SPI-NOR flow equivalent to spi/linux/spi_rw/test_steps.pl."

usage() {
  cat <<'EOF_USAGE'
Usage:
  test_steps.sh [--yes] [--profile eeprom|simics-nor|discovery] [spidev]

Environment:
  SPI_PROFILE=eeprom|simics-nor|discovery
  SPI_DEV=/dev/spidev1.0
  SPI_ITERATIONS=100
  SPI_NOR_MTD=/dev/mtd0 (agilex72) or /dev/mtd2 (legacy)
  PLATFORM_FAMILY=agilex72
  TESTSUITE_ALLOW_DESTRUCTIVE=1

Profiles:
  eeprom      Agilex board Debug2 daughter-card Microchip 25AA128 flow.
  simics-nor  SIMICS SPI NOR MTD erase/write/readback flow from Perl.
  discovery   List SPI devices only.
EOF_USAGE
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

CONFIRMED=0
if [[ "${1:-}" == "--yes" ]]; then CONFIRMED=1; shift; fi
PROFILE="${SPI_PROFILE:-eeprom}"
if [[ "${1:-}" == "--profile" ]]; then PROFILE="${2:?profile required}"; shift 2; fi

: "${SPI_DEV:=/dev/spidev1.0}"
: "${SPI_ITERATIONS:=100}"
# Default SPI_NOR_MTD is selected in run_simics_nor (agilex72: mtd0, legacy: mtd2).
DEV="${1:-$SPI_DEV}"

hex_byte() { printf '%02X' "$((RANDOM % 256))"; }

run_discovery() {
  ts_log "SPI device nodes"
  ls -l /dev/spidev* 2>/dev/null || true
  ts_log "SPI sysfs devices"
  find /sys/bus/spi/devices -maxdepth 2 -type l -o -type d 2>/dev/null | sort || true
  ts_pass "SPI discovery completed"
}

run_simics_nor() {
  local out mtd_name erase_count
  ts_require_root
  ts_require_destructive "$CONFIRMED"
  ts_need flash_erase
  ts_need dd
  ts_need hexdump
  # agilex72: unpartitioned JEDEC flash appears as "spi0.0" on /dev/mtd0.
  # Legacy Simics: labeled partition spi_flash_part0 on /dev/mtd2.
  # Erase 1 block on mtd0 — full-chip erase of ~256MB exceeds typical timeouts.
  if [[ "${PLATFORM_FAMILY:-${FAMILY_NAME:-${family_name:-}}}" == "agilex72" ]]; then
    SPI_NOR_MTD="${SPI_NOR_MTD:-/dev/mtd0}"
    mtd_name="spi0.0"
    erase_count=1
  else
    SPI_NOR_MTD="${SPI_NOR_MTD:-/dev/mtd2}"
    mtd_name="spi_flash_part0"
    erase_count=0
  fi
  ts_log "Running SIMICS SPI NOR MTD flow from test_steps.pl (${SPI_NOR_MTD}, expect ${mtd_name})"
  cat /proc/mtd
  grep -q "$mtd_name" /proc/mtd || ts_fail "${mtd_name} not found in /proc/mtd"
  [[ -e "$SPI_NOR_MTD" ]] || ts_fail "SPI NOR MTD device not found: $SPI_NOR_MTD"
  ts_run "erase $SPI_NOR_MTD" flash_erase "$SPI_NOR_MTD" 0 "$erase_count"
  out="$(dd if="$SPI_NOR_MTD" bs=512 count=1 2>/dev/null | hexdump -C)"
  printf '%s\n' "$out"
  ts_assert_grep 'ff ff ff ff ff ff ff ff  ff ff ff ff ff ff ff ff' "$out" "SPI NOR was not erased to 0xff"
  echo "FACECAFEBADCAFE" > temp.txt
  grep -q FACECAFEBADCAFE temp.txt || ts_fail "temp.txt was not created correctly"
  ts_run "write temp.txt to $SPI_NOR_MTD" dd if=temp.txt of="$SPI_NOR_MTD" bs=512 count=1
  out="$(dd if="$SPI_NOR_MTD" bs=512 count=1 2>/dev/null | hexdump -C)"
  printf '%s\n' "$out"
  ts_assert_grep '46 41 43 45 43 41 46 45|FACECAFE' "$out" "SPI NOR readback does not contain FACECAFEBADCAFE"
  rm -f temp.txt
  ts_pass "SIMICS SPI NOR flow completed"
}

run_eeprom() {
  local i off_msb off_lsb value out payload
  ts_need spidev_test
  [[ -e "$DEV" ]] || ts_fail "SPI device not found: $DEV"
  ts_log "Running Microchip 25AA128 EEPROM byte write/readback for $SPI_ITERATIONS iteration(s) on $DEV"
  for ((i = 1; i <= SPI_ITERATIONS; i++)); do
    off_msb="$(hex_byte)"
    off_lsb="$(hex_byte)"
    value="$(hex_byte)"
    ts_log "Iteration $i offset=0x${off_msb}${off_lsb} value=0x$value"
    ts_run "WREN" spidev_test -D "$DEV" -v -p "\\x06"
    # Use printf to create the exact byte sequence required by the Perl payload.
    payload="$(printf '\\x02\\x%s\\x%s\\x%s' "$off_msb" "$off_lsb" "$value")"
    ts_run "byte write" spidev_test -D "$DEV" -v -p "$payload"
    payload="$(printf '\\x03\\x%s\\x%s\\x00' "$off_msb" "$off_lsb")"
    out="$(spidev_test -D "$DEV" -v -p "$payload" 2>&1)"
    printf '%s\n' "$out"
    ts_assert_grep "FF FF FF.*${value}|${value}" "$out" "SPI EEPROM readback did not include written value 0x$value"
  done
  ts_pass "SPI EEPROM write/readback flow completed"
}

case "$PROFILE" in
  eeprom) run_eeprom ;;
  simics-nor|simics) run_simics_nor ;;
  discovery|smoke) run_discovery ;;
  *) ts_fail "unknown SPI_PROFILE: $PROFILE" ;;
esac
