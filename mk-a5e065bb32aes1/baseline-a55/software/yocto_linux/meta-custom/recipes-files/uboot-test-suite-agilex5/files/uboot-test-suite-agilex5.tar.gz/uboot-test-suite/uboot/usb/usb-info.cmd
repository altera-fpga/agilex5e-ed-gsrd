# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
echo "[uboot-usb-info] Start USB information test"

if usb reset; then
  echo "[uboot-usb-info] usb reset OK"
else
  echo "[FAIL] usb reset failed"
  exit 1
fi

if usb tree; then
  echo "[uboot-usb-info] usb tree OK"
else
  echo "[FAIL] usb tree failed"
  exit 1
fi

if usb info; then
  echo "[uboot-usb-info] usb info OK"
else
  echo "[FAIL] usb info failed"
  exit 1
fi

if test -n "${uboot_usb_dev}"; then
  if part list usb ${uboot_usb_dev}; then
    echo "[uboot-usb-info] USB partition list OK for device ${uboot_usb_dev}"
  else
    echo "[uboot-usb-info] No partition table for USB device ${uboot_usb_dev}; information-only test continues"
  fi
fi

echo "[PASS] U-Boot USB information command sequence completed"
