# Release Notes

Package: emb-test-suite  
Version: 2026.09.14  
Platform: agilex5  
Build type: release  
Built UTC: 2026-09-14T06:47:38Z  
Source commit: 57e34d80078b  
Linux manifest SHA256: none  
Linux config SHA256: none  
U-Boot manifest SHA256: 5226e6e4c0804a014e1cc72de4e65343374f07a617e78be56b921427eb12bfe3  
U-Boot config SHA256: 8b5682c96b191fcb5b1b5e7207df3901c1b8228f37b33e06a96d981fe16dda66

## Release scope

This release contains customer-facing Linux and/or U-Boot test-suite assets for devkit bring-up and guided validation. It excludes internal Simics/farm/Xen orchestration.

## Safety

Manual, multiboard, and destructive tests are not run by default. Linux destructive tests require TESTSUITE_ALLOW_DESTRUCTIVE=1 and --yes. U-Boot destructive tests require setenv uboot_allow_destructive 1.
