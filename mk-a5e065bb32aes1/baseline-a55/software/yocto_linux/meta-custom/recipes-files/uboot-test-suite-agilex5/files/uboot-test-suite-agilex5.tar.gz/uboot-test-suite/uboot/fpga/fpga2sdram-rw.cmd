# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from fpga_bridge/uboot/fpga2sdram_rw/test_steps.pl
echo "[uboot-fpga2sdram-rw] Start generated command sequence"
  echo "[cmd] bridge enable"
  if bridge enable; then
    echo "[OK] bridge enable"
  else
    echo "[FAIL] command failed: bridge enable"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] md ${write_addr} 4"
  if md ${write_addr} 4; then
    echo "[OK] md ${write_addr} 4"
  else
    echo "[FAIL] command failed: md ${write_addr} 4"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
