# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_sw/uboot/cold_reset/test_steps.pl
echo "[uboot-cold-reset] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] fatwrite mmc 0:1 $loadaddr $uboot_itb $filesize"
  if fatwrite mmc 0:1 $loadaddr $uboot_itb $filesize; then
    echo "[OK] fatwrite mmc 0:1 $loadaddr $uboot_itb $filesize"
  else
    echo "[FAIL] command failed: fatwrite mmc 0:1 $loadaddr $uboot_itb $filesize"
    exit 1
  fi
  echo "[cmd] fatls mmc 0:1"
  if fatls mmc 0:1; then
    echo "[OK] fatls mmc 0:1"
  else
    echo "[FAIL] command failed: fatls mmc 0:1"
    exit 1
  fi
  echo "[cmd] fatload mmc 0:1 $loadaddr $uboot_itb"
  if fatload mmc 0:1 $loadaddr $uboot_itb; then
    echo "[OK] fatload mmc 0:1 $loadaddr $uboot_itb"
  else
    echo "[FAIL] command failed: fatload mmc 0:1 $loadaddr $uboot_itb"
    exit 1
  fi
  echo "[cmd] iminfo"
  if iminfo; then
    echo "[OK] iminfo"
  else
    echo "[FAIL] command failed: iminfo"
    exit 1
  fi
  echo "[cmd] reset"
  echo "[INFO] reset command should reboot the board; script fails if it returns"
  reset
  echo "[FAIL] reset command returned unexpectedly"
  exit 1
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
