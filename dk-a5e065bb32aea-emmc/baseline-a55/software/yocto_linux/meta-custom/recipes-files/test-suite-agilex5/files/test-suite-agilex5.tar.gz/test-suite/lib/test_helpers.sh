#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Shared helpers for Linux test-suite test_steps.sh scripts.
#
# Source from a test script:
#   SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
#   TEST_TAG="my-test"
#   # shellcheck disable=SC1091
#   source "$(ts_resolve_helpers "$SCRIPT_DIR")"
#
# At runtime the packaged test-suite exports TESTSUITE_ROOT; during repo
# development helpers are resolved from tools/testsuite/lib/.

ts_resolve_helpers() {
  local script_dir="${1:?script_dir required}"

  if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/test_helpers.sh" ]]; then
    printf '%s\n' "${TESTSUITE_ROOT}/lib/test_helpers.sh"
    return 0
  fi

  local repo_root
  repo_root="$(cd "${script_dir}/../../.." && pwd)"
  if [[ -f "${repo_root}/tools/testsuite/lib/test_helpers.sh" ]]; then
    printf '%s\n' "${repo_root}/tools/testsuite/lib/test_helpers.sh"
    return 0
  fi

  echo "test_helpers.sh not found (TESTSUITE_ROOT=${TESTSUITE_ROOT:-unset})" >&2
  return 1
}

ts_log() {
  echo "[${TEST_TAG:-testsuite}] $*"
}

ts_fail() {
  ts_log "FAIL: $*" >&2
  if [[ -n "${TESTSUITE_HINT:-}" ]]; then
    ts_log "HINT: ${TESTSUITE_HINT}" >&2
  fi
  exit 1
}

ts_pass() {
  ts_log "PASS: $*"
  if [[ -n "${TESTSUITE_PASS_EVIDENCE:-}" ]]; then
    ts_log "PASS-EVIDENCE: ${TESTSUITE_PASS_EVIDENCE}"
  fi
}

ts_pass_evidence() {
  TESTSUITE_PASS_EVIDENCE="$*"
  ts_log "PASS-EVIDENCE: $*"
}

ts_fail_hint() {
  TESTSUITE_HINT="$*"
  ts_log "HINT: $*"
}

ts_require_var() {
  local name="${1:?variable name required}"
  local value="${!name:-}"
  [[ -n "${value// }" ]] || ts_fail "required config variable is empty: ${name}"
}

ts_require_device() {
  local dev="${1:?device path required}"
  [[ -e "$dev" ]] || ts_fail "required device/path not found: $dev"
}

TESTSUITE_CLEANUP_CMDS=()

ts_register_cleanup() {
  TESTSUITE_CLEANUP_CMDS+=("$*")
}

ts_run_cleanups() {
  local cmd
  for cmd in "${TESTSUITE_CLEANUP_CMDS[@]:-}"; do
    [[ -n "$cmd" ]] || continue
    ts_log "CLEANUP: $cmd"
    # shellcheck disable=SC2086
    eval "$cmd" || true
  done
}

ts_enable_cleanup_trap() {
  trap ts_run_cleanups EXIT INT TERM
}

ts_need() {
  command -v "$1" >/dev/null 2>&1 || ts_fail "Required command not found: $1"
}

ts_require_root() {
  if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
    ts_fail "this test requires root privileges"
  fi
}

ts_require_destructive() {
  local confirmed="${1:-0}"
  if [[ "$confirmed" -ne 1 || "${TESTSUITE_ALLOW_DESTRUCTIVE:-0}" != "1" ]]; then
    ts_fail "destructive flow not armed. Re-run with both TESTSUITE_ALLOW_DESTRUCTIVE=1 and --yes"
  fi
  ts_log "DESTRUCTIVE-CONFIRMED: operator supplied TESTSUITE_ALLOW_DESTRUCTIVE=1 and --yes"
}

ts_run() {
  local label="$1"
  shift
  ts_log "STEP: $label"
  "$@" || ts_fail "step failed: $label"
}

ts_capture() {
  local __var="$1"
  shift
  local __out __rc
  set +e
  __out="$("$@" 2>&1)"
  __rc=$?
  set -e
  printf -v "$__var" '%s' "$__out"
  return "$__rc"
}

ts_assert_rc() {
  local rc="$1"
  local allowed="$2"
  local msg="$3"
  local token

  IFS=',' read -ra _ts_ok_rc <<< "$allowed"
  for token in "${_ts_ok_rc[@]}"; do
    [[ "$rc" -eq "$token" ]] && return 0
  done
  ts_fail "$msg (rc=$rc)"
}

ts_assert_grep() {
  local pattern="$1"
  local text="$2"
  local msg="$3"
  printf '%s\n' "$text" | grep -Eq "$pattern" || ts_fail "$msg"
}

ts_assert_not_grep() {
  local pattern="$1"
  local text="$2"
  local msg="$3"
  if printf '%s\n' "$text" | grep -Eq "$pattern"; then
    ts_fail "$msg"
  fi
}

ts_assert_cmp() {
  cmp -s "$1" "$2" || ts_fail "file mismatch: $1 vs $2"
}

ts_assert_nonempty() {
  local value="$1"
  local msg="$2"
  [[ -n "${value// }" ]] || ts_fail "$msg"
}

ts_mktemp_dir() {
  mktemp -d "${TMPDIR:-/tmp}/testsuite-${TEST_TAG:-run}.XXXXXX"
}

ts_stage_assets() {
  local dest_dir="$1"
  shift
  local required=("$@")
  local asset asset_name src

  [[ -n "${TESTSUITE_ASSETS_DIR:-}" && -d "$TESTSUITE_ASSETS_DIR" ]] || {
    if ((${#required[@]} > 0)); then
      ts_fail "TESTSUITE_ASSETS_DIR is unset but required assets were requested: ${required[*]}"
    fi
    return 0
  }

  while IFS= read -r asset; do
    [[ -n "$asset" ]] || continue
    asset_name="$(basename "$asset")"
    cp "$asset" "${dest_dir}/${asset_name}" || ts_fail "failed to copy asset: $asset"
    if [[ -x "$asset" ]]; then
      chmod +x "${dest_dir}/${asset_name}"
    fi
  done < <(find "$TESTSUITE_ASSETS_DIR" -maxdepth 3 -type f 2>/dev/null | sort)

  for src in "${required[@]}"; do
    [[ -e "${dest_dir}/${src}" ]] || ts_fail "required asset not staged: $src"
  done
}

ts_fcs_reject_errors() {
  local output="$1"
  local context="$2"
  ts_assert_not_grep 'Mailbox error|Failed' "$output" "$context reported FCS failure"
}

ts_fcs_parse_session_id() {
  local output="$1"
  local sid=""

  sid="$(printf '%s\n' "$output" | awk '/Session ID/ { print $NF; exit }')"
  if [[ -z "$sid" ]]; then
    sid="$(printf '%s\n' "$output" | awk '/session id|Session id/ { print $NF; exit }')"
  fi
  if [[ -z "$sid" ]]; then
    sid="$(printf '%s\n' "$output" | awk -F= '/session/ { print $2; exit }' | tr -d '[:space:]')"
  fi
  ts_assert_nonempty "$sid" "unable to parse FCS session id from output"
  printf '%s\n' "$sid"
}

ts_fcs_open_session() {
  local workdir="$1"
  local output="" rc sid
  local saved_pwd="$PWD"

  cd "$workdir" || ts_fail "cannot cd to $workdir"
  ts_capture output ./fcs_client -e
  rc=$?
  cd "$saved_pwd" || true
  echo "[${TEST_TAG:-testsuite}] fcs_client open session output:" >&2
  printf '%s\n' "$output" >&2
  ts_assert_rc "$rc" "0" "fcs_client open session failed"
  ts_fcs_reject_errors "$output" "fcs_client open session"
  sid="$(ts_fcs_parse_session_id "$output")"
  printf '%s\n' "$sid"
}

ts_fcs_close_session() {
  local workdir="$1"
  local sid="$2"
  local output="" rc
  local saved_pwd="$PWD"

  cd "$workdir" || ts_fail "cannot cd to $workdir"
  ts_capture output ./fcs_client -l -s "$sid"
  rc=$?
  cd "$saved_pwd" || true
  echo "[${TEST_TAG:-testsuite}] fcs_client close session output:" >&2
  printf '%s\n' "$output" >&2
  ts_assert_rc "$rc" "0" "fcs_client close session failed"
  ts_fcs_reject_errors "$output" "fcs_client close session"
}

# Backward-compatible aliases for legacy test_steps.sh scripts.
log()  { ts_log "$@"; }
fail() { ts_fail "$@"; }
need() { ts_need "$@"; }
pass() { ts_pass "$@"; }

ts_source_bootstrap() {
  local script_dir="$1"
  local test_tag="$2"
  TESTSUITE_SCRIPT_DIR="$script_dir"
  TESTSUITE_TEST_TAG="$test_tag"
  local bootstrap=""
  if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/bootstrap.sh" ]]; then
    bootstrap="${TESTSUITE_ROOT}/lib/bootstrap.sh"
  elif [[ -f "${script_dir}/../../../tools/testsuite/lib/bootstrap.sh" ]]; then
    bootstrap="$(cd "${script_dir}/../../../tools/testsuite/lib" && pwd)/bootstrap.sh"
  else
    ts_fail "bootstrap.sh not found"
  fi
  # shellcheck source=/dev/null
  source "$bootstrap"
}
