# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
echo "[uboot-bridge] Start FPGA bridge enable/read test"

if test -z "${uboot_bridge_verify_addr}"; then setenv uboot_bridge_verify_addr 0xf9000000; fi

if bridge enable; then
  echo "[uboot-bridge] bridge enable OK"
else
  echo "[FAIL] bridge enable failed"
  exit 1
fi

if md.l ${uboot_bridge_verify_addr} 1; then
  echo "[PASS] U-Boot bridge read completed at ${uboot_bridge_verify_addr}"
else
  echo "[FAIL] bridge verification read failed at ${uboot_bridge_verify_addr}"
  exit 1
fi
