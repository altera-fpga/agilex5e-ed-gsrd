#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Source after setting TESTSUITE_SCRIPT_DIR and TESTSUITE_TEST_TAG.

[[ -n "${TESTSUITE_SCRIPT_DIR:-}" ]] || {
  echo "TESTSUITE_SCRIPT_DIR must be set before sourcing bootstrap.sh" >&2
  exit 1
}

: "${TESTSUITE_TEST_TAG:=testsuite}"

_helper=""
if [[ -n "${TESTSUITE_ROOT:-}" && -f "${TESTSUITE_ROOT}/lib/test_helpers.sh" ]]; then
  _helper="${TESTSUITE_ROOT}/lib/test_helpers.sh"
elif [[ -f "${TESTSUITE_SCRIPT_DIR}/../../../tools/testsuite/lib/test_helpers.sh" ]]; then
  _helper="$(cd "${TESTSUITE_SCRIPT_DIR}/../../../tools/testsuite/lib" && pwd)/test_helpers.sh"
else
  echo "[${TESTSUITE_TEST_TAG}] FAIL: test_helpers.sh not found" >&2
  exit 1
fi

# shellcheck source=/dev/null
source "$_helper"
TEST_TAG="${TESTSUITE_TEST_TAG}"
