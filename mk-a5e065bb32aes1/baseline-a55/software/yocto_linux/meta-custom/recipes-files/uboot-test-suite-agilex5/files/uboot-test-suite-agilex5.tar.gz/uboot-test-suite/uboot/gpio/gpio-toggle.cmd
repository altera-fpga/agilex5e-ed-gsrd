# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
echo "[uboot-gpio] Start GPIO toggle test"

if test -z "${uboot_gpio_pin1}"; then setenv uboot_gpio_pin1 portb13; fi
if test -z "${uboot_gpio_pin2}"; then setenv uboot_gpio_pin2 portb23; fi

if gpio status -a; then
  echo "[uboot-gpio] GPIO status listed"
else
  echo "[FAIL] gpio status -a failed"
  exit 1
fi

echo "[uboot-gpio] Testing ${uboot_gpio_pin1}"
if gpio input ${uboot_gpio_pin1}; then
  echo "[OK] gpio input ${uboot_gpio_pin1} value=0"
else
  echo "[OK] gpio input ${uboot_gpio_pin1} value=1"
fi
if gpio set ${uboot_gpio_pin1}; then echo "[OK] gpio set ${uboot_gpio_pin1}"; else echo "[FAIL] gpio set ${uboot_gpio_pin1}"; exit 1; fi
if gpio clear ${uboot_gpio_pin1}; then echo "[OK] gpio clear ${uboot_gpio_pin1}"; else echo "[FAIL] gpio clear ${uboot_gpio_pin1}"; exit 1; fi
if gpio toggle ${uboot_gpio_pin1}; then echo "[OK] gpio toggle ${uboot_gpio_pin1}"; else echo "[FAIL] gpio toggle ${uboot_gpio_pin1}"; exit 1; fi

echo "[uboot-gpio] Testing ${uboot_gpio_pin2}"
if gpio input ${uboot_gpio_pin2}; then
  echo "[OK] gpio input ${uboot_gpio_pin2} value=0"
else
  echo "[OK] gpio input ${uboot_gpio_pin2} value=1"
fi
if gpio set ${uboot_gpio_pin2}; then echo "[OK] gpio set ${uboot_gpio_pin2}"; else echo "[FAIL] gpio set ${uboot_gpio_pin2}"; exit 1; fi
if gpio clear ${uboot_gpio_pin2}; then echo "[OK] gpio clear ${uboot_gpio_pin2}"; else echo "[FAIL] gpio clear ${uboot_gpio_pin2}"; exit 1; fi
if gpio toggle ${uboot_gpio_pin2}; then echo "[OK] gpio toggle ${uboot_gpio_pin2}"; else echo "[FAIL] gpio toggle ${uboot_gpio_pin2}"; exit 1; fi

echo "[PASS] U-Boot GPIO command sequence completed"
