# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/rsu_combined_application_image_update/test_steps.pl
echo "[uboot-rsu-combined-application-image-update] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] setenv autoload no"
  setenv autoload no
  echo "[cmd] printenv"
  if printenv; then
    echo "[OK] printenv"
  else
    echo "[FAIL] command failed: printenv"
    exit 1
  fi
  echo "[cmd] setenv ethaddr 00:df:00:33:56:00"
  setenv ethaddr 00:df:00:33:56:00
  echo "[cmd] dhcp"
  if dhcp; then
    echo "[OK] dhcp"
  else
    echo "[FAIL] command failed: dhcp"
    exit 1
  fi
  echo "[cmd] rsu display_dcmf_version"
  if rsu display_dcmf_version; then
    echo "[OK] rsu display_dcmf_version"
  else
    echo "[FAIL] command failed: rsu display_dcmf_version"
    exit 1
  fi
  echo "[cmd] rsu slot_erase 2"
  if rsu slot_erase 2; then
    echo "[OK] rsu slot_erase 2"
  else
    echo "[FAIL] command failed: rsu slot_erase 2"
    exit 1
  fi
  echo "[cmd] rsu slot_program_buf 2 $loadaddr $filesize"
  if rsu slot_program_buf 2 $loadaddr $filesize; then
    echo "[OK] rsu slot_program_buf 2 $loadaddr $filesize"
  else
    echo "[FAIL] command failed: rsu slot_program_buf 2 $loadaddr $filesize"
    exit 1
  fi
  echo "[cmd] rsu slot_verify_buf 2 $loadaddr $filesize"
  if rsu slot_verify_buf 2 $loadaddr $filesize; then
    echo "[OK] rsu slot_verify_buf 2 $loadaddr $filesize"
  else
    echo "[FAIL] command failed: rsu slot_verify_buf 2 $loadaddr $filesize"
    exit 1
  fi
  echo "[cmd] rsu slot_get_info 2"
  if rsu slot_get_info 2; then
    echo "[OK] rsu slot_get_info 2"
  else
    echo "[FAIL] command failed: rsu slot_get_info 2"
    exit 1
  fi
  echo "[cmd] rsu slot_load 2"
  echo "[INFO] RSU command may reboot the board; script fails if it returns"
  rsu slot_load 2
  echo "[FAIL] RSU command returned unexpectedly"
  exit 1
  echo "[cmd] dcache off"
  if dcache off; then
    echo "[OK] dcache off"
  else
    echo "[FAIL] command failed: dcache off"
    exit 1
  fi
  echo "[cmd] rsu display_dcmf_version"
  if rsu display_dcmf_version; then
    echo "[OK] rsu display_dcmf_version"
  else
    echo "[FAIL] command failed: rsu display_dcmf_version"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
