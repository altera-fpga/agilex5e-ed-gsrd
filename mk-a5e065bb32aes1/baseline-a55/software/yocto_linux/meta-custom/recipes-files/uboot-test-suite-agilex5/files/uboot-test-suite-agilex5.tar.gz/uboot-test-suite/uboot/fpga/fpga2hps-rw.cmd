# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from fpga_bridge/uboot/fpga2hps_rw/test_steps.pl
echo "[uboot-fpga2hps-rw] Start generated command sequence"
  echo "[cmd] bridge enable"
  if bridge enable; then
    echo "[OK] bridge enable"
  else
    echo "[FAIL] command failed: bridge enable"
    exit 1
  fi
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] md 0x0082000020 4"
  if md 0x0082000020 4; then
    echo "[OK] md 0x0082000020 4"
  else
    echo "[FAIL] command failed: md 0x0082000020 4"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
