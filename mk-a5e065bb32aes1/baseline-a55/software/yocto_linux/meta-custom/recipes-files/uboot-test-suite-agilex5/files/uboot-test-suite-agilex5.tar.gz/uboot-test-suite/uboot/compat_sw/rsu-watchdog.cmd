# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_sw/uboot/rsu_watchdog/test_steps.pl
echo "[uboot-rsu-watchdog] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] dcache flush"
  if dcache flush; then
    echo "[OK] dcache flush"
  else
    echo "[FAIL] command failed: dcache flush"
    exit 1
  fi
  echo "[cmd] iminfo"
  if iminfo; then
    echo "[OK] iminfo"
  else
    echo "[FAIL] command failed: iminfo"
    exit 1
  fi
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[cmd] wdt list"
  if wdt list; then
    echo "[OK] wdt list"
  else
    echo "[FAIL] command failed: wdt list"
    exit 1
  fi
  echo "[cmd] wdt dev watchdog\@10d00200"
  if wdt dev watchdog\@10d00200; then
    echo "[OK] wdt dev watchdog\@10d00200"
  else
    echo "[FAIL] command failed: wdt dev watchdog\@10d00200"
    exit 1
  fi
  echo "[cmd] wdt dev"
  if wdt dev; then
    echo "[OK] wdt dev"
  else
    echo "[FAIL] command failed: wdt dev"
    exit 1
  fi
  echo "[cmd] wdt start 200"
  if wdt start 200; then
    echo "[OK] wdt start 200"
  else
    echo "[FAIL] command failed: wdt start 200"
    exit 1
  fi
  echo "[cmd] mw.l 0xffd00204 0x11"
  if mw.l 0xffd00204 0x11; then
    echo "[OK] mw.l 0xffd00204 0x11"
  else
    echo "[FAIL] command failed: mw.l 0xffd00204 0x11"
    exit 1
  fi
  echo "[cmd] mw ffd00200 1"
  if mw ffd00200 1; then
    echo "[OK] mw ffd00200 1"
  else
    echo "[FAIL] command failed: mw ffd00200 1"
    exit 1
  fi
  echo "[cmd] rsu list"
  if rsu list; then
    echo "[OK] rsu list"
  else
    echo "[FAIL] command failed: rsu list"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
