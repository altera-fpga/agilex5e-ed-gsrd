# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from fpga_bridge/uboot/hps2fpga_rw/test_steps.pl
echo "[uboot-hps2fpga-rw] Start generated command sequence"
  echo "[cmd] bridge enable"
  if bridge enable; then
    echo "[OK] bridge enable"
  else
    echo "[FAIL] command failed: bridge enable"
    exit 1
  fi
  echo "[cmd] mw ${rand_mem_addr} 0xfacecafe"
  if mw ${rand_mem_addr} 0xfacecafe; then
    echo "[OK] mw ${rand_mem_addr} 0xfacecafe"
  else
    echo "[FAIL] command failed: mw ${rand_mem_addr} 0xfacecafe"
    exit 1
  fi
  echo "[cmd] md ${rand_mem_addr} 1"
  if md ${rand_mem_addr} 1; then
    echo "[OK] md ${rand_mem_addr} 1"
  else
    echo "[FAIL] command failed: md ${rand_mem_addr} 1"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
