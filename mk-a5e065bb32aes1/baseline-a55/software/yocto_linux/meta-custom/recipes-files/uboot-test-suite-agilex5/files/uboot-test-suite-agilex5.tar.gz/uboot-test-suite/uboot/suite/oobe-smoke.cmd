# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Default U-Boot OOBE smoke batch: ping, gpio, mmc-info, mtest, i2c-probe.
#
# Recommended usage:
#   1. Load config/uboot.scr first, or set the variables below manually.
#   2. For TFTP packages stored below a server subdirectory, set:
#        setenv uboot_ts_load tftp
#        setenv uboot_ts_root <server/path>/uboot-test-suite
#
# Environment overrides:
#   uboot_ts_load   Script loader: fatload or tftp (default: fatload)
#   uboot_ts_root   Package prefix on storage/server (default: uboot-test-suite)
#   uboot_ts_dev    MMC device for fatload (default: 0)
#   uboot_ts_part   MMC partition for fatload (default: 1)

echo "=== U-Boot OOBE smoke batch ==="

if test -z "${uboot_ts_load}"; then setenv uboot_ts_load fatload; fi
if test -z "${uboot_ts_root}"; then setenv uboot_ts_root uboot-test-suite; fi
if test -z "${uboot_ts_dev}"; then setenv uboot_ts_dev 0; fi
if test -z "${uboot_ts_part}"; then setenv uboot_ts_part 1; fi

echo "[uboot-oobe] loader=${uboot_ts_load} root=${uboot_ts_root}"

setenv uboot_ts_pass 0
setenv uboot_ts_fail 0

# --- ethernet/ping ---
echo "==> RUN ethernet/ping"
setenv uboot_ts_subtest ethernet/ping
setenv uboot_ts_script ${uboot_ts_root}/uboot/ethernet/ping.scr
if test "${uboot_ts_load}" = "tftp"; then
  if tftp ${scriptaddr} ${uboot_ts_script}; then
    if source ${scriptaddr}; then setexpr uboot_ts_pass ${uboot_ts_pass} + 1; else echo "subtest failed: ${uboot_ts_subtest}"; setexpr uboot_ts_fail ${uboot_ts_fail} + 1; fi
  else
    echo "subtest load failed: ${uboot_ts_subtest} (${uboot_ts_script})"
    setexpr uboot_ts_fail ${uboot_ts_fail} + 1
  fi
else
  if fatload mmc ${uboot_ts_dev}:${uboot_ts_part} ${scriptaddr} ${uboot_ts_script}; then
    if source ${scriptaddr}; then setexpr uboot_ts_pass ${uboot_ts_pass} + 1; else echo "subtest failed: ${uboot_ts_subtest}"; setexpr uboot_ts_fail ${uboot_ts_fail} + 1; fi
  else
    echo "subtest load failed: ${uboot_ts_subtest} (${uboot_ts_script})"
    setexpr uboot_ts_fail ${uboot_ts_fail} + 1
  fi
fi

# --- gpio/gpio-toggle ---
echo "==> RUN gpio/gpio-toggle"
setenv uboot_ts_subtest gpio/gpio-toggle
setenv uboot_ts_script ${uboot_ts_root}/uboot/gpio/gpio-toggle.scr
if test "${uboot_ts_load}" = "tftp"; then
  if tftp ${scriptaddr} ${uboot_ts_script}; then
    if source ${scriptaddr}; then setexpr uboot_ts_pass ${uboot_ts_pass} + 1; else echo "subtest failed: ${uboot_ts_subtest}"; setexpr uboot_ts_fail ${uboot_ts_fail} + 1; fi
  else
    echo "subtest load failed: ${uboot_ts_subtest} (${uboot_ts_script})"
    setexpr uboot_ts_fail ${uboot_ts_fail} + 1
  fi
else
  if fatload mmc ${uboot_ts_dev}:${uboot_ts_part} ${scriptaddr} ${uboot_ts_script}; then
    if source ${scriptaddr}; then setexpr uboot_ts_pass ${uboot_ts_pass} + 1; else echo "subtest failed: ${uboot_ts_subtest}"; setexpr uboot_ts_fail ${uboot_ts_fail} + 1; fi
  else
    echo "subtest load failed: ${uboot_ts_subtest} (${uboot_ts_script})"
    setexpr uboot_ts_fail ${uboot_ts_fail} + 1
  fi
fi

# --- sdmmc/mmc-info ---
echo "==> RUN sdmmc/mmc-info"
setenv uboot_ts_subtest sdmmc/mmc-info
setenv uboot_ts_script ${uboot_ts_root}/uboot/sdmmc/mmc-info.scr
if test "${uboot_ts_load}" = "tftp"; then
  if tftp ${scriptaddr} ${uboot_ts_script}; then
    if source ${scriptaddr}; then setexpr uboot_ts_pass ${uboot_ts_pass} + 1; else echo "subtest failed: ${uboot_ts_subtest}"; setexpr uboot_ts_fail ${uboot_ts_fail} + 1; fi
  else
    echo "subtest load failed: ${uboot_ts_subtest} (${uboot_ts_script})"
    setexpr uboot_ts_fail ${uboot_ts_fail} + 1
  fi
else
  if fatload mmc ${uboot_ts_dev}:${uboot_ts_part} ${scriptaddr} ${uboot_ts_script}; then
    if source ${scriptaddr}; then setexpr uboot_ts_pass ${uboot_ts_pass} + 1; else echo "subtest failed: ${uboot_ts_subtest}"; setexpr uboot_ts_fail ${uboot_ts_fail} + 1; fi
  else
    echo "subtest load failed: ${uboot_ts_subtest} (${uboot_ts_script})"
    setexpr uboot_ts_fail ${uboot_ts_fail} + 1
  fi
fi

# --- sdram/mtest ---
echo "==> RUN sdram/mtest"
setenv uboot_ts_subtest sdram/mtest
setenv uboot_ts_script ${uboot_ts_root}/uboot/sdram/mtest.scr
if test "${uboot_ts_load}" = "tftp"; then
  if tftp ${scriptaddr} ${uboot_ts_script}; then
    if source ${scriptaddr}; then setexpr uboot_ts_pass ${uboot_ts_pass} + 1; else echo "subtest failed: ${uboot_ts_subtest}"; setexpr uboot_ts_fail ${uboot_ts_fail} + 1; fi
  else
    echo "subtest load failed: ${uboot_ts_subtest} (${uboot_ts_script})"
    setexpr uboot_ts_fail ${uboot_ts_fail} + 1
  fi
else
  if fatload mmc ${uboot_ts_dev}:${uboot_ts_part} ${scriptaddr} ${uboot_ts_script}; then
    if source ${scriptaddr}; then setexpr uboot_ts_pass ${uboot_ts_pass} + 1; else echo "subtest failed: ${uboot_ts_subtest}"; setexpr uboot_ts_fail ${uboot_ts_fail} + 1; fi
  else
    echo "subtest load failed: ${uboot_ts_subtest} (${uboot_ts_script})"
    setexpr uboot_ts_fail ${uboot_ts_fail} + 1
  fi
fi

# --- i2c/i2c-probe ---
echo "==> RUN i2c/i2c-probe"
setenv uboot_ts_subtest i2c/i2c-probe
setenv uboot_ts_script ${uboot_ts_root}/uboot/i2c/i2c-probe.scr
if test "${uboot_ts_load}" = "tftp"; then
  if tftp ${scriptaddr} ${uboot_ts_script}; then
    if source ${scriptaddr}; then setexpr uboot_ts_pass ${uboot_ts_pass} + 1; else echo "subtest failed: ${uboot_ts_subtest}"; setexpr uboot_ts_fail ${uboot_ts_fail} + 1; fi
  else
    echo "subtest load failed: ${uboot_ts_subtest} (${uboot_ts_script})"
    setexpr uboot_ts_fail ${uboot_ts_fail} + 1
  fi
else
  if fatload mmc ${uboot_ts_dev}:${uboot_ts_part} ${scriptaddr} ${uboot_ts_script}; then
    if source ${scriptaddr}; then setexpr uboot_ts_pass ${uboot_ts_pass} + 1; else echo "subtest failed: ${uboot_ts_subtest}"; setexpr uboot_ts_fail ${uboot_ts_fail} + 1; fi
  else
    echo "subtest load failed: ${uboot_ts_subtest} (${uboot_ts_script})"
    setexpr uboot_ts_fail ${uboot_ts_fail} + 1
  fi
fi

echo "=== U-Boot OOBE smoke summary: pass=${uboot_ts_pass} fail=${uboot_ts_fail} ==="
if test ${uboot_ts_fail} -ne 0; then
  echo "[FAIL] U-Boot OOBE smoke batch completed with failures"
  exit 1
fi
echo "[PASS] U-Boot OOBE smoke batch completed"
