# Customer safety: destructive U-Boot script.
# Review UBOOT_QUICK_START.md and set uboot_allow_destructive=1 only after confirming recovery access.
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from reset/uboot/warm_reset_stress/test_steps.pl
echo "[uboot-warm-reset-stress] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] mw $loadaddr aaaaaaaa 1"
  if mw $loadaddr aaaaaaaa 1; then
    echo "[OK] mw $loadaddr aaaaaaaa 1"
  else
    echo "[FAIL] command failed: mw $loadaddr aaaaaaaa 1"
    exit 1
  fi
  echo "[cmd] md $loadaddr 4"
  if md $loadaddr 4; then
    echo "[OK] md $loadaddr 4"
  else
    echo "[FAIL] command failed: md $loadaddr 4"
    exit 1
  fi
  echo "[cmd] reset -w"
  echo "[INFO] reset command should reboot the board; script fails if it returns"
  reset -w
  echo "[FAIL] reset command returned unexpectedly"
  exit 1
  echo "[cmd] md $loadaddr 4"
  if md $loadaddr 4; then
    echo "[OK] md $loadaddr 4"
  else
    echo "[FAIL] command failed: md $loadaddr 4"
    exit 1
  fi
  echo "[PASS] Generated U-Boot command sequence reached completion"
fi
